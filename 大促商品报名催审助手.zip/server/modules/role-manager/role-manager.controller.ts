import { Body, Controller, Get, Post } from '@nestjs/common';
import {
  AuthorizationSDK,
  CanRole,
  NeedLogin,
} from '@lark-apaas/fullstack-nestjs-core';
import type {
  UserSimpleDTO,
  I18nText,
} from '@lark-apaas/fullstack-nestjs-core';

import type {
  AddAdminMembersRequest,
  AdminUser,
  ListAdminMembersResponse,
  RemoveAdminMembersRequest,
  SearchMembersRequest,
  SearchMembersResponse,
} from '@shared/api.interface';

const ADMIN_ROLE_BIZ_ID = 'admin';

function pickName(name?: I18nText): string {
  if (!name) return '';
  return name.zh_cn || name.en_us || Object.values(name)[0] || '';
}

function toAdminUser(user: UserSimpleDTO): AdminUser {
  return {
    userID: String(user.userID ?? ''),
    name: pickName(user.name),
    avatar: user.avatar,
    email: user.email,
  };
}

@Controller('api/role-manager')
export class RoleManagerController {
  constructor(private readonly authzSDK: AuthorizationSDK) {}

  @CanRole(['admin'])
  @Get('admins')
  async listAdmins(): Promise<ListAdminMembersResponse> {
    const res = await this.authzSDK.members.list(ADMIN_ROLE_BIZ_ID, {
      type: 'User',
      pageSize: 200,
    });
    const userList = (res.members.userList ?? []).map(toAdminUser);
    return { userList };
  }

  @NeedLogin()
  @CanRole(['admin'])
  @Post('admins')
  async addAdmins(@Body() dto: AddAdminMembersRequest) {
    await this.authzSDK.members.add(ADMIN_ROLE_BIZ_ID, {
      members: {
        userList: dto.userIds.map((userID: string) => ({ userID })),
      },
    });
    return { success: true };
  }

  @NeedLogin()
  @CanRole(['admin'])
  @Post('admins/batch_remove')
  async removeAdmins(@Body() dto: RemoveAdminMembersRequest) {
    await this.authzSDK.members.remove(ADMIN_ROLE_BIZ_ID, {
      members: {
        userList: dto.userIds.map((userID: string) => ({ userID })),
      },
    });
    return { success: true };
  }

  @NeedLogin()
  @CanRole(['admin'])
  @Post('search')
  async search(
    @Body() dto: SearchMembersRequest,
  ): Promise<SearchMembersResponse> {
    const res = await this.authzSDK.search.search({
      query: dto.query,
      page: dto.page ?? 1,
      pageSize: dto.pageSize ?? 20,
      filters: {
        departmentParam: { commonParam: { pageSize: 0 } },
        chatParam: { commonParam: { pageSize: 0 } },
      },
    });
    const items = res.result.userResult?.items ?? [];
    const userList: AdminUser[] = items.map((item) => ({
      userID: String(item.userID ?? ''),
      name: pickName(item.name),
      avatar: item.avatar,
      email: item.email,
    }));
    return { userList };
  }
}
