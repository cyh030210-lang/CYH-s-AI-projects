import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
} from '@nestjs/common';
import { CanRole, NeedLogin } from '@lark-apaas/fullstack-nestjs-core';

import { ActivityOptionService } from './activity-option.service';
import type {
  CreateActivityOptionRequest,
  CreateActivityOptionResponse,
  ListActivityOptionsResponse,
  MutationResultResponse,
} from '@shared/api.interface';

@Controller('api/activity-options')
export class ActivityOptionController {
  constructor(
    private readonly activityOptionService: ActivityOptionService,
  ) {}

  @NeedLogin()
  @Get()
  async list(): Promise<ListActivityOptionsResponse> {
    const items = await this.activityOptionService.list();
    return { items };
  }

  @NeedLogin()
  @CanRole(['admin'])
  @Post()
  async create(
    @Body() dto: CreateActivityOptionRequest,
  ): Promise<CreateActivityOptionResponse> {
    const item = await this.activityOptionService.create(dto.activityId);
    return { item };
  }

  @NeedLogin()
  @CanRole(['admin'])
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<MutationResultResponse> {
    await this.activityOptionService.remove(id);
    return { success: true };
  }
}
