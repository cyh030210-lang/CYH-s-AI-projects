import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { asc, eq } from 'drizzle-orm';

import { activityOption } from '../../database/schema';
import type { ActivityOption } from '@shared/api.interface';

type ActivityOptionRow = typeof activityOption.$inferSelect;

@Injectable()
export class ActivityOptionService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  private toDTO(row: ActivityOptionRow): ActivityOption {
    return {
      id: row.id,
      activityId: row.activityId,
    };
  }

  async list(): Promise<ActivityOption[]> {
    const rows = await this.db
      .select()
      .from(activityOption)
      .orderBy(asc(activityOption.createdAt));
    return rows.map((row: ActivityOptionRow) => this.toDTO(row));
  }

  async create(activityIdRaw: string): Promise<ActivityOption> {
    const activityId = (activityIdRaw ?? '').trim();
    if (!activityId) {
      throw new BadRequestException('活动 ID 不能为空');
    }

    const existing = await this.db
      .select()
      .from(activityOption)
      .where(eq(activityOption.activityId, activityId));
    if (existing.length > 0) {
      throw new ConflictException('该活动 ID 已存在');
    }

    const inserted = await this.db
      .insert(activityOption)
      .values({ activityId })
      .returning();
    return this.toDTO(inserted[0]);
  }

  async remove(id: string): Promise<void> {
    const deleted = await this.db
      .delete(activityOption)
      .where(eq(activityOption.id, id))
      .returning();
    if (deleted.length === 0) {
      throw new NotFoundException('活动 ID 不存在或已被删除');
    }
  }
}
