import { Module } from '@nestjs/common';

import { ActivityOptionController } from './activity-option.controller';
import { ActivityOptionService } from './activity-option.service';

@Module({
  controllers: [ActivityOptionController],
  providers: [ActivityOptionService],
})
export class ActivityOptionModule {}
