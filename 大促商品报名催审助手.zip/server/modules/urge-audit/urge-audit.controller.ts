import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { CanRole, NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';

import { UrgeAuditService } from './urge-audit.service';
import type {
  AuditStatus,
  BatchUpdateProcessRequest,
  CreateUrgeAuditRecordRequest,
  ProcessStatusFilter,
  UpdateUrgeAuditGroupRequest,
  UpdateUrgeAuditRowRequest,
  UpdateProcessRequest,
} from '@shared/api.interface';

@Controller('api/urge-audit-records')
export class UrgeAuditController {
  constructor(private readonly urgeAuditService: UrgeAuditService) {}

  @NeedLogin()
  @Get('mine')
  async listMine(
    @Req() req: Request,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new UnauthorizedException('请登录后查看提交记录');
    }
    return this.urgeAuditService.listMine(userId, {
      page: page ? parseInt(page, 10) : 1,
      pageSize: pageSize ? parseInt(pageSize, 10) : 20,
    });
  }

  @CanRole(['admin'])
  @Get()
  async list(
    @Query('activityId') activityId?: string,
    @Query('auditStatus') auditStatus?: string,
    @Query('processStatus') processStatus?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    return this.urgeAuditService.list({
      activityId: activityId || undefined,
      auditStatus: (auditStatus as AuditStatus) || undefined,
      processStatus: (processStatus as ProcessStatusFilter) || undefined,
      page: page ? parseInt(page, 10) : 1,
      pageSize: pageSize ? parseInt(pageSize, 10) : 20,
    });
  }

  @NeedLogin()
  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateUrgeAuditRecordRequest,
  ) {
    const { userId } = req.userContext;
    if (!userId) {
      throw new UnauthorizedException('请登录后提交催审记录');
    }
    return this.urgeAuditService.create(dto, userId);
  }

  private buildDetailUrl(req: Request): string {
    const base = (process.env.CLIENT_BASE_PATH ?? '').replace(/\/$/u, '');
    return `https://${req.hostname}${base}/`;
  }

  @CanRole(['admin'])
  @NeedLogin()
  @Post('batch_process')
  async batchProcess(
    @Req() req: Request,
    @Body() dto: BatchUpdateProcessRequest,
  ) {
    return this.urgeAuditService.batchUpdateProcess(
      dto.ids,
      dto.processResult,
      dto.processNote,
      this.buildDetailUrl(req),
    );
  }

  @CanRole(['admin'])
  @NeedLogin()
  @Patch(':id/row')
  async updateRow(
    @Param('id') id: string,
    @Body() dto: UpdateUrgeAuditRowRequest,
  ) {
    return this.urgeAuditService.updateRow(id, dto);
  }

  @CanRole(['admin'])
  @NeedLogin()
  @Put('group/:groupId')
  async updateGroup(
    @Param('groupId') groupId: string,
    @Body() dto: UpdateUrgeAuditGroupRequest,
  ) {
    return this.urgeAuditService.updateGroup(groupId, dto);
  }

  @CanRole(['admin'])
  @NeedLogin()
  @Patch(':id/process')
  async updateProcess(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateProcessRequest,
  ) {
    return this.urgeAuditService.updateProcess(
      id,
      dto,
      this.buildDetailUrl(req),
    );
  }

  @CanRole(['admin'])
  @Delete('group/:groupId')
  async removeGroup(@Param('groupId') groupId: string) {
    return this.urgeAuditService.removeGroup(groupId);
  }

  @CanRole(['admin'])
  @Delete(':id')
  async remove(@Param('id') id: string) {
    return this.urgeAuditService.remove(id);
  }
}
