import { Module } from '@nestjs/common';

import { UrgeAuditController } from './urge-audit.controller';
import { UrgeAuditOpenApiController } from './urge-audit.openapi.controller';
import { UrgeAuditService } from './urge-audit.service';

@Module({
  controllers: [UrgeAuditController, UrgeAuditOpenApiController],
  providers: [UrgeAuditService],
})
export class UrgeAuditModule {}
