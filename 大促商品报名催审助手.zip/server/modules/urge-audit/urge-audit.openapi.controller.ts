import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';

import { UrgeAuditService } from './urge-audit.service';
import type {
  AuditStatus,
  BackfillProcessResultRequest,
  ListUrgeAuditRecordsParams,
  ProcessStatusFilter,
  UpdateProcessResultByIdRequest,
} from '@shared/api.interface';

@Controller('openapi/urge-audit-records')
export class UrgeAuditOpenApiController {
  constructor(private readonly urgeAuditService: UrgeAuditService) {}

  private buildDetailUrl(req: Request): string {
    const base = (process.env.CLIENT_BASE_PATH ?? '').replace(/\/$/u, '');
    return `https://${req.hostname}${base}/`;
  }

  @Get()
  async list(
    @Query('activityId') activityId?: string,
    @Query('auditStatus') auditStatus?: string,
    @Query('processStatus') processStatus?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    return this.urgeAuditService.list({
      activityId: activityId || undefined,
      auditStatus: (auditStatus as AuditStatus) || undefined,
      processStatus: (processStatus as ProcessStatusFilter) || undefined,
      page: page ? parseInt(page, 10) : 1,
      pageSize: pageSize ? parseInt(pageSize, 10) : 20,
    });
  }

  @Post()
  async listByPost(@Body() body: ListUrgeAuditRecordsParams) {
    return this.urgeAuditService.list({
      activityId: body.activityId || undefined,
      auditStatus: body.auditStatus || undefined,
      processStatus: body.processStatus || undefined,
      page: body.page ?? 1,
      pageSize: body.pageSize ?? 20,
    });
  }

  @Get('product-ids')
  async listProductIds(@Query('processStatus') processStatus?: string) {
    return this.urgeAuditService.listProductIds(
      (processStatus as ProcessStatusFilter) || 'pending',
    );
  }

  @Post('process-result')
  async backfillProcessResult(
    @Req() req: Request,
    @Body() body: BackfillProcessResultRequest,
  ) {
    return this.urgeAuditService.backfillProcessResultByProductId(
      body?.items ?? [],
      this.buildDetailUrl(req),
    );
  }

  @Patch(':id')
  async updateProcessResult(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateProcessResultByIdRequest,
  ) {
    const record = await this.urgeAuditService.updateProcessResultById(
      id,
      dto?.processResult ?? '',
      dto?.processNote,
      this.buildDetailUrl(req),
    );
    if (!record) {
      throw new NotFoundException('催审记录不存在');
    }
    return record;
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    const record = await this.urgeAuditService.findOne(id);
    if (!record) {
      throw new NotFoundException('催审记录不存在');
    }
    return record;
  }

  @Post(':id')
  async findOneByPost(@Param('id') id: string) {
    const record = await this.urgeAuditService.findOne(id);
    if (!record) {
      throw new NotFoundException('催审记录不存在');
    }
    return record;
  }
}
