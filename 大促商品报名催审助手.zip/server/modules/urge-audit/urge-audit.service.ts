import { Inject, Injectable, Logger } from '@nestjs/common';
import {
  CapabilityService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { and, asc, count, desc, eq, inArray, sql } from 'drizzle-orm';

import { urgeAuditRecord } from '../../database/schema';
import type { SendFeishuReviewResultNotificationOneInput } from '@shared/plugin-types';
import type {
  AuditStatus,
  BackfillProcessResultItem,
  BackfillProcessResultResponse,
  CreateUrgeAuditRecordRequest,
  ListProductIdsResponse,
  ListUrgeAuditRecordsResponse,
  ListMyUrgeAuditRecordsParams,
  ProcessStatusFilter,
  UpdateUrgeAuditGroupRequest,
  UpdateUrgeAuditRowRequest,
  UpdateProcessRequest,
  UrgeAuditItem,
  UrgeAuditRecord,
} from '@shared/api.interface';

interface ListParams {
  activityId?: string;
  auditStatus?: AuditStatus;
  processStatus?: ProcessStatusFilter;
  page: number;
  pageSize: number;
}

type RecordRow = typeof urgeAuditRecord.$inferSelect;

const PROCESS_RESULT_NOTIFICATION_ID =
  'send_feishu_review_result_notification_1';

@Injectable()
export class UrgeAuditService {
  private readonly logger = new Logger(UrgeAuditService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    @Inject() private readonly capabilityService: CapabilityService,
  ) {}

  private buildNotificationContent(row: RecordRow): string {
    const lines = [
      '您提交的催审申请已填入处理结果：',
      '',
      `**申请人**：${row.applicantName}`,
      `**活动 ID**：${row.activityId}`,
      `**商品 ID**：${row.productId}`,
      `**处理结果**：${row.processResult}`,
    ];
    if (row.processNote && row.processNote.trim()) {
      lines.push(`**处理说明**：${row.processNote.trim()}`);
    }
    return lines.join('\n');
  }

  private notifyProcessResult(rows: RecordRow[], detailUrl: string): void {
    for (const row of rows) {
      const receiver = row.createdBy;
      if (!receiver || !row.processResult || !row.processResult.trim()) {
        continue;
      }
      const input: SendFeishuReviewResultNotificationOneInput = {
        receiver_user_ids: [receiver],
        content: this.buildNotificationContent(row),
        record_detail_url: detailUrl,
      };
      this.capabilityService
        .load(PROCESS_RESULT_NOTIFICATION_ID)
        .call('send_feishu_message', input)
        .catch((error: unknown) => {
          this.logger.warn(
            `send process result notification failed: ${JSON.stringify({
              pluginInstanceId: PROCESS_RESULT_NOTIFICATION_ID,
              actionKey: 'send_feishu_message',
              outputMode: 'unary',
              inputKeys: Object.keys(input),
              recordId: row.id,
              receiver,
              error:
                error instanceof Error ? error.message : 'Unknown error',
            })}`,
          );
        });
    }
  }

  private normalizeProductIds(productIds: string[]): string[] {
    const seen = new Set<string>();
    const result: string[] = [];
    for (const raw of productIds) {
      const trimmed = (raw ?? '').trim();
      if (trimmed && !seen.has(trimmed)) {
        seen.add(trimmed);
        result.push(trimmed);
      }
    }
    return result;
  }

  private normalizeItems(items: UrgeAuditItem[]): UrgeAuditItem[] {
    return (items ?? [])
      .map((item) => ({
        activityId: (item.activityId ?? '').trim(),
        productIds: this.normalizeProductIds(item.productIds ?? []),
      }))
      .filter((item) => item.activityId && item.productIds.length > 0);
  }

  private toResponse(row: RecordRow): UrgeAuditRecord {
    return {
      id: row.id,
      groupId: row.groupId,
      date: row.date,
      applicantName: row.applicantName,
      activityId: row.activityId,
      productId: row.productId,
      isNegotiating: row.isNegotiating,
      auditStatus: row.auditStatus as AuditStatus,
      remark: row.remark ?? '',
      remarkImages: (row.remarkImages as string[]) ?? [],
      processResult: row.processResult ?? '',
      processNote: row.processNote ?? '',
      processNoteImages: (row.processNoteImages as string[]) ?? [],
      createdAt:
        row.createdAt instanceof Date
          ? row.createdAt.toISOString()
          : String(row.createdAt),
    };
  }

  async list(params: ListParams): Promise<ListUrgeAuditRecordsResponse> {
    const { activityId, auditStatus, processStatus, page, pageSize } =
      params;
    const conditions = [];
    if (activityId) {
      conditions.push(eq(urgeAuditRecord.activityId, activityId));
    }
    if (auditStatus) {
      conditions.push(eq(urgeAuditRecord.auditStatus, auditStatus));
    }
    if (processStatus === 'pending') {
      conditions.push(sql`${urgeAuditRecord.processResult} = ''`);
    } else if (processStatus === 'processed') {
      conditions.push(sql`${urgeAuditRecord.processResult} <> ''`);
    }
    const whereClause =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(whereClause)
      .orderBy(
        desc(urgeAuditRecord.createdAt),
        asc(urgeAuditRecord.groupId),
        asc(urgeAuditRecord.productId),
      )
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = await this.db
      .select({ value: count() })
      .from(urgeAuditRecord)
      .where(whereClause);
    const total = Number(totalResult[0]?.value ?? 0);

    return {
      items: rows.map((row: RecordRow) => this.toResponse(row)),
      total,
    };
  }

  async listMine(
    userId: string,
    params: ListMyUrgeAuditRecordsParams,
  ): Promise<ListUrgeAuditRecordsResponse> {
    const page = params.page ?? 1;
    const pageSize = params.pageSize ?? 20;
    if (!userId) {
      return { items: [], total: 0 };
    }

    const whereClause = eq(
      sql`(${urgeAuditRecord.createdBy}).user_id`,
      userId,
    );

    const rows: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(whereClause)
      .orderBy(
        desc(urgeAuditRecord.createdAt),
        asc(urgeAuditRecord.groupId),
        asc(urgeAuditRecord.productId),
      )
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const totalResult = await this.db
      .select({ value: count() })
      .from(urgeAuditRecord)
      .where(whereClause);
    const total = Number(totalResult[0]?.value ?? 0);

    return {
      items: rows.map((row: RecordRow) => this.toResponse(row)),
      total,
    };
  }

  async create(
    dto: CreateUrgeAuditRecordRequest,
    userId: string,
  ): Promise<{ id: string }> {
    const items = this.normalizeItems(dto.items);
    const rows: Array<typeof urgeAuditRecord.$inferInsert> = [];
    for (const item of items) {
      const groupId = crypto.randomUUID();
      for (const productId of item.productIds) {
        rows.push({
          date: dto.date,
          applicantName: dto.applicantName.trim(),
          groupId,
          activityId: item.activityId,
          productId,
          isNegotiating: dto.isNegotiating,
          auditStatus: dto.auditStatus,
          remark: dto.remark ?? '',
          remarkImages: dto.remarkImages ?? [],
          processResult: '',
          processNote: '',
          processNoteImages: [],
          createdBy: userId,
        });
      }
    }
    const inserted: RecordRow[] = await this.db
      .insert(urgeAuditRecord)
      .values(rows)
      .returning();
    return { id: inserted[0].id };
  }

  async updateRow(
    id: string,
    dto: UpdateUrgeAuditRowRequest,
  ): Promise<{ success: boolean }> {
    await this.db
      .update(urgeAuditRecord)
      .set({
        productId: (dto.productId ?? '').trim(),
        isNegotiating: dto.isNegotiating,
        auditStatus: dto.auditStatus,
        remark: dto.remark ?? '',
        remarkImages: dto.remarkImages ?? [],
        updatedAt: new Date(),
      })
      .where(eq(urgeAuditRecord.id, id));
    return { success: true };
  }

  async updateGroup(
    groupId: string,
    dto: UpdateUrgeAuditGroupRequest,
  ): Promise<{ success: boolean }> {
    await this.db
      .update(urgeAuditRecord)
      .set({
        date: dto.date,
        applicantName: dto.applicantName.trim(),
        activityId: (dto.activityId ?? '').trim(),
        updatedAt: new Date(),
      })
      .where(eq(urgeAuditRecord.groupId, groupId));
    return { success: true };
  }

  async updateProcess(
    id: string,
    dto: UpdateProcessRequest,
    detailUrl?: string,
  ): Promise<{ success: boolean }> {
    const before: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(eq(urgeAuditRecord.id, id))
      .limit(1);
    const wasEmpty = !(before[0]?.processResult ?? '').trim();

    const updated: RecordRow[] = await this.db
      .update(urgeAuditRecord)
      .set({
        processResult: dto.processResult ?? '',
        processNote: dto.processNote ?? '',
        processNoteImages: dto.processNoteImages ?? [],
        updatedAt: new Date(),
      })
      .where(eq(urgeAuditRecord.id, id))
      .returning();

    if (detailUrl && wasEmpty && updated.length > 0) {
      this.notifyProcessResult(updated, detailUrl);
    }
    return { success: true };
  }

  async batchUpdateProcess(
    ids: string[],
    processResult: string,
    processNote?: string,
    detailUrl?: string,
  ): Promise<{ updated: number }> {
    const cleanIds = (ids ?? []).filter((id) => !!id);
    const result = (processResult ?? '').trim();
    if (cleanIds.length === 0 || !result) {
      return { updated: 0 };
    }
    const before: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(inArray(urgeAuditRecord.id, cleanIds));
    const wasEmptyIds = new Set(
      before
        .filter((row) => !(row.processResult ?? '').trim())
        .map((row) => row.id),
    );

    const setValues: Partial<typeof urgeAuditRecord.$inferInsert> = {
      processResult: result,
      updatedAt: new Date(),
    };
    if (typeof processNote === 'string') {
      setValues.processNote = processNote;
    }
    const updated: RecordRow[] = await this.db
      .update(urgeAuditRecord)
      .set(setValues)
      .where(inArray(urgeAuditRecord.id, cleanIds))
      .returning();

    if (detailUrl) {
      const toNotify = updated.filter((row) => wasEmptyIds.has(row.id));
      this.notifyProcessResult(toNotify, detailUrl);
    }
    return { updated: updated.length };
  }

  async listProductIds(
    processStatus?: ProcessStatusFilter,
  ): Promise<ListProductIdsResponse> {
    const conditions = [];
    if (processStatus === 'pending') {
      conditions.push(sql`${urgeAuditRecord.processResult} = ''`);
    } else if (processStatus === 'processed') {
      conditions.push(sql`${urgeAuditRecord.processResult} <> ''`);
    }
    const whereClause =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: Array<{ productId: string }> = await this.db
      .selectDistinct({ productId: urgeAuditRecord.productId })
      .from(urgeAuditRecord)
      .where(whereClause)
      .orderBy(asc(urgeAuditRecord.productId));

    const productIds = rows
      .map((row) => (row.productId ?? '').trim())
      .filter((id) => id.length > 0);

    return { productIds, total: productIds.length };
  }

  async updateProcessResultById(
    id: string,
    processResult: string,
    processNote?: string,
    detailUrl?: string,
  ): Promise<UrgeAuditRecord | null> {
    const before: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(eq(urgeAuditRecord.id, id))
      .limit(1);
    const wasEmpty = !(before[0]?.processResult ?? '').trim();

    const setValues: Partial<typeof urgeAuditRecord.$inferInsert> = {
      processResult: (processResult ?? '').trim(),
      updatedAt: new Date(),
    };
    if (typeof processNote === 'string') {
      setValues.processNote = processNote;
    }
    const updated: RecordRow[] = await this.db
      .update(urgeAuditRecord)
      .set(setValues)
      .where(eq(urgeAuditRecord.id, id))
      .returning();
    if (updated.length === 0) {
      return null;
    }

    if (detailUrl && wasEmpty) {
      this.notifyProcessResult(updated, detailUrl);
    }
    return this.toResponse(updated[0]);
  }

  async backfillProcessResultByProductId(
    items: BackfillProcessResultItem[],
    detailUrl?: string,
  ): Promise<BackfillProcessResultResponse> {
    const results: BackfillProcessResultResponse['results'] = [];
    let updated = 0;
    const allMatchedRows: RecordRow[] = [];

    for (const item of items ?? []) {
      const productId = (item?.productId ?? '').trim();
      const processResult = (item?.processResult ?? '').trim();
      if (!productId || !processResult) {
        continue;
      }

      // 查询更新前状态，判断哪些记录是首次填入处理结果
      const before: RecordRow[] = await this.db
        .select()
        .from(urgeAuditRecord)
        .where(eq(urgeAuditRecord.productId, productId));
      const wasEmptyIds = new Set(
        before.filter((row) => !(row.processResult ?? '').trim()).map((row) => row.id),
      );

      const setValues: Partial<typeof urgeAuditRecord.$inferInsert> = {
        processResult,
        updatedAt: new Date(),
      };
      if (typeof item.processNote === 'string') {
        setValues.processNote = item.processNote;
      }
      const matchedRows: RecordRow[] = await this.db
        .update(urgeAuditRecord)
        .set(setValues)
        .where(eq(urgeAuditRecord.productId, productId))
        .returning();

      results.push({ productId, matched: matchedRows.length });
      updated += matchedRows.length;

      if (detailUrl) {
        const toNotify = matchedRows.filter((row) => wasEmptyIds.has(row.id));
        allMatchedRows.push(...toNotify);
      }
    }

    if (detailUrl && allMatchedRows.length > 0) {
      this.notifyProcessResult(allMatchedRows, detailUrl);
    }
    return { updated, results };
  }

  async findOne(id: string): Promise<UrgeAuditRecord | null> {
    const rows: RecordRow[] = await this.db
      .select()
      .from(urgeAuditRecord)
      .where(eq(urgeAuditRecord.id, id))
      .limit(1);
    if (rows.length === 0) {
      return null;
    }
    return this.toResponse(rows[0]);
  }

  async remove(id: string): Promise<{ success: boolean }> {
    await this.db
      .delete(urgeAuditRecord)
      .where(eq(urgeAuditRecord.id, id));
    return { success: true };
  }

  async removeGroup(groupId: string): Promise<{ success: boolean }> {
    await this.db
      .delete(urgeAuditRecord)
      .where(eq(urgeAuditRecord.groupId, groupId));
    return { success: true };
  }
}
