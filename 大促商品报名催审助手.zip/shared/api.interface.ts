/* 前后端共享的类型写在这里 */

export type AuditStatus = 'abnormal' | 'pending_first_review' | 'reviewing';

export const ACTIVITY_ID_OPTIONS = [
  '7390937781360443674',
  '7628508121755566374',
] as const;

export const AUDIT_STATUS_LABELS: Record<AuditStatus, string> = {
  abnormal: '报名异常',
  pending_first_review: '待一审',
  reviewing: '审核中',
};

export const PROCESS_RESULT_OPTIONS = [
  '商品高价,议价中,商家响应前不可催审',
  '审核时效为48小时,未超时不可催审',
  '已过审,运营可在招商后台查询最新报名状态',
  '已超时且未议价@王馨悦',
  '已驳回,运营可在招商后台查最新报名状态',
  '商家已取消报名,运营可在招商后台查最新报名状态',
  '无报名记录',
  '议价申诉审核中',
  '议价申诉中,无需填本表,请参考sheet2的场景二进行反馈,后续也不用填本表',
  '商品校验价巡检不通过,商家响应前不可催审',
  '商品/商家资质不满足活动要求',
] as const;

export type ProcessResult = (typeof PROCESS_RESULT_OPTIONS)[number];

export interface UrgeAuditItem {
  activityId: string;
  productIds: string[];
}

export interface UrgeAuditRecord {
  id: string;
  groupId: string;
  date: string;
  applicantName: string;
  activityId: string;
  productId: string;
  isNegotiating: boolean;
  auditStatus: AuditStatus;
  remark: string;
  remarkImages: string[];
  processResult: string;
  processNote: string;
  processNoteImages: string[];
  createdAt: string;
}

export interface UpdateProcessRequest {
  processResult: string;
  processNote: string;
  processNoteImages: string[];
}

/** 批量标记已处理：对多行设置同一处理结果 */
export interface BatchUpdateProcessRequest {
  ids: string[];
  processResult: string;
  processNote?: string;
}

export interface BatchUpdateProcessResponse {
  updated: number;
}

export interface UpdateProcessResultByIdRequest {
  processResult: string;
  processNote?: string;
}

export interface ListProductIdsResponse {
  productIds: string[];
  total: number;
}

export interface BackfillProcessResultItem {
  productId: string;
  processResult: string;
  processNote?: string;
}

export interface BackfillProcessResultRequest {
  items: BackfillProcessResultItem[];
}

export interface BackfillProcessResultResultItem {
  productId: string;
  matched: number;
}

export interface BackfillProcessResultResponse {
  updated: number;
  results: BackfillProcessResultResultItem[];
}

export interface CreateUrgeAuditRecordRequest {
  date: string;
  applicantName: string;
  items: UrgeAuditItem[];
  isNegotiating: boolean;
  auditStatus: AuditStatus;
  remark?: string;
  remarkImages?: string[];
}

export interface ListMyUrgeAuditRecordsParams {
  page?: number;
  pageSize?: number;
}

/** 行级编辑：修改单个商品行的商品ID/议价/审核状态/备注 */
export interface UpdateUrgeAuditRowRequest {
  productId: string;
  isNegotiating: boolean;
  auditStatus: AuditStatus;
  remark?: string;
  remarkImages?: string[];
}

/** 组级编辑：修改整组的日期/申请人/活动ID（写回同组所有行） */
export interface UpdateUrgeAuditGroupRequest {
  date: string;
  applicantName: string;
  activityId: string;
}

export type ProcessStatusFilter = 'pending' | 'processed';

export interface ListUrgeAuditRecordsParams {
  activityId?: string;
  auditStatus?: AuditStatus;
  processStatus?: ProcessStatusFilter;
  page?: number;
  pageSize?: number;
}

export interface ListUrgeAuditRecordsResponse {
  items: UrgeAuditRecord[];
  total: number;
}

export interface CreateUrgeAuditRecordResponse {
  id: string;
}

export interface MutationResultResponse {
  success: boolean;
}

export interface AdminUser {
  userID: string;
  name: string;
  avatar?: string;
  email?: string;
}

export interface AddAdminMembersRequest {
  userIds: string[];
}

export interface RemoveAdminMembersRequest {
  userIds: string[];
}

export interface SearchMembersRequest {
  query: string;
  page?: number;
  pageSize?: number;
}

export interface ListAdminMembersResponse {
  userList: AdminUser[];
}

export interface SearchMembersResponse {
  userList: AdminUser[];
}

export interface ActivityOption {
  id: string;
  activityId: string;
}

export interface ListActivityOptionsResponse {
  items: ActivityOption[];
}

export interface CreateActivityOptionRequest {
  activityId: string;
}

export interface CreateActivityOptionResponse {
  item: ActivityOption;
}
