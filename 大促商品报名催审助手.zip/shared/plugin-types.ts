// ---- plugin:feishu_bitable_batch_add_reminder_records_1 ----
// ============================================================
// 插件 feishu_bitable_batch_add_reminder_records_1 (批量写入催审记录到飞书多维表格) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface FeishuBitableBatchAddReminderRecordsOneAggregatequeryInput {
  /** [object Object] */
  filter?: {
    conditions: {
      fieldName: string;
      operator: string;
      value: string[];
    }[];
    conjunction: string;
  };
  /** [object Object] */
  expandArrayDimension?: boolean;
  /** [object Object] */
  dimensions?: string[];
  /** [object Object] */
  measures?: {
    fieldName: string;
    aggregation: string;
    alias: string;
  }[];
  /** [object Object] */
  pageToken?: string;
  /** [object Object] */
  pageSize?: number;
  /** [object Object] */
  sort?: {
    fieldName: string;
    desc: boolean;
  }[];
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneAggregatequeryOutput>('aggregateQuery', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { result, hasMore, pageToken } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneAggregatequeryOutput {
  /** [object Object] */
  result: {

  }[];
  /** [object Object] */
  hasMore: boolean;
  /** [object Object] */
  pageToken?: string;
}

export interface FeishuBitableBatchAddReminderRecordsOneBatchaddrecordsInput {
  /** [object Object] */
  records: {
    record: {
      '是否议价中': boolean;
      '审核状态': string;
      '备注': string;
      '提交时间': number;
      '日期': number;
      '申请人': number[];
      '活动与商品明细(文本汇总)': string;
    };
  }[];
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneBatchaddrecordsOutput>('batchAddRecords', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { records } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneBatchaddrecordsOutput {
  /** [object Object] */
  records: {
    id: string;
  }[];
}

export interface FeishuBitableBatchAddReminderRecordsOneBatchupdaterecordsInput {
  /** [object Object] */
  records: {
    id: string;
    record: {
      '备注': string;
      '提交时间': number;
      '日期': number;
      '申请人': number[];
      '活动与商品明细(文本汇总)': string;
      '是否议价中': boolean;
      '审核状态': string;
    };
  }[];
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneBatchupdaterecordsOutput>('batchUpdateRecords', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { records } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneBatchupdaterecordsOutput {
  /** [object Object] */
  records: {
    id: string;
  }[];
}

export interface FeishuBitableBatchAddReminderRecordsOneDeleterecordsInput {
  /** [object Object] */
  recordIDs: string[];
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneDeleterecordsOutput>('deleteRecords', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { success } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneDeleterecordsOutput {
  /** [object Object] */
  success: boolean;
}

export interface FeishuBitableBatchAddReminderRecordsOneGetrecordInput {
  /** [object Object] */
  recordID: string;
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneGetrecordOutput>('getRecord', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { id, record } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneGetrecordOutput {
  /** [object Object] */
  id: string;
  /** [object Object] */
  record?: {
    '日期': number;
    '申请人': number[];
    '活动与商品明细(文本汇总)': {
      text: string;
    };
    '是否议价中': unknown;
    '审核状态': string;
    '备注': unknown;
    '提交时间': number;
  };
}

export interface FeishuBitableBatchAddReminderRecordsOneSearchrecordsInput {
  /** [object Object] */
  filter?: {
    conjunction: string;
    conditions: {
      operator: string;
      value: string[];
      fieldName: string;
    }[];
  };
  /** [object Object] */
  pageToken?: string;
  /** [object Object] */
  pageSize?: number;
  /** [object Object] */
  fieldNames?: string[];
  /** [object Object] */
  sort?: {
    fieldName: string;
    desc: boolean;
  }[];
}

/**
 * capabilityClient.load('feishu_bitable_batch_add_reminder_records_1').call<FeishuBitableBatchAddReminderRecordsOneSearchrecordsOutput>('searchRecords', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { hasMore, pageToken, total, ... } = result;
 */
export interface FeishuBitableBatchAddReminderRecordsOneSearchrecordsOutput {
  /** [object Object] */
  hasMore: boolean;
  /** [object Object] */
  pageToken?: string;
  /** [object Object] */
  total?: number;
  /** [object Object] */
  records: {
    id: string;
    record: {
      '申请人': number[];
      '活动与商品明细(文本汇总)': {
        text: string;
      };
      '是否议价中': unknown;
      '审核状态': string;
      '备注': unknown;
      '提交时间': number;
      '日期': number;
    };
  }[];
}
// ---- end:feishu_bitable_batch_add_reminder_records_1 ----

// ---- plugin:send_feishu_review_result_notification_1 ----
// ============================================================
// 插件 send_feishu_review_result_notification_1 (催审处理结果飞书通知) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface SendFeishuReviewResultNotificationOneInput {
  /** 接收通知的用户ID列表（催审记录提交人ID） */
  receiver_user_ids: string[];
  /** 催审处理结果正文内容，支持markdown格式 */
  content: string;
  /** 催审记录详情页的应用深链地址 */
  record_detail_url: string;
}

/**
 * capabilityClient.load('send_feishu_review_result_notification_1').call<SendFeishuReviewResultNotificationOneOutput>('send_feishu_message', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { success } = result;
 */
export interface SendFeishuReviewResultNotificationOneOutput {
  /** [object Object] */
  success: boolean;
}
// ---- end:send_feishu_review_result_notification_1 ----