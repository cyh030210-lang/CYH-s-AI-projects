# UI 设计指南

> **设计类型**: App 设计（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。

> ℹ️ Section 1 为设计意图与决策上下文。Code agent 实现时以 Section 2 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解

- **目标用户**: 电商平台运营人员，高频录入催审数据，追求效率与准确性
- **核心目的**: 引导行动（快速录入）+ 告知（状态反馈）
- **情绪基调**: 专注、掌控感 / 避免焦虑、视觉疲劳

### 1.2 设计方向

- **Design Style**: Data-Dense Dashboard（数据密集仪表盘）— 品牌蓝主色、清晰信息层级、紧凑卡片分组，强调批量操作与高效筛选
- **Application Type**: Admin/SaaS Tool — 录入页双栏（概览栏 + 表单）、管理页卡片分组工作台
- **Aesthetic Direction**: 冷中性 slate 背景承载信息，品牌蓝 #1E40AF 用于主操作与激活态，状态色搭配图标双重表达

## 2. Color System (色彩系统)

**色彩关系**: 冷中性 slate 背景 + 纯白卡片 + 品牌蓝主色 + 状态色（橙/蓝/红，均配图标）
**配色设计理由**: 数据密集场景需要清晰品牌识别与信息层级，品牌蓝建立操作锚点，状态色低饱和背景 + 图标避免仅靠颜色传达
**主色推导**: primary 选用品牌蓝 hsl(224 64% 40%)（≈#1E40AF），用于主按钮、激活 tab、选中态、卡片左侧色条
**使用比例**: 70% 冷中性背景/卡片 / 18% 品牌蓝主色与文字 / 12% 状态语义色

### 2.1 主题颜色

| Token                | HSL 值             | 说明                         |
| -------------------- | ------------------ | ---------------------------- |
| `background`         | hsl(210 40% 98%)   | 冷中性 slate 页面底色        |
| `card`               | hsl(0 0% 100%)     | 表单/卡片容器背景            |
| `foreground`         | hsl(217 33% 17%)   | 主文字，深 slate             |
| `muted-foreground`   | hsl(215 16% 47%)   | 次要文字/placeholder         |
| `primary`            | hsl(224 64% 40%)   | 主按钮/激活态/卡片色条，品牌蓝 |
| `primary-foreground` | hsl(0 0% 100%)     | 主按钮文字                   |
| `accent`             | hsl(214 38% 95%)   | hover/focus/skeleton 背景    |
| `border`             | hsl(214 32% 91%)   | 输入框/分割线边框            |

### 2.3 语义颜色（状态徽标，颜色 + 图标双重表达）

| 状态       | 文字色 / 背景                              | 图标（lucide）      |
| ---------- | ----------------------------------------- | ------------------- |
| 待一审     | hsl(32 90% 38%) / hsl(32 95% 44% /.12)    | Clock 时钟          |
| 审核中     | hsl(221 80% 46%) / hsl(221 83% 53% /.12)  | RefreshCw 刷新      |
| 报名异常   | hsl(0 72% 42%) / hsl(0 72% 51% /.10)      | AlertTriangle 警示  |
| 议价中     | warning 暖橙轻量 tag                       | 无（轻量标签）      |
| 成功反馈   | `success` hsl(142 71% 36%)                | Toast / 行高亮闪现  |

## 3. Typography (字体排版)

- **Heading**: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- **Body**: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- **字体策略**: Inter 数字等宽特性适配 ID/日期对齐；中文回退系统默认无衬线保障可读性

## 4. Layout Strategy (布局策略)

- **导航意图**: 无全局导航；录入页单列居中（顶部标题区 + 表单 + 概览）；管理页单列卡片工作台
- **页面架构**: 录入页 `max-w-[820px]` 单列居中：顶部标题区（图标+标题同行居中、副标题居中、admin「进入管理」入口绝对定位右上角）→ 表单卡片 → 底部「本人提交概览」扁平卡片（与表单同宽，三计数横向 grid + 查看记录入口）；管理页 `max-w-[1400px]` 单列，tab + 筛选栏 + 批量工具条 + 卡片列表
- **响应式**: ≤1024px 管理页卡片纵向排列，窄屏正常折行

## 5. Visual Language (视觉语言)

- **形态参数**: 控件圆角 8px / 卡片 10px · 阴影 `shadow-sm` 低透明度冷阴影 · 间距 `comfortable (gap-5~7 / p-6~8)`
- **识别签名**: 管理页卡片式分组（卡头日期/申请人/活动ID + 左侧品牌蓝色条，组内每商品一行，永不串组）；状态以「柔底胶囊 + 图标 + 文字」表达
- **数字排版**: 日期 / 商品 ID / 活动 ID / 计数统一 `tabular-nums` 防抖动
- **动效原则**: 表单进场 opacity+位移 250ms + 记录行高亮闪现 1.2s + Toast/AutoAnimate 列表增删
- **可及性**: 正文对比度 ≥ 4.5:1；图标按钮均带 aria-label + title；所有交互元素有 focus ring

## 6. Component Principles (组件原则)

- **状态完整性**: Input/Select/Checkbox/Button 覆盖 Default/Hover/Focus/Disabled/Error；Focus 统一 `ring-2 ring-ring/30`
- **层级清晰**: Primary Button `bg-primary text-primary-foreground`（近黑）；Ghost Icon Button `text-muted-foreground hover:text-foreground`
- **一致性**: 状态胶囊统一 `gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium` + 1.5px 圆点；卡片统一 `rounded-lg shadow-sm p-6 md:p-8`；lucide 图标统一 `strokeWidth={1.75}`

## 7. Image Direction (图片与视觉资产)

- **Image Role**: 无强制图片需求
- **Image Art Direction**: 优先通过排版节奏、状态色对比和输入框尺寸差异建立视觉记忆点
- **Image Prompt Keywords**: 无
- **Image Avoidance**: 无

## 8. 应避免 (Anti-patterns)

- ❌ 使用高饱和主色或实心高饱和状态块大面积填充，破坏耳语级语义与 premium 克制感
- ❌ 表格行高过大或添加多余分隔线，破坏紧凑录入节奏
- ❌ 弹窗/卡片使用过重投影或彩色阴影，偏离暖中性高级极简基调
- ❌ 使用文本箭头（←/→）或 emoji，统一用 lucide 图标

## 9. 功能与数据结构 (Functional Notes)

- **页面区隔与权限**:
  - `/` 指向 `pages/UrgeAuditEntry`：**催审信息录入页，需登录**，提交记录以登录账号归属（写入审计列 `_created_by`）。  - `/manage` 指向 `pages/UrgeAuditManage`：**催审记录管理页，仅管理员可见**，用 `ProtectedRoute` + `useAuth` 做路由守卫，要求平台 `admin` 角色，无权限重定向 `/unauthorized`（`pages/Unauthorized`）。录入页底部对 admin 显示「进入管理」入口（`<CanRole roles={['admin']}>`）。
  - 录入页与管理页复用 `pages/UrgeAuditWorkbench/` 下的 `RecordForm` / `MyRecordList` / `StatusBadge` / `useUrgeAuditRecords` / `utils`。
  - 录入页为单列居中布局：顶部标题区（图标+标题同行、副标题、admin 进入管理入口右上角）→ 表单 → 底部「本人提交概览」扁平卡片（待一审/审核中/异常计数 + 查看记录入口）；表单 `mode:'onBlur'` 失焦校验，商品组为虚线可重复卡片（自动编号、可删、至少一组），helper text 常驻，提交按钮 loading「提交中…」，提交成功刷新概览并 toast。
- **后端鉴权**: `POST /api/urge-audit-records`（录入）与 `GET /api/urge-audit-records/mine`（查看本人记录）均加 `@NeedLogin()`，并在 controller 层校验 `req.userContext.userId`为空时抛 401；`GET`（列表）/ `POST batch_process`（批量标记已处理）/ 行级 `PATCH :id/row` / 行级 `PATCH :id/process` / 组级 `PUT group/:groupId` / 行删除 `DELETE :id` / 组删除 `DELETE group/:groupId` 均加 `@CanRole(['admin'])`（写操作另加 `@NeedLogin()`）。前端 API 层对管理类接口检查 `res.status === 403` 抛明确无权限提示。
- **RLS**: `urge_audit_record` 表允许 `authenticated` 执行 INSERT。
- **申请人字段**: 因面向外部商服且平台人员选择器仅能检索内部组织，申请人改为纯文本输入 `applicantName`（varchar），不使用 UserSelect/UserDisplay。
- **议价中不可提交**: RecordForm 的 zod `superRefine` 校验——当「是否议价中」选择「议价中」(`yes`) 时阻止提交，在字段下报错「商品高价，议价中，商家响应前不可催审」。
- **账号归属与查看本人记录**: 提交时由系统将当前登录用户写入审计列 `_created_by`（service.create 接收 userId）。录入页「查看我的提交记录」按钮调 `GET /mine`，service 按 `(_created_by).user_id = 当前用户` 过滤，弹窗内用只读 `MyRecordList` 展示，跨设备可见且互不可见。
- **活动与商品（商品行级存储）**: 数据以「一个商品 ID = 一行」粒度存储。同一次提交的同一活动共享一个 `group_id`（组级字段：`date` / `applicant_name` / `activity_id`）；每行独立拥有 `product_id` / `is_negotiating` / `audit_status` / `remark` / `process_*`（行级字段）。录入表单（RecordForm）仍按「活动组 + 多商品 ID」体验，提交 `items: { activityId, productIds[] }[]`，由后端 `create` 按组生成 `group_id` 并逐商品展开为多行。商品 ID 支持换行/逗号分隔并自动去重去空。
- **卡片式分组展示与操作（仅管理员，替代旧 rowspan 表格）**: 管理页全量拉取数据（`useUrgeAuditRecords` 拉 processStatus 过滤后的全部记录），前端按 `groupRecordsByGroupId` 聚合，用 `RecordGroupCard` 渲染——每个申请单一张卡，卡头固定显示日期/申请人/活动ID + 左侧品牌蓝色条 + 组级多选/编辑组/删除组，组内每商品一行（行级多选 + 商品ID/议价tag/状态徽标/备注/处理结果 + 行操作）永不串组。`待处理` tab 隐藏处理结果展示，`已处理` tab 显示。
  - **筛选**: `ManageFilterBar` 提供搜索框（按商品ID/申请人实时过滤，`utils.filterRecords`）+ 活动 ID 下拉 + 审核状态下拉（均用 `__all__` 哨兵值代表「全部」，回调翻译回空字符串）+ 日期区间（shadcn Calendar）+ 一键清除；四维可自由组合，任一生效即显示「清除筛选」。`pending/processed` tab 走服务端 `processStatus` 过滤。
  - **批量操作**: 行级 + 组级全选多选，选中后顶部工具条浮现「批量标记已处理」（`BatchProcessDialog` 选处理结果，`POST batch_process`）。
  - **行级操作**：`ProcessDialog`（处理结果/说明/图片，`PATCH :id/process`）、行删除（`DELETE :id`）。**不提供行编辑**（已移除 RowEditDialog 入口）。
  - **组级操作**：`GroupEditDialog`（日期/申请人/活动ID，`PUT group/:groupId`）、组删除（`DELETE group/:groupId`）。
  - **删除撤销**: 行/组删除采用延迟执行——先从视图隐藏并弹带「撤销」的 toast，5s 内未撤销才真正调后端删除接口。空态有 Inbox 插画 + 文案，loading 用骨架屏。
- **本人记录展示**: `MyRecordList` 按 `group_id` 聚合（`utils.groupRecordsByGroupId`），一组一卡片，组内每商品一行。
- **数据表**: `urge_audit_record`（商品行级，一行一个商品 ID），字段 group_id / date / applicant_name / activity_id / product_id / is_negotiating / audit_status / remark / process_result / process_note / process_note_images(jsonb)；按 `group_id` 建索引 `idx_urge_audit_record_group_id`；归属依赖审计列 `_created_by`。
- **管理员管理**: 管理页头部「管理员设置」按钮打开 `AdminManageDialog`，通过 `AuthorizationSDK` 对平台 `admin` 角色做用户成员的增/删/查（`UserSelect` 选人添加、`UserDisplay` 列表展示、逐项移除）。后端 `server/modules/role-manager/`，接口 `GET /api/role-manager/admins`、`POST /api/role-manager/admins`、`POST /api/role-manager/admins/batch_remove`，均加 `@CanRole(['admin'])`，写操作另加 `@NeedLogin()`；前端 API 层对 403 抛明确无权限提示。
- **活动 ID 动态管理**: 活动 ID 存于 `activity_option` 表（`activity_id` varchar 唯一），不再硬编码。管理页头部「活动 ID 管理」按钮打开 `ActivityOptionDialog`（输入框新增 + 列表逐项删除）。后端 `server/modules/activity-option/`，接口 `GET /api/activity-options`（列表，`@NeedLogin()` 登录可读）、`POST /api/activity-options`（新增，`@CanRole(['admin'])`，非空+去重校验，重复报 409）、`DELETE /api/activity-options/:id`（删除，`@CanRole(['admin'])`）。录入表单 `RecordForm`、管理页筛选 `ManageFilterBar`、组编辑 `GroupEditDialog` 三处活动 ID 下拉统一通过 `useActivityOptions` hook（位于 `pages/UrgeAuditWorkbench/`）动态拉取。删除活动 ID 仅影响下拉候选项，不影响已提交记录里存储的 `activity_id`。
- **接口**: `GET /api/urge-audit-records`（列表）、`POST`（录入）、`POST batch_process`（批量标记已处理）、`PATCH :id/row`（行编辑，前端暂未使用）、`PATCH :id/process`（处理）、`PUT group/:groupId`（组编辑）、`DELETE :id`（行删除）、`DELETE group/:groupId`（组删除），外加公开的 `GET /api/urge-audit-records/mine` 与 `/openapi/urge-audit-records`（列表/详情，行级结构）。