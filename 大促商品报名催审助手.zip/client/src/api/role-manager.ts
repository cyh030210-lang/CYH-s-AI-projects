import {
  axiosForBackend,
} from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

import type {
  AddAdminMembersRequest,
  ListAdminMembersResponse,
  MutationResultResponse,
  RemoveAdminMembersRequest,
} from '@shared/api.interface';

const BASE = '/api/role-manager';

const NO_PERMISSION_MESSAGE = '无操作权限，请联系管理员分配角色';

export async function listAdmins(): Promise<ListAdminMembersResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/admins`,
      method: 'GET',
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('获取管理员列表失败', error);
    throw error;
  }
}

export async function addAdmins(
  body: AddAdminMembersRequest,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/admins`,
      method: 'POST',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('添加管理员失败', error);
    throw error;
  }
}

export async function removeAdmins(
  body: RemoveAdminMembersRequest,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/admins/batch_remove`,
      method: 'POST',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('移除管理员失败', error);
    throw error;
  }
}
