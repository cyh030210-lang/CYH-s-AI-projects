import {
  axiosForBackend,
} from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

import type {
  BatchUpdateProcessRequest,
  BatchUpdateProcessResponse,
  CreateUrgeAuditRecordRequest,
  CreateUrgeAuditRecordResponse,
  ListUrgeAuditRecordsParams,
  ListUrgeAuditRecordsResponse,
  ListMyUrgeAuditRecordsParams,
  MutationResultResponse,
  UpdateUrgeAuditGroupRequest,
  UpdateUrgeAuditRowRequest,
  UpdateProcessRequest,
} from '@shared/api.interface';

const BASE = '/api/urge-audit-records';

const NO_PERMISSION_MESSAGE = '无操作权限，请联系管理员分配角色';

export async function listRecords(
  params: ListUrgeAuditRecordsParams = {},
): Promise<ListUrgeAuditRecordsResponse> {
  try {
    const res = await axiosForBackend({
      url: BASE,
      method: 'GET',
      params,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('获取催审记录列表失败', error);
    throw error;
  }
}

export async function listMyRecords(
  params: ListMyUrgeAuditRecordsParams = {},
): Promise<ListUrgeAuditRecordsResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/mine`,
      method: 'GET',
      params,
    });
    return res.data;
  } catch (error) {
    logger.error('获取我的催审记录失败', error);
    throw error;
  }
}

export async function createRecord(
  body: CreateUrgeAuditRecordRequest,
): Promise<CreateUrgeAuditRecordResponse> {
  try {
    const res = await axiosForBackend({
      url: BASE,
      method: 'POST',
      data: body,
    });
    return res.data;
  } catch (error) {
    logger.error('创建催审记录失败', error);
    throw error;
  }
}

export async function updateRow(
  id: string,
  body: UpdateUrgeAuditRowRequest,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/${id}/row`,
      method: 'PATCH',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('更新催审商品行失败', error);
    throw error;
  }
}

export async function updateGroup(
  groupId: string,
  body: UpdateUrgeAuditGroupRequest,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/group/${groupId}`,
      method: 'PUT',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('更新催审记录组失败', error);
    throw error;
  }
}

export async function updateProcess(
  id: string,
  body: UpdateProcessRequest,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/${id}/process`,
      method: 'PATCH',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('更新处理结果失败', error);
    throw error;
  }
}

export async function batchProcess(
  body: BatchUpdateProcessRequest,
): Promise<BatchUpdateProcessResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/batch_process`,
      method: 'POST',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('批量标记已处理失败', error);
    throw error;
  }
}

export async function deleteRecord(
  id: string,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/${id}`,
      method: 'DELETE',
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('删除催审记录失败', error);
    throw error;
  }
}

export async function deleteGroup(
  groupId: string,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/group/${groupId}`,
      method: 'DELETE',
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('删除催审记录组失败', error);
    throw error;
  }
}
