import {
  axiosForBackend,
} from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';

import type {
  CreateActivityOptionRequest,
  CreateActivityOptionResponse,
  ListActivityOptionsResponse,
  MutationResultResponse,
} from '@shared/api.interface';

const BASE = '/api/activity-options';

const NO_PERMISSION_MESSAGE = '无操作权限，请联系管理员分配角色';

export async function listActivityOptions(): Promise<ListActivityOptionsResponse> {
  try {
    const res = await axiosForBackend({
      url: BASE,
      method: 'GET',
    });
    return res.data;
  } catch (error) {
    logger.error('获取活动 ID 列表失败', error);
    throw error;
  }
}

export async function createActivityOption(
  body: CreateActivityOptionRequest,
): Promise<CreateActivityOptionResponse> {
  try {
    const res = await axiosForBackend({
      url: BASE,
      method: 'POST',
      data: body,
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('新增活动 ID 失败', error);
    throw error;
  }
}

export async function deleteActivityOption(
  id: string,
): Promise<MutationResultResponse> {
  try {
    const res = await axiosForBackend({
      url: `${BASE}/${id}`,
      method: 'DELETE',
    });
    if (res.status === 403) throw new Error(NO_PERMISSION_MESSAGE);
    return res.data;
  } catch (error) {
    logger.error('删除活动 ID 失败', error);
    throw error;
  }
}
