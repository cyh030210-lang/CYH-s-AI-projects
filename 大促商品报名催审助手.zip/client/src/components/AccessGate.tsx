import React, { useState } from 'react';
import { Lock } from 'lucide-react';

import { Button } from './ui/button';
import { Input } from './ui/input';

const ACCESS_PASSWORD = 'qixidamai';
const STORAGE_KEY = 'app_access_granted';

const AccessGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [granted, setGranted] = useState<boolean>(
    () => sessionStorage.getItem(STORAGE_KEY) === '1',
  );
  const [value, setValue] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value === ACCESS_PASSWORD) {
      sessionStorage.setItem(STORAGE_KEY, '1');
      setError(false);
      setGranted(true);
    } else {
      setError(true);
    }
  };

  if (granted) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-background px-4">
      <div className="w-full max-w-[380px] rounded-lg border border-border bg-card p-8 shadow-sm">
        <div className="flex flex-col items-center text-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent">
            <Lock className="h-5 w-5 text-primary" strokeWidth={1.75} />
          </div>
          <h1 className="text-lg font-semibold text-foreground">访问验证</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            请输入访问密码以继续
          </p>
        </div>
        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-3">
          <Input
            type="password"
            autoFocus
            placeholder="请输入密码"
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (error) setError(false);
            }}
            aria-label="访问密码"
            className={error ? 'border-destructive focus-visible:ring-destructive/30' : ''}
          />
          {error && (
            <p className="text-sm text-destructive">密码错误，请重新输入</p>
          )}
          <Button type="submit" className="mt-1 w-full">
            进入
          </Button>
        </form>
      </div>
    </div>
  );
};

export default AccessGate;
