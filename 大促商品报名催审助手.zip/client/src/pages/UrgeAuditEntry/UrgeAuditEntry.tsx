import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  ClipboardList,
  History,
  ArrowRight,
  Download,
  Clock,
  RefreshCw,
  AlertTriangle,
} from 'lucide-react';
import { NavLink } from 'react-router-dom';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { CanRole } from '@lark-apaas/client-toolkit/auth';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { cn } from '@/lib/utils';
import * as urgeAuditApi from '@/api/urge-audit';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

import RecordForm, {
  RecordFormSubmitData,
} from '../UrgeAuditWorkbench/RecordForm';
import MyRecordList from '../UrgeAuditWorkbench/MyRecordList';
import { exportMyRecordsToExcel } from '../UrgeAuditWorkbench/exportMyRecords';

interface OverviewStat {
  key: AuditStatus;
  label: string;
  icon: typeof Clock;
  count: number;
  tone: string;
}

const UrgeAuditEntry: React.FC = () => {
  const [formKey, setFormKey] = useState(0);
  const [myRecordsOpen, setMyRecordsOpen] = useState(false);
  const [myRecords, setMyRecords] = useState<UrgeAuditRecord[]>([]);
  const [myRecordsLoading, setMyRecordsLoading] = useState(false);

  const fetchMyRecords = useCallback(async () => {
    setMyRecordsLoading(true);
    try {
      const res = await urgeAuditApi.listMyRecords({
        page: 1,
        pageSize: 100,
      });
      setMyRecords(res.items);
    } catch (error) {
      logger.error('获取我的提交记录失败', error);
      toast.error('获取记录失败，请重试');
    } finally {
      setMyRecordsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMyRecords();
  }, [fetchMyRecords]);

  const handleCreate = async (formData: RecordFormSubmitData) => {
    try {
      await urgeAuditApi.createRecord(formData);
      toast.success('提交成功，已记录到本人提交记录');
      setFormKey((k) => k + 1);
      fetchMyRecords();
    } catch (error) {
      logger.error('提交催审记录失败', error);
      toast.error('提交失败，请重试');
    }
  };

  const stats: OverviewStat[] = useMemo(() => {
    const counter: Record<AuditStatus, number> = {
      pending_first_review: 0,
      reviewing: 0,
      abnormal: 0,
    };
    for (const row of myRecords) {
      if (counter[row.auditStatus as AuditStatus] !== undefined) {
        counter[row.auditStatus as AuditStatus] += 1;
      }
    }
    return [
      {
        key: 'pending_first_review',
        label: '待一审',
        icon: Clock,
        count: counter.pending_first_review,
        tone: 'text-[hsl(32_90%_38%)] bg-[hsl(32_95%_44%/0.12)]',
      },
      {
        key: 'reviewing',
        label: '审核中',
        icon: RefreshCw,
        count: counter.reviewing,
        tone: 'text-[hsl(221_80%_46%)] bg-[hsl(221_83%_53%/0.12)]',
      },
      {
        key: 'abnormal',
        label: '报名异常',
        icon: AlertTriangle,
        count: counter.abnormal,
        tone: 'text-[hsl(0_72%_42%)] bg-[hsl(0_72%_51%/0.10)]',
      },
    ];
  }, [myRecords]);

  const handleOpenMyRecords = () => {
    setMyRecordsOpen(true);
    fetchMyRecords();
  };

  const handleExportMyRecords = () => {
    if (myRecords.length === 0) {
      toast.error('暂无记录可导出');
      return;
    }
    try {
      exportMyRecordsToExcel(myRecords);
      toast.success('导出成功');
    } catch (error) {
      logger.error('导出我的提交记录失败', error);
      toast.error('导出失败，请重试');
    }
  };

  return (
    <div className="min-h-screen w-full bg-background px-5 py-8 md:px-8 md:py-12">
      <div className="mx-auto flex max-w-[820px] flex-col gap-6">
        <div className="flex items-end justify-between gap-4">
          <div className="flex flex-col items-start gap-2 pt-1">
            <div className="flex items-center gap-3">
              <div className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <ClipboardList className="size-5" strokeWidth={1.75} />
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-foreground">
                报名催审信息录入
              </h1>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              填写并提交商品报名催审信息，提交后可查看本人记录。
            </p>
          </div>

          <CanRole roles={['admin']} fallback={null}>
            <NavLink
              to="/manage"
              className="group inline-flex shrink-0 items-center justify-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-foreground transition-colors hover:border-primary/40 hover:text-primary"
            >
              进入催审记录管理
              <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" />
            </NavLink>
          </CanRole>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
        >
          <Card className="p-6 shadow-sm md:p-8">
            <RecordForm key={formKey} onSubmit={handleCreate} />
          </Card>
        </motion.div>

        <Card className="flex flex-col gap-3 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-foreground">
              本人提交概览
              <span className="ml-2 text-xs tabular-nums text-muted-foreground">
                共 {myRecords.length} 条
              </span>
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleOpenMyRecords}
            >
              <History className="size-4" strokeWidth={1.75} />
              查看我的提交记录
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.key}
                  className="flex items-center justify-between rounded-lg border border-border bg-card px-3 py-2.5"
                >
                  <span className="inline-flex items-center gap-2 text-sm text-foreground">
                    <span
                      className={cn(
                        'flex size-6 items-center justify-center rounded-md',
                        stat.tone,
                      )}
                    >
                      <Icon className="size-3.5" strokeWidth={2} />
                    </span>
                    {stat.label}
                  </span>
                  <span className="text-base font-semibold tabular-nums text-foreground">
                    {myRecordsLoading ? '—' : stat.count}
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      <Dialog open={myRecordsOpen} onOpenChange={setMyRecordsOpen}>
        <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-[560px]">
          <DialogHeader>
            <DialogTitle>我的提交记录</DialogTitle>
            <DialogDescription>
              仅显示你本人提交的催审记录，他人记录不可见
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleExportMyRecords}
              disabled={myRecordsLoading || myRecords.length === 0}
            >
              <Download className="size-4" strokeWidth={1.75} />
              导出 Excel
            </Button>
          </div>
          <MyRecordList data={myRecords} loading={myRecordsLoading} />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UrgeAuditEntry;
