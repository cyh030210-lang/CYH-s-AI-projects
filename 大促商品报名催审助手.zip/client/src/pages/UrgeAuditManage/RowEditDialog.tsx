import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as urgeAuditApi from '@/api/urge-audit';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

import {
  AUDIT_STATUS_OPTIONS,
  NEGOTIATING_OPTIONS,
} from '../UrgeAuditWorkbench/utils';
import RemarkImageInput from '../UrgeAuditWorkbench/RemarkImageInput';

interface RowEditDialogProps {
  record: UrgeAuditRecord | null;
  onOpenChange: (open: boolean) => void;
  onSaved: (id: string) => void;
}

const RowEditDialog: React.FC<RowEditDialogProps> = ({
  record,
  onOpenChange,
  onSaved,
}) => {
  const [productId, setProductId] = useState('');
  const [isNegotiating, setIsNegotiating] = useState<'yes' | 'no'>('no');
  const [auditStatus, setAuditStatus] = useState<AuditStatus | ''>('');
  const [remark, setRemark] = useState('');
  const [remarkImages, setRemarkImages] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (record) {
      setProductId(record.productId);
      setIsNegotiating(record.isNegotiating ? 'yes' : 'no');
      setAuditStatus(record.auditStatus);
      setRemark(record.remark || '');
      setRemarkImages(record.remarkImages || []);
    }
  }, [record]);

  const handleSave = async () => {
    if (!record) return;
    if (!productId.trim()) {
      toast.error('请填写商品 ID');
      return;
    }
    if (!auditStatus) {
      toast.error('请选择审核状态');
      return;
    }
    setSaving(true);
    try {
      await urgeAuditApi.updateRow(record.id, {
        productId: productId.trim(),
        isNegotiating: isNegotiating === 'yes',
        auditStatus,
        remark,
        remarkImages,
      });
      toast.success('保存成功');
      onSaved(record.id);
      onOpenChange(false);
    } catch (err) {
      logger.error('保存商品行失败', err);
      toast.error(err instanceof Error ? err.message : '保存失败，请重试');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!record} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>编辑商品行</DialogTitle>
          <DialogDescription>
            仅修改当前商品 ID 所在行，不影响同组其他商品
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-2">
            <Label>
              商品 ID <span className="text-destructive">*</span>
            </Label>
            <Input
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              placeholder="请输入商品 ID"
              className="font-mono text-sm"
            />
          </div>

          <div className="flex flex-wrap gap-4">
            <div className="flex flex-1 flex-col gap-2">
              <Label>议价中</Label>
              <Select
                value={isNegotiating}
                onValueChange={(v) => setIsNegotiating(v as 'yes' | 'no')}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="请选择" />
                </SelectTrigger>
                <SelectContent>
                  {NEGOTIATING_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-1 flex-col gap-2">
              <Label>
                审核状态 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={auditStatus || undefined}
                onValueChange={(v) => setAuditStatus(v as AuditStatus)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="请选择审核状态" />
                </SelectTrigger>
                <SelectContent>
                  {AUDIT_STATUS_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Label>备注</Label>
            <RemarkImageInput
              value={remark}
              onValueChange={setRemark}
              images={remarkImages}
              onImagesChange={setRemarkImages}
              placeholder="填写备注（可选），可直接粘贴图片"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={saving} onClick={handleSave}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RowEditDialog;
