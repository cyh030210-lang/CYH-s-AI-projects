import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { UserPlus, Trash2 } from 'lucide-react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UserSelect } from '@/components/business-ui/user-select';
import { UserDisplay } from '@/components/business-ui/user-display/user-display';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as roleManagerApi from '@/api/role-manager';
import type { AdminUser } from '@shared/api.interface';

interface AdminManageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const AdminManageDialog: React.FC<AdminManageDialogProps> = ({
  open,
  onOpenChange,
}) => {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [adding, setAdding] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);

  const fetchAdmins = async () => {
    setLoading(true);
    try {
      const res = await roleManagerApi.listAdmins();
      setAdmins(res.userList);
    } catch (error) {
      logger.error('获取管理员列表失败', error);
      toast.error(
        error instanceof Error ? error.message : '获取管理员列表失败',
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      setSelectedIds([]);
      fetchAdmins();
    }
  }, [open]);

  const handleAdd = async () => {
    if (selectedIds.length === 0) {
      toast.error('请先选择要添加的用户');
      return;
    }
    setAdding(true);
    try {
      await roleManagerApi.addAdmins({ userIds: selectedIds });
      toast.success('已添加管理员');
      setSelectedIds([]);
      await fetchAdmins();
    } catch (error) {
      logger.error('添加管理员失败', error);
      toast.error(error instanceof Error ? error.message : '添加失败，请重试');
    } finally {
      setAdding(false);
    }
  };

  const handleRemove = async (userID: string) => {
    setRemovingId(userID);
    try {
      await roleManagerApi.removeAdmins({ userIds: [userID] });
      toast.success('已移除管理员');
      await fetchAdmins();
    } catch (error) {
      logger.error('移除管理员失败', error);
      toast.error(error instanceof Error ? error.message : '移除失败，请重试');
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>管理员设置</DialogTitle>
          <DialogDescription>
            添加或移除可访问催审记录管理页的管理员
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium text-foreground">
              添加管理员
            </span>
            <div className="flex items-start gap-2">
              <div className="flex-1">
                <UserSelect
                  multiple
                  value={selectedIds}
                  onChange={(v) => setSelectedIds(v as string[])}
                  placeholder="搜索并选择用户"
                />
              </div>
              <Button onClick={handleAdd} disabled={adding}>
                <UserPlus className="size-4" strokeWidth={1.75} />
                {adding ? '添加中...' : '添加'}
              </Button>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium text-foreground">
              当前管理员（{admins.length}）
            </span>
            {loading ? (
              <div className="py-8 text-center text-sm text-muted-foreground">
                加载中...
              </div>
            ) : admins.length === 0 ? (
              <div className="rounded-md border border-dashed border-border py-8 text-center text-sm text-muted-foreground">
                暂无管理员
              </div>
            ) : (
              <div className="flex flex-col divide-y divide-border rounded-md border border-border">
                {admins.map((admin) => (
                  <div
                    key={admin.userID}
                    className="flex items-center justify-between gap-2 px-3 py-2"
                  >
                    <UserDisplay value={admin.userID} size="small" />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-muted-foreground hover:text-destructive"
                      disabled={removingId === admin.userID}
                      onClick={() => handleRemove(admin.userID)}
                    >
                      <Trash2 className="size-4" strokeWidth={1.75} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AdminManageDialog;
