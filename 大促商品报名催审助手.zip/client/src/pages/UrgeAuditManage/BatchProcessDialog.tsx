import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as urgeAuditApi from '@/api/urge-audit';
import { PROCESS_RESULT_OPTIONS } from '@shared/api.interface';

interface BatchProcessDialogProps {
  open: boolean;
  ids: string[];
  onOpenChange: (open: boolean) => void;
  onDone: () => void;
}

const BatchProcessDialog: React.FC<BatchProcessDialogProps> = ({
  open,
  ids,
  onOpenChange,
  onDone,
}) => {
  const [processResult, setProcessResult] = useState('');
  const [processNote, setProcessNote] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setProcessResult('');
      setProcessNote('');
    }
  }, [open]);

  const handleSave = async () => {
    if (!processResult) {
      toast.error('请选择处理结果');
      return;
    }
    setSaving(true);
    try {
      const res = await urgeAuditApi.batchProcess({
        ids,
        processResult,
        processNote: processNote || undefined,
      });
      toast.success(`已标记 ${res.updated} 条记录为已处理`);
      onOpenChange(false);
      onDone();
    } catch (err) {
      logger.error('批量标记已处理失败', err);
      toast.error(err instanceof Error ? err.message : '操作失败，请重试');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle>批量标记已处理</DialogTitle>
          <DialogDescription>
            将对选中的 {ids.length} 条商品记录设置同一处理结果
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-2">
            <Label>
              处理结果 <span className="text-destructive">*</span>
            </Label>
            <Select value={processResult} onValueChange={setProcessResult}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="请选择处理结果" />
              </SelectTrigger>
              <SelectContent className="max-w-[520px]">
                {PROCESS_RESULT_OPTIONS.map((opt, idx) => (
                  <SelectItem
                    key={opt}
                    value={opt}
                    className="whitespace-normal"
                  >
                    {idx + 1}. {opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-2">
            <Label>处理说明（选填）</Label>
            <Textarea
              value={processNote}
              onChange={(e) => setProcessNote(e.target.value)}
              placeholder="统一补充处理说明"
              className="min-h-[80px]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={saving} onClick={handleSave}>
            {saving ? '提交中…' : `标记 ${ids.length} 条已处理`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BatchProcessDialog;
