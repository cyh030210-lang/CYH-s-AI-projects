import React, { useMemo, useState } from 'react';
import { toast } from 'sonner';
import {
  ClipboardList,
  UserCog,
  Tag,
  ArrowLeft,
  Inbox,
  CheckCheck,
  X,
} from 'lucide-react';
import { NavLink } from 'react-router-dom';

import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as urgeAuditApi from '@/api/urge-audit';
import type {
  AuditStatus,
  ProcessStatusFilter,
  UrgeAuditRecord,
} from '@shared/api.interface';

import {
  filterRecords,
  groupRecordsByGroupId,
} from '../UrgeAuditWorkbench/utils';
import { useUrgeAuditRecords } from '../UrgeAuditWorkbench/useUrgeAuditRecords';
import AdminManageDialog from './AdminManageDialog';
import ActivityOptionDialog from './ActivityOptionDialog';
import ProcessDialog from './ProcessDialog';
import GroupEditDialog from './GroupEditDialog';
import BatchProcessDialog from './BatchProcessDialog';
import ManageFilterBar from './ManageFilterBar';
import RecordGroupCard from './RecordGroupCard';

const UNDO_DELAY = 5000;

const UrgeAuditManage: React.FC = () => {
  const {
    data,
    loading,
    processStatus,
    highlightId,
    setProcessStatus,
    fetchList,
    flashHighlight,
  } = useUrgeAuditRecords({ initialProcessStatus: 'pending' });

  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [activityFilter, setActivityFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<AuditStatus | ''>('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [pendingDeleteIds, setPendingDeleteIds] = useState<Set<string>>(
    new Set(),
  );

  const [editingGroup, setEditingGroup] = useState<UrgeAuditRecord | null>(
    null,
  );
  const [processing, setProcessing] = useState<UrgeAuditRecord | null>(null);
  const [adminDialogOpen, setAdminDialogOpen] = useState(false);
  const [activityDialogOpen, setActivityDialogOpen] = useState(false);
  const [batchOpen, setBatchOpen] = useState(false);

  const showProcessResult = processStatus === 'processed';
  const hasActiveFilter = !!(
    search ||
    dateFrom ||
    dateTo ||
    activityFilter ||
    statusFilter
  );

  const visibleRecords = useMemo(() => {
    const filtered = filterRecords(data, {
      search,
      dateFrom,
      dateTo,
      activityId: activityFilter,
      auditStatus: statusFilter,
    });
    return filtered.filter((r) => !pendingDeleteIds.has(r.id));
  }, [
    data,
    search,
    dateFrom,
    dateTo,
    activityFilter,
    statusFilter,
    pendingDeleteIds,
  ]);

  const groups = useMemo(
    () => groupRecordsByGroupId(visibleRecords),
    [visibleRecords],
  );

  const visibleIds = useMemo(
    () => visibleRecords.map((r) => r.id),
    [visibleRecords],
  );
  const allSelected =
    visibleIds.length > 0 && visibleIds.every((id) => selectedIds.has(id));

  const refreshAfterMutation = async () => {
    setSelectedIds(new Set());
    await fetchList();
  };

  const toggleRow = (id: string, checked: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const toggleGroup = (ids: string[], checked: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => (checked ? next.add(id) : next.delete(id)));
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelectedIds(allSelected ? new Set() : new Set(visibleIds));
  };

  const handleProcessTabChange = (value: string) => {
    setProcessStatus(value as ProcessStatusFilter);
    setSelectedIds(new Set());
  };

  const handleClearFilter = () => {
    setSearch('');
    setDateFrom('');
    setDateTo('');
    setActivityFilter('');
    setStatusFilter('');
  };

  // 延迟删除：先从视图隐藏并给撤销 toast，超时未撤销才真正删除
  const scheduleDelete = (
    scope: 'row' | 'group',
    record: UrgeAuditRecord,
  ) => {
    const ids =
      scope === 'group'
        ? data.filter((r) => r.groupId === record.groupId).map((r) => r.id)
        : [record.id];
    setPendingDeleteIds((prev) => new Set([...prev, ...ids]));
    setSelectedIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => next.delete(id));
      return next;
    });

    let undone = false;
    const timer = setTimeout(async () => {
      if (undone) return;
      try {
        if (scope === 'group') {
          await urgeAuditApi.deleteGroup(record.groupId);
        } else {
          await urgeAuditApi.deleteRecord(record.id);
        }
        await fetchList();
      } catch (error) {
        logger.error('删除催审记录失败', error);
        toast.error('删除失败，请重试');
      } finally {
        setPendingDeleteIds((prev) => {
          const next = new Set(prev);
          ids.forEach((id) => next.delete(id));
          return next;
        });
      }
    }, UNDO_DELAY);

    toast(
      scope === 'group'
        ? '已删除整组记录'
        : '已删除该商品行',
      {
        action: {
          label: '撤销',
          onClick: () => {
            undone = true;
            clearTimeout(timer);
            setPendingDeleteIds((prev) => {
              const next = new Set(prev);
              ids.forEach((id) => next.delete(id));
              return next;
            });
            toast.success('已撤销删除');
          },
        },
        duration: UNDO_DELAY,
      },
    );
  };

  const handleRowSaved = async (id: string) => {
    await fetchList();
    flashHighlight(id);
  };

  const handleGroupSaved = async (groupId: string) => {
    await fetchList();
    flashHighlight(groupId);
  };

  return (
    <div className="min-h-screen w-full bg-background px-5 py-8 md:px-8 md:py-10">
      <div className="mx-auto flex max-w-[1400px] flex-col gap-7">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3.5">
            <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <ClipboardList className="size-5" strokeWidth={1.75} />
            </div>
            <div className="flex flex-col gap-0.5">
              <h1 className="text-xl font-semibold tracking-tight text-foreground">
                催审记录管理
              </h1>
              <p className="text-sm text-muted-foreground">
                查看与管理商品报名催审记录（仅管理员可见）
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <NavLink to="/">
                <ArrowLeft className="size-4" />
                返回录入页
              </NavLink>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setActivityDialogOpen(true)}
            >
              <Tag className="size-4" strokeWidth={1.75} />
              活动 ID 管理
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAdminDialogOpen(true)}
            >
              <UserCog className="size-4" strokeWidth={1.75} />
              管理员设置
            </Button>
          </div>
        </header>

        <Card className="flex flex-col gap-5 p-6 shadow-sm md:p-7">
          <div className="flex flex-col gap-4">
            <Tabs
              value={processStatus ?? 'pending'}
              onValueChange={handleProcessTabChange}
            >
              <TabsList>
                <TabsTrigger value="pending">待处理</TabsTrigger>
                <TabsTrigger value="processed">已处理</TabsTrigger>
              </TabsList>
            </Tabs>
            <ManageFilterBar
              search={search}
              dateFrom={dateFrom}
              dateTo={dateTo}
              activityId={activityFilter}
              auditStatus={statusFilter}
              onSearchChange={setSearch}
              onDateFromChange={setDateFrom}
              onDateToChange={setDateTo}
              onActivityIdChange={setActivityFilter}
              onAuditStatusChange={setStatusFilter}
              onClear={handleClearFilter}
              hasActiveFilter={hasActiveFilter}
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-y border-border py-2.5">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                className="h-8 text-xs text-muted-foreground hover:text-foreground"
                onClick={toggleSelectAll}
                disabled={visibleIds.length === 0}
              >
                {allSelected ? '取消全选' : '全选当前'}
              </Button>
              <span className="text-xs tabular-nums text-muted-foreground">
                共 {visibleRecords.length} 条
                {selectedIds.size > 0 && ` · 已选 ${selectedIds.size} 条`}
              </span>
            </div>
            {selectedIds.size > 0 && processStatus === 'pending' && (
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => setBatchOpen(true)}
                >
                  <CheckCheck className="size-4" strokeWidth={1.75} />
                  批量标记已处理
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1 text-muted-foreground"
                  onClick={() => setSelectedIds(new Set())}
                >
                  <X className="size-4" strokeWidth={1.75} />
                  清除选择
                </Button>
              </div>
            )}
          </div>

          {loading ? (
            <div className="flex flex-col gap-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="h-28 animate-pulse rounded-[10px] bg-muted/60"
                />
              ))}
            </div>
          ) : groups.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
              <div className="flex size-14 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <Inbox className="size-7" strokeWidth={1.5} />
              </div>
              <p className="text-sm font-medium text-foreground">
                {hasActiveFilter
                  ? '没有符合筛选条件的记录'
                  : processStatus === 'pending'
                    ? '暂无待处理记录'
                    : '暂无已处理记录'}
              </p>
              <p className="text-xs text-muted-foreground">
                {hasActiveFilter
                  ? '尝试调整搜索关键词或日期区间'
                  : '新提交的催审记录会显示在这里'}
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {groups.map((group) => (
                <RecordGroupCard
                  key={group.groupId}
                  group={group}
                  selectedIds={selectedIds}
                  highlightId={highlightId}
                  showProcessResult={showProcessResult}
                  onToggleRow={toggleRow}
                  onToggleGroup={toggleGroup}
                  onProcess={setProcessing}
                  onDeleteRow={(record) => scheduleDelete('row', record)}
                  onEditGroup={setEditingGroup}
                  onDeleteGroup={(record) => scheduleDelete('group', record)}
                />
              ))}
            </div>
          )}
        </Card>
      </div>

      <GroupEditDialog
        record={editingGroup}
        onOpenChange={(open) => !open && setEditingGroup(null)}
        onSaved={handleGroupSaved}
      />
      <AdminManageDialog
        open={adminDialogOpen}
        onOpenChange={setAdminDialogOpen}
      />
      <ActivityOptionDialog
        open={activityDialogOpen}
        onOpenChange={setActivityDialogOpen}
      />
      <ProcessDialog
        record={processing}
        onOpenChange={(open) => !open && setProcessing(null)}
        onSaved={handleRowSaved}
      />
      <BatchProcessDialog
        open={batchOpen}
        ids={Array.from(selectedIds)}
        onOpenChange={setBatchOpen}
        onDone={refreshAfterMutation}
      />
    </div>
  );
};

export default UrgeAuditManage;
