import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { CalendarIcon } from 'lucide-react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as urgeAuditApi from '@/api/urge-audit';
import type { UrgeAuditRecord } from '@shared/api.interface';

import { useActivityOptions } from '../UrgeAuditWorkbench/useActivityOptions';

interface GroupEditDialogProps {
  record: UrgeAuditRecord | null;
  onOpenChange: (open: boolean) => void;
  onSaved: (groupId: string) => void;
}

const GroupEditDialog: React.FC<GroupEditDialogProps> = ({
  record,
  onOpenChange,
  onSaved,
}) => {
  const [date, setDate] = useState('');
  const [applicantName, setApplicantName] = useState('');
  const [activityId, setActivityId] = useState('');
  const [saving, setSaving] = useState(false);
  const { activityIds } = useActivityOptions();

  useEffect(() => {
    if (record) {
      setDate(record.date);
      setApplicantName(record.applicantName);
      setActivityId(record.activityId);
    }
  }, [record]);

  const handleSave = async () => {
    if (!record) return;
    if (!date) {
      toast.error('请选择日期');
      return;
    }
    if (!applicantName.trim()) {
      toast.error('请填写申请人');
      return;
    }
    if (!activityId) {
      toast.error('请选择活动 ID');
      return;
    }
    setSaving(true);
    try {
      await urgeAuditApi.updateGroup(record.groupId, {
        date,
        applicantName: applicantName.trim(),
        activityId,
      });
      toast.success('保存成功');
      onSaved(record.groupId);
      onOpenChange(false);
    } catch (err) {
      logger.error('保存催审记录组失败', err);
      toast.error(err instanceof Error ? err.message : '保存失败，请重试');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!record} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>编辑整组</DialogTitle>
          <DialogDescription>
            修改日期 / 申请人 / 活动 ID，将同步应用到该组所有商品行
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-2">
            <Label>
              日期 <span className="text-destructive">*</span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'justify-start text-left font-normal',
                    !date && 'text-muted-foreground',
                  )}
                >
                  <CalendarIcon className="mr-2 size-4" strokeWidth={1.75} />
                  {date || '选择日期'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date ? new Date(date) : undefined}
                  onSelect={(day) => {
                    if (day) setDate(format(day, 'yyyy-MM-dd'));
                  }}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex flex-col gap-2">
            <Label>
              申请人 <span className="text-destructive">*</span>
            </Label>
            <Input
              value={applicantName}
              onChange={(e) => setApplicantName(e.target.value)}
              placeholder="请输入申请人姓名"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>
              活动 ID <span className="text-destructive">*</span>
            </Label>
            <Select
              value={activityId || undefined}
              onValueChange={setActivityId}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="请选择活动 ID" />
              </SelectTrigger>
              <SelectContent>
                {activityIds.map((id) => (
                  <SelectItem key={id} value={id}>
                    {id}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={saving} onClick={handleSave}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default GroupEditDialog;
