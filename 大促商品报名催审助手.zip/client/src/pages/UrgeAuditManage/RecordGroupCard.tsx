import React from 'react';
import { Wrench, Trash2, FolderPen, FolderX, ImageIcon } from 'lucide-react';

import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

import StatusBadge, {
  NegotiatingTag,
} from '../UrgeAuditWorkbench/StatusBadge';
import type { RecordGroup } from '../UrgeAuditWorkbench/utils';

interface RecordGroupCardProps {
  group: RecordGroup;
  selectedIds: Set<string>;
  highlightId: string | null;
  showProcessResult: boolean;
  onToggleRow: (id: string, checked: boolean) => void;
  onToggleGroup: (ids: string[], checked: boolean) => void;
  onProcess: (record: UrgeAuditRecord) => void;
  onDeleteRow: (record: UrgeAuditRecord) => void;
  onEditGroup: (record: UrgeAuditRecord) => void;
  onDeleteGroup: (record: UrgeAuditRecord) => void;
}

const RecordGroupCard: React.FC<RecordGroupCardProps> = ({
  group,
  selectedIds,
  highlightId,
  showProcessResult,
  onToggleRow,
  onToggleGroup,
  onProcess,
  onDeleteRow,
  onEditGroup,
  onDeleteGroup,
}) => {
  const rowIds = group.rows.map((r) => r.id);
  const selectedCount = rowIds.filter((id) => selectedIds.has(id)).length;
  const allSelected = selectedCount === rowIds.length && rowIds.length > 0;
  const partlySelected = selectedCount > 0 && !allSelected;
  const isHighlighted =
    group.groupId === highlightId ||
    group.rows.some((r) => r.id === highlightId);

  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-[10px] border border-border bg-card shadow-sm transition-colors',
        isHighlighted && 'ring-2 ring-primary/40',
      )}
    >
      <span
        className="absolute inset-y-0 left-0 w-1 bg-primary"
        aria-hidden="true"
      />

      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-muted/40 py-3 pl-5 pr-4">
        <div className="flex items-center gap-3">
          <Checkbox
            checked={allSelected ? true : partlySelected ? 'indeterminate' : false}
            onCheckedChange={(c) => onToggleGroup(rowIds, c === true)}
            aria-label={`选择 ${group.applicantName} 的整组记录`}
          />
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="text-sm font-medium tabular-nums text-foreground">
              {group.date}
            </span>
            <span className="text-sm font-semibold text-foreground">
              {group.applicantName || '-'}
            </span>
            <span className="text-xs tabular-nums text-muted-foreground">
              活动ID：{group.activityId}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
            onClick={() => onEditGroup(group.rows[0])}
            aria-label="编辑整组（日期/申请人/活动ID）"
            title="编辑整组（日期/申请人/活动ID）"
          >
            <FolderPen className="size-4" strokeWidth={1.75} />
            编辑组
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 gap-1 px-2 text-xs text-muted-foreground hover:text-destructive"
            onClick={() => onDeleteGroup(group.rows[0])}
            aria-label="删除整组"
            title="删除整组"
          >
            <FolderX className="size-4" strokeWidth={1.75} />
            删除组
          </Button>
        </div>
      </div>

      <div className="divide-y divide-border/70 pl-5">
        {group.rows.map((row) => {
          const checked = selectedIds.has(row.id);
          return (
            <div
              key={row.id}
              className={cn(
                'flex items-start gap-3 py-3 pr-4 transition-colors',
                checked && 'bg-primary/[0.03]',
                row.id === highlightId && 'bg-primary/5',
              )}
            >
              <Checkbox
                className="mt-0.5"
                checked={checked}
                onCheckedChange={(c) => onToggleRow(row.id, c === true)}
                aria-label={`选择商品 ${row.productId}`}
              />
              <div className="flex min-w-0 flex-1 flex-col gap-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span
                    className="break-all text-xs tabular-nums text-foreground"
                    style={{ fontFamily: '"Times New Roman", Times, serif' }}
                  >
                    {row.productId}
                  </span>
                  <div className="flex shrink-0 items-center gap-2">
                    {row.isNegotiating && <NegotiatingTag />}
                    <StatusBadge status={row.auditStatus as AuditStatus} />
                  </div>
                </div>

                {row.remark && (
                  <p className="line-clamp-2 text-xs text-muted-foreground">
                    备注：{row.remark}
                  </p>
                )}
                {row.remarkImages?.length > 0 && (
                  <span className="inline-flex w-fit items-center gap-1 text-xs text-muted-foreground">
                    <ImageIcon className="size-3" strokeWidth={1.75} />
                    备注 {row.remarkImages.length} 张图
                  </span>
                )}

                {showProcessResult && row.processResult && (
                  <div className="mt-1 flex flex-col gap-1 rounded-md bg-muted/60 p-2.5">
                    <span className="text-xs text-foreground">
                      <span className="text-muted-foreground">处理结果：</span>
                      {row.processResult}
                    </span>
                    {row.processNote && (
                      <span className="whitespace-pre-wrap break-words text-xs text-foreground">
                        <span className="text-muted-foreground">
                          处理说明：
                        </span>
                        {row.processNote}
                      </span>
                    )}
                    {row.processNoteImages?.length > 0 && (
                      <span className="inline-flex w-fit items-center gap-1 text-xs text-muted-foreground">
                        <ImageIcon className="size-3" strokeWidth={1.75} />
                        说明 {row.processNoteImages.length} 张图
                      </span>
                    )}
                  </div>
                )}
              </div>

              <div className="flex shrink-0 items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className="size-8 p-0 text-muted-foreground hover:text-primary"
                  onClick={() => onProcess(row)}
                  aria-label="处理该商品行"
                  title="处理"
                >
                  <Wrench className="size-4" strokeWidth={1.75} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="size-8 p-0 text-muted-foreground hover:text-destructive"
                  onClick={() => onDeleteRow(row)}
                  aria-label="删除该商品行"
                  title="删除该商品行"
                >
                  <Trash2 className="size-4" strokeWidth={1.75} />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecordGroupCard;
