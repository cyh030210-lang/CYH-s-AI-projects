import React, { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Loader2, Upload, X } from 'lucide-react';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { logger } from '@lark-apaas/client-toolkit/logger';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import * as urgeAuditApi from '@/api/urge-audit';
import {
  PROCESS_RESULT_OPTIONS,
  type UrgeAuditRecord,
} from '@shared/api.interface';

interface ProcessDialogProps {
  record: UrgeAuditRecord | null;
  onOpenChange: (open: boolean) => void;
  onSaved: (id: string) => void;
}

const RESULT_PLACEHOLDER = '__none__';

const ProcessDialog: React.FC<ProcessDialogProps> = ({
  record,
  onOpenChange,
  onSaved,
}) => {
  const [processResult, setProcessResult] = useState('');
  const [processNote, setProcessNote] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (record) {
      setProcessResult(record.processResult || '');
      setProcessNote(record.processNote || '');
      setImages(record.processNoteImages || []);
    }
  }, [record]);

  const uploadFiles = async (files: File[]) => {
    const imageFiles = files.filter((f) => f.type.startsWith('image/'));
    if (imageFiles.length === 0) return;
    setUploading(true);
    try {
      const dataloom = await getDataloom();
      const bucketId = getDefaultBucketId();
      const uploaded: string[] = [];
      for (const file of imageFiles) {
        const { data, error } = await dataloom.storage
          .from(bucketId)
          .uploadFile(file);
        if (error || !data) {
          throw new Error(error?.message || '图片上传失败');
        }
        uploaded.push(data.download_url);
      }
      setImages((prev) => [...prev, ...uploaded]);
      toast.success(`已添加 ${uploaded.length} 张图片`);
    } catch (err) {
      logger.error('上传处理说明图片失败', err);
      toast.error(err instanceof Error ? err.message : '图片上传失败');
    } finally {
      setUploading(false);
    }
  };

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (fileInputRef.current) fileInputRef.current.value = '';
    await uploadFiles(files);
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = Array.from(e.clipboardData?.items ?? []);
    const files = items
      .filter((item) => item.kind === 'file' && item.type.startsWith('image/'))
      .map((item) => item.getAsFile())
      .filter((f): f is File => f !== null);
    if (files.length > 0) {
      e.preventDefault();
      await uploadFiles(files);
    }
  };

  const removeImage = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!record) return;
    setSaving(true);
    try {
      await urgeAuditApi.updateProcess(record.id, {
        processResult,
        processNote,
        processNoteImages: images,
      });
      toast.success('保存成功');
      onSaved(record.id);
      onOpenChange(false);
    } catch (err) {
      logger.error('保存处理结果失败', err);
      toast.error(err instanceof Error ? err.message : '保存失败，请重试');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={!!record} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle>处理记录</DialogTitle>
          <DialogDescription>
            填写处理结果与处理说明，处理说明支持上传或粘贴图片
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-2">
          <div className="flex flex-col gap-2">
            <Label>处理结果</Label>
            <Select
              value={processResult || RESULT_PLACEHOLDER}
              onValueChange={(v) =>
                setProcessResult(v === RESULT_PLACEHOLDER ? '' : v)
              }
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="请选择处理结果" />
              </SelectTrigger>
              <SelectContent className="max-w-[520px]">
                {PROCESS_RESULT_OPTIONS.map((opt, idx) => (
                  <SelectItem
                    key={opt}
                    value={opt}
                    className="whitespace-normal"
                  >
                    {idx + 1}. {opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-2">
            <Label>处理说明</Label>
            <Textarea
              value={processNote}
              onChange={(e) => setProcessNote(e.target.value)}
              onPaste={handlePaste}
              placeholder="填写处理说明，可在此处直接粘贴图片"
              className="min-h-[100px]"
            />
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-end">
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={uploading}
                onClick={() => fileInputRef.current?.click()}
              >
                {uploading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Upload className="size-4" strokeWidth={1.75} />
                )}
                上传图片
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleFileInput}
              />
            </div>
            {images.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {images.map((url, idx) => (
                  <div
                    key={`${url}-${idx}`}
                    className="group relative aspect-square overflow-hidden rounded-md border border-border"
                  >
                    <img
                      src={url}
                      alt={`处理说明图片 ${idx + 1}`}
                      className="size-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => removeImage(idx)}
                      className="absolute right-1 top-1 rounded-full bg-black/60 p-0.5 text-white opacity-0 transition-opacity group-hover:opacity-100"
                    >
                      <X className="size-3.5" strokeWidth={2} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={saving || uploading} onClick={handleSave}>
            {saving ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ProcessDialog;
