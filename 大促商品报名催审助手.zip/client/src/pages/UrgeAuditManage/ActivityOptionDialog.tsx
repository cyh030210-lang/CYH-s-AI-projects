import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Plus, Trash2 } from 'lucide-react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { logger } from '@lark-apaas/client-toolkit/logger';
import * as activityOptionApi from '@/api/activity-option';
import type { ActivityOption } from '@shared/api.interface';

interface ActivityOptionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged?: () => void;
}

const ActivityOptionDialog: React.FC<ActivityOptionDialogProps> = ({
  open,
  onOpenChange,
  onChanged,
}) => {
  const [options, setOptions] = useState<ActivityOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [newId, setNewId] = useState('');
  const [adding, setAdding] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);

  const fetchOptions = async () => {
    setLoading(true);
    try {
      const res = await activityOptionApi.listActivityOptions();
      setOptions(res.items);
    } catch (error) {
      logger.error('获取活动 ID 列表失败', error);
      toast.error(
        error instanceof Error ? error.message : '获取活动 ID 列表失败',
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      setNewId('');
      fetchOptions();
    }
  }, [open]);

  const handleAdd = async () => {
    const activityId = newId.trim();
    if (!activityId) {
      toast.error('请输入活动 ID');
      return;
    }
    setAdding(true);
    try {
      await activityOptionApi.createActivityOption({ activityId });
      toast.success('已新增活动 ID');
      setNewId('');
      await fetchOptions();
      onChanged?.();
    } catch (error) {
      logger.error('新增活动 ID 失败', error);
      toast.error(error instanceof Error ? error.message : '新增失败，请重试');
    } finally {
      setAdding(false);
    }
  };

  const handleRemove = async (id: string) => {
    setRemovingId(id);
    try {
      await activityOptionApi.deleteActivityOption(id);
      toast.success('已删除活动 ID');
      await fetchOptions();
      onChanged?.();
    } catch (error) {
      logger.error('删除活动 ID 失败', error);
      toast.error(error instanceof Error ? error.message : '删除失败，请重试');
    } finally {
      setRemovingId(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>活动 ID 管理</DialogTitle>
          <DialogDescription>
            新增或删除录入与筛选下拉中可选的活动 ID
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium text-foreground">
              新增活动 ID
            </span>
            <div className="flex items-start gap-2">
              <Input
                value={newId}
                onChange={(e) => setNewId(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAdd();
                  }
                }}
                placeholder="请输入活动 ID"
                className="flex-1 tabular-nums"
              />
              <Button onClick={handleAdd} disabled={adding}>
                <Plus className="size-4" strokeWidth={1.75} />
                {adding ? '添加中...' : '添加'}
              </Button>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="text-sm font-medium text-foreground">
              当前活动 ID（{options.length}）
            </span>
            {loading ? (
              <div className="py-8 text-center text-sm text-muted-foreground">
                加载中...
              </div>
            ) : options.length === 0 ? (
              <div className="rounded-md border border-dashed border-border py-8 text-center text-sm text-muted-foreground">
                暂无活动 ID
              </div>
            ) : (
              <div className="flex flex-col divide-y divide-border rounded-md border border-border">
                {options.map((option) => (
                  <div
                    key={option.id}
                    className="flex items-center justify-between gap-2 px-3 py-2"
                  >
                    <span className="break-all text-sm tabular-nums text-foreground">
                      {option.activityId}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0 text-muted-foreground hover:text-destructive"
                      disabled={removingId === option.id}
                      onClick={() => handleRemove(option.id)}
                      aria-label={`删除活动 ID ${option.activityId}`}
                    >
                      <Trash2 className="size-4" strokeWidth={1.75} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ActivityOptionDialog;
