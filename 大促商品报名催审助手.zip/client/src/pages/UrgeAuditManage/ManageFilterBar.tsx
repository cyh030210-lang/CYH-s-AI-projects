import React from 'react';
import { format } from 'date-fns';
import { Search, CalendarIcon, X } from 'lucide-react';

import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import type { AuditStatus } from '@shared/api.interface';

import { AUDIT_STATUS_OPTIONS } from '../UrgeAuditWorkbench/utils';
import { useActivityOptions } from '../UrgeAuditWorkbench/useActivityOptions';

const ALL_SENTINEL = '__all__';

interface ManageFilterBarProps {
  search: string;
  dateFrom: string;
  dateTo: string;
  activityId: string;
  auditStatus: AuditStatus | '';
  onSearchChange: (value: string) => void;
  onDateFromChange: (value: string) => void;
  onDateToChange: (value: string) => void;
  onActivityIdChange: (value: string) => void;
  onAuditStatusChange: (value: AuditStatus | '') => void;
  onClear: () => void;
  hasActiveFilter: boolean;
}

const DateField: React.FC<{
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}> = ({ value, placeholder, onChange }) => (
  <Popover>
    <PopoverTrigger asChild>
      <Button
        variant="outline"
        size="sm"
        className={cn(
          'h-9 justify-start gap-2 font-normal tabular-nums',
          !value && 'text-muted-foreground',
        )}
      >
        <CalendarIcon className="size-4" strokeWidth={1.75} />
        {value || placeholder}
      </Button>
    </PopoverTrigger>
    <PopoverContent className="w-auto p-0" align="start">
      <Calendar
        mode="single"
        selected={value ? new Date(value) : undefined}
        onSelect={(day) => onChange(day ? format(day, 'yyyy-MM-dd') : '')}
      />
    </PopoverContent>
  </Popover>
);

const ManageFilterBar: React.FC<ManageFilterBarProps> = ({
  search,
  dateFrom,
  dateTo,
  activityId,
  auditStatus,
  onSearchChange,
  onDateFromChange,
  onDateToChange,
  onActivityIdChange,
  onAuditStatusChange,
  onClear,
  hasActiveFilter,
}) => {
  const { activityIds } = useActivityOptions();
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="relative min-w-[220px] flex-1">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
          strokeWidth={1.75}
        />
        <Input
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="搜索商品 ID 或申请人"
          className="h-9 pl-9"
          aria-label="搜索商品 ID 或申请人"
        />
      </div>

      <Select
        value={activityId || ALL_SENTINEL}
        onValueChange={(v) =>
          onActivityIdChange(v === ALL_SENTINEL ? '' : v)
        }
      >
        <SelectTrigger
          className="h-9 w-[200px] tabular-nums"
          aria-label="按活动 ID 筛选"
        >
          <SelectValue placeholder="全部活动 ID" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL_SENTINEL}>全部活动 ID</SelectItem>
          {activityIds.map((id) => (
            <SelectItem key={id} value={id} className="tabular-nums">
              {id}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={auditStatus || ALL_SENTINEL}
        onValueChange={(v) =>
          onAuditStatusChange(v === ALL_SENTINEL ? '' : (v as AuditStatus))
        }
      >
        <SelectTrigger
          className="h-9 w-[150px]"
          aria-label="按审核状态筛选"
        >
          <SelectValue placeholder="全部审核状态" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL_SENTINEL}>全部审核状态</SelectItem>
          {AUDIT_STATUS_OPTIONS.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="flex items-center gap-2">
        <DateField
          value={dateFrom}
          placeholder="开始日期"
          onChange={onDateFromChange}
        />
        <span className="text-sm text-muted-foreground">至</span>
        <DateField
          value={dateTo}
          placeholder="结束日期"
          onChange={onDateToChange}
        />
      </div>
      {hasActiveFilter && (
        <Button
          variant="ghost"
          size="sm"
          className="h-9 gap-1 text-muted-foreground hover:text-foreground"
          onClick={onClear}
        >
          <X className="size-4" strokeWidth={1.75} />
          清除筛选
        </Button>
      )}
    </div>
  );
};

export default ManageFilterBar;
