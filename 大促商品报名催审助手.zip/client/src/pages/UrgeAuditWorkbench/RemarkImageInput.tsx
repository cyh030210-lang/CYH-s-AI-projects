import React, { useRef, useState } from 'react';
import { toast } from 'sonner';
import { Loader2, Upload, X } from 'lucide-react';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';
import { logger } from '@lark-apaas/client-toolkit/logger';

import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface RemarkImageInputProps {
  value: string;
  onValueChange: (value: string) => void;
  images: string[];
  onImagesChange: (images: string[]) => void;
  placeholder?: string;
  className?: string;
}

const RemarkImageInput: React.FC<RemarkImageInputProps> = ({
  value,
  onValueChange,
  images,
  onImagesChange,
  placeholder,
  className,
}) => {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadFiles = async (files: File[]) => {
    const imageFiles = files.filter((f) => f.type.startsWith('image/'));
    if (imageFiles.length === 0) return;
    setUploading(true);
    try {
      const dataloom = await getDataloom();
      const bucketId = getDefaultBucketId();
      const uploaded: string[] = [];
      for (const file of imageFiles) {
        const { data, error } = await dataloom.storage
          .from(bucketId)
          .uploadFile(file);
        if (error || !data) {
          throw new Error(error?.message || '图片上传失败');
        }
        uploaded.push(data.download_url);
      }
      onImagesChange([...images, ...uploaded]);
      toast.success(`已添加 ${uploaded.length} 张图片`);
    } catch (err) {
      logger.error('上传备注图片失败', err);
      toast.error(err instanceof Error ? err.message : '图片上传失败');
    } finally {
      setUploading(false);
    }
  };

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (fileInputRef.current) fileInputRef.current.value = '';
    await uploadFiles(files);
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = Array.from(e.clipboardData?.items ?? []);
    const files = items
      .filter((item) => item.kind === 'file' && item.type.startsWith('image/'))
      .map((item) => item.getAsFile())
      .filter((f): f is File => f !== null);
    if (files.length > 0) {
      e.preventDefault();
      await uploadFiles(files);
    }
  };

  const removeImage = (idx: number) => {
    onImagesChange(images.filter((_, i) => i !== idx));
  };

  return (
    <div className={className}>
      <div className="relative">
        <Textarea
          value={value}
          onChange={(e) => onValueChange(e.target.value)}
          onPaste={handlePaste}
          placeholder={placeholder}
          className="min-h-20 resize-y pr-24"
        />
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={uploading}
          onClick={() => fileInputRef.current?.click()}
          className="absolute right-1.5 top-1.5 h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground"
          title="上传图片"
        >
          {uploading ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Upload className="size-4" strokeWidth={1.75} />
          )}
          上传图片
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={handleFileInput}
        />
      </div>
      {images.length > 0 && (
        <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-6">
          {images.map((url, idx) => (
            <div
              key={`${url}-${idx}`}
              className="group relative aspect-square overflow-hidden rounded-md border border-border"
            >
              <img
                src={url}
                alt={`备注图片 ${idx + 1}`}
                className="size-full object-cover"
              />
              <button
                type="button"
                onClick={() => removeImage(idx)}
                className="absolute right-1 top-1 rounded-full bg-black/60 p-0.5 text-white opacity-0 transition-opacity group-hover:opacity-100"
              >
                <X className="size-3.5" strokeWidth={2} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RemarkImageInput;
