import * as XLSX from 'xlsx';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

import { AUDIT_STATUS_LABEL_MAP } from './utils';

export function exportMyRecordsToExcel(data: UrgeAuditRecord[]): void {
  const rows = data.map((row) => ({
    日期: row.date,
    申请人: row.applicantName,
    活动ID: row.activityId,
    商品ID: row.productId,
    是否议价中: row.isNegotiating ? '是' : '否',
    审核状态:
      AUDIT_STATUS_LABEL_MAP[row.auditStatus as AuditStatus] ??
      row.auditStatus,
    备注: row.remark,
    备注图片: (row.remarkImages ?? []).join('\n'),
    处理结果: row.processResult,
    处理说明: row.processNote,
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet['!cols'] = [
    { wch: 12 },
    { wch: 14 },
    { wch: 22 },
    { wch: 22 },
    { wch: 12 },
    { wch: 12 },
    { wch: 28 },
    { wch: 30 },
    { wch: 28 },
    { wch: 28 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, '我的提交记录');

  const now = new Date();
  const pad = (n: number): string => String(n).padStart(2, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(
    now.getDate(),
  )}_${pad(now.getHours())}${pad(now.getMinutes())}`;

  XLSX.writeFile(workbook, `我的催审提交记录_${stamp}.xlsx`);
}
