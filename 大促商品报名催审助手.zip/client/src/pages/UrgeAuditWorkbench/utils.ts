import type { LucideIcon } from 'lucide-react';
import { AlertTriangle, Clock, RefreshCw } from 'lucide-react';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

export const AUDIT_STATUS_OPTIONS: { value: AuditStatus; label: string }[] = [
  { value: 'abnormal', label: '报名异常' },
  { value: 'pending_first_review', label: '待一审' },
  { value: 'reviewing', label: '审核中' },
];

export const NEGOTIATING_OPTIONS: { value: 'yes' | 'no'; label: string }[] = [
  { value: 'yes', label: '议价中' },
  { value: 'no', label: '非议价中' },
];

export const AUDIT_STATUS_LABEL_MAP: Record<AuditStatus, string> = {
  abnormal: '报名异常',
  pending_first_review: '待一审',
  reviewing: '审核中',
};

export const AUDIT_STATUS_BADGE_CLASS: Record<AuditStatus, string> = {
  abnormal: 'bg-[hsl(0_72%_51%/0.10)] text-[hsl(0_72%_42%)]',
  pending_first_review: 'bg-[hsl(32_95%_44%/0.12)] text-[hsl(32_90%_38%)]',
  reviewing: 'bg-[hsl(221_83%_53%/0.12)] text-[hsl(221_80%_46%)]',
};

export const AUDIT_STATUS_ICON_MAP: Record<AuditStatus, LucideIcon> = {
  abnormal: AlertTriangle,
  pending_first_review: Clock,
  reviewing: RefreshCw,
};

export function formatDate(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function todayString(): string {
  return formatDate(new Date());
}

export function parseProductIds(input: string): string[] {
  const parts = input.split(/[\n,，\s]+/);
  const seen = new Set<string>();
  const result: string[] = [];
  for (const raw of parts) {
    const trimmed = raw.trim();
    if (trimmed && !seen.has(trimmed)) {
      seen.add(trimmed);
      result.push(trimmed);
    }
  }
  return result;
}

export interface RecordGroup {
  groupId: string;
  date: string;
  applicantName: string;
  activityId: string;
  isNegotiating: boolean;
  auditStatus: AuditStatus;
  rows: UrgeAuditRecord[];
}

/** 按 groupId 聚合扁平商品行，保持首次出现顺序 */
export function groupRecordsByGroupId(
  data: UrgeAuditRecord[],
): RecordGroup[] {
  const map = new Map<string, RecordGroup>();
  const order: string[] = [];
  for (const row of data) {
    let group = map.get(row.groupId);
    if (!group) {
      group = {
        groupId: row.groupId,
        date: row.date,
        applicantName: row.applicantName,
        activityId: row.activityId,
        isNegotiating: row.isNegotiating,
        auditStatus: row.auditStatus,
        rows: [],
      };
      map.set(row.groupId, group);
      order.push(row.groupId);
    }
    group.rows.push(row);
  }
  return order.map((id) => map.get(id) as RecordGroup);
}

export interface RecordFilterOptions {
  search?: string;
  dateFrom?: string;
  dateTo?: string;
  activityId?: string;
  auditStatus?: AuditStatus | '';
}

/** 前端筛选：按商品ID/申请人模糊匹配 + 日期区间 + 活动ID + 审核状态 */
export function filterRecords(
  data: UrgeAuditRecord[],
  options: RecordFilterOptions,
): UrgeAuditRecord[] {
  const keyword = (options.search ?? '').trim().toLowerCase();
  const { dateFrom, dateTo, activityId, auditStatus } = options;
  return data.filter((row) => {
    if (keyword) {
      const haystack = `${row.productId} ${row.applicantName}`.toLowerCase();
      if (!haystack.includes(keyword)) return false;
    }
    if (dateFrom && row.date < dateFrom) return false;
    if (dateTo && row.date > dateTo) return false;
    if (activityId && row.activityId !== activityId) return false;
    if (auditStatus && row.auditStatus !== auditStatus) return false;
    return true;
  });
}
