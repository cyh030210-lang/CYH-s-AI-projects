import { useCallback, useEffect, useRef, useState } from 'react';

import * as urgeAuditApi from '@/api/urge-audit';
import type {
  ProcessStatusFilter,
  UrgeAuditRecord,
} from '@shared/api.interface';

interface UseUrgeAuditRecordsOptions {
  initialProcessStatus?: ProcessStatusFilter;
}

const FETCH_PAGE_SIZE = 500;

export function useUrgeAuditRecords(
  options: UseUrgeAuditRecordsOptions = {},
) {
  const { initialProcessStatus } = options;
  const [data, setData] = useState<UrgeAuditRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [processStatus, setProcessStatus] = useState<
    ProcessStatusFilter | undefined
  >(initialProcessStatus);
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const highlightTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchList = useCallback(async () => {
    setLoading(true);
    try {
      const res = await urgeAuditApi.listRecords({
        processStatus,
        page: 1,
        pageSize: FETCH_PAGE_SIZE,
      });
      setData(res.items);
      setTotal(res.total);
    } finally {
      setLoading(false);
    }
  }, [processStatus]);

  useEffect(() => {
    fetchList();
  }, [fetchList]);

  useEffect(() => {
    return () => {
      if (highlightTimer.current) clearTimeout(highlightTimer.current);
    };
  }, []);

  const flashHighlight = useCallback((id: string) => {
    setHighlightId(id);
    if (highlightTimer.current) clearTimeout(highlightTimer.current);
    highlightTimer.current = setTimeout(() => setHighlightId(null), 1200);
  }, []);

  return {
    data,
    total,
    loading,
    processStatus,
    highlightId,
    setProcessStatus,
    fetchList,
    flashHighlight,
  };
}
