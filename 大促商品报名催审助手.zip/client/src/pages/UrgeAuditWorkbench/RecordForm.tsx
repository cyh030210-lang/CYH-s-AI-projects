import React from 'react';
import { useFieldArray, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon, Plus, Trash2, Package } from 'lucide-react';
import { useAutoAnimate } from '@formkit/auto-animate/react';

import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import type { AuditStatus, UrgeAuditItem } from '@shared/api.interface';

import {
  AUDIT_STATUS_OPTIONS,
  NEGOTIATING_OPTIONS,
  parseProductIds,
  todayString,
} from './utils';
import { useActivityOptions } from './useActivityOptions';
import RemarkImageInput from './RemarkImageInput';

const itemSchema = z.object({
  activityId: z.string().min(1, '请选择活动 ID'),
  productIdsRaw: z
    .string()
    .min(1, '请输入商品 ID')
    .refine((v) => parseProductIds(v).length > 0, '至少需要一个有效商品 ID'),
});

const formSchema = z.object({
  date: z.string().min(1, '请选择日期'),
  applicantName: z.string().min(1, '请填写申请人'),
  items: z.array(itemSchema).min(1, '至少需要一组活动与商品'),
  isNegotiating: z.enum(['yes', 'no'], {
    errorMap: () => ({ message: '请选择是否议价中' }),
  }),
  auditStatus: z.enum(['abnormal', 'pending_first_review', 'reviewing'], {
    errorMap: () => ({ message: '请选择当前审核状态' }),
  }),
  remark: z.string(),
  remarkImages: z.array(z.string()),
}).superRefine((values, ctx) => {
  if (values.isNegotiating === 'yes') {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['isNegotiating'],
      message: '商品高价，议价中，商家响应前不可催审',
    });
  }
});

export type RecordFormValues = z.infer<typeof formSchema>;

export interface RecordFormSubmitData {
  date: string;
  applicantName: string;
  items: UrgeAuditItem[];
  isNegotiating: boolean;
  auditStatus: AuditStatus;
  remark: string;
  remarkImages: string[];
}

interface RecordFormProps {
  defaultValues?: Partial<RecordFormValues>;
  submitText?: string;
  onSubmit: (data: RecordFormSubmitData) => Promise<void> | void;
}

const buildDefaultValues = (
  override?: Partial<RecordFormValues>,
): RecordFormValues => ({
  date: override?.date ?? todayString(),
  applicantName: override?.applicantName ?? '',
  items:
    override?.items && override.items.length > 0
      ? override.items
      : [{ activityId: '', productIdsRaw: '' }],
  isNegotiating: override?.isNegotiating ?? ('' as 'yes' | 'no'),
  auditStatus: override?.auditStatus ?? ('' as AuditStatus),
  remark: override?.remark ?? '',
  remarkImages: override?.remarkImages ?? [],
});

const RecordForm: React.FC<RecordFormProps> = ({
  defaultValues,
  submitText = '提交',
  onSubmit,
}) => {
  const form = useForm<RecordFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: buildDefaultValues(defaultValues),
    mode: 'onBlur',
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'items',
  });

  const { activityIds } = useActivityOptions();

  const [itemsRef] = useAutoAnimate<HTMLDivElement>();

  const isSubmitting = form.formState.isSubmitting;

  const handleSubmit = async (values: RecordFormValues) => {
    await onSubmit({
      date: values.date,
      applicantName: values.applicantName.trim(),
      items: values.items.map((item) => ({
        activityId: item.activityId,
        productIds: parseProductIds(item.productIdsRaw),
      })),
      isNegotiating: values.isNegotiating === 'yes',
      auditStatus: values.auditStatus,
      remark: values.remark,
      remarkImages: values.remarkImages,
    });
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit)}
        className="space-y-6"
        noValidate
      >
        <div className="flex flex-wrap gap-4">
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem className="flex flex-1 flex-col">
                <FormLabel>
                  日期 <span className="text-destructive">*</span>
                </FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          'justify-start text-left font-normal tabular-nums',
                          !field.value && 'text-muted-foreground',
                        )}
                      >
                        <CalendarIcon
                          className="mr-2 size-4"
                          strokeWidth={1.75}
                        />
                        {field.value || '选择日期'}
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={
                        field.value ? new Date(field.value) : undefined
                      }
                      onSelect={(day) => {
                        if (day) field.onChange(format(day, 'yyyy-MM-dd'));
                      }}
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="applicantName"
            render={({ field }) => (
              <FormItem className="flex flex-1 flex-col">
                <FormLabel>
                  申请人 <span className="text-destructive">*</span>
                </FormLabel>
                <FormControl>
                  <Input {...field} placeholder="请输入申请人姓名" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <FormLabel className="text-sm font-medium">
              活动与商品 <span className="text-destructive">*</span>
            </FormLabel>
            <span className="text-xs text-muted-foreground">
              共 {fields.length} 组
            </span>
          </div>

          <div ref={itemsRef} className="space-y-3">
            {fields.map((fieldItem, index) => (
              <div
                key={fieldItem.id}
                className="relative rounded-lg border border-dashed border-border bg-muted/30 p-4"
              >
                <div className="mb-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Package className="size-3.5" strokeWidth={1.75} />
                    商品组 {index + 1}
                  </span>
                  {fields.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-destructive"
                      onClick={() => remove(index)}
                      aria-label={`删除商品组 ${index + 1}`}
                    >
                      <Trash2 className="size-3.5" strokeWidth={1.75} />
                      删除
                    </Button>
                  )}
                </div>
                <div className="flex flex-col gap-3">
                  <FormField
                    control={form.control}
                    name={`items.${index}.activityId`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-muted-foreground">
                          活动 ID
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="w-full tabular-nums">
                              <SelectValue placeholder="请选择活动 ID" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {activityIds.map((id) => (
                              <SelectItem
                                key={id}
                                value={id}
                                className="tabular-nums"
                              >
                                {id}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name={`items.${index}.productIdsRaw`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs text-muted-foreground">
                          商品 ID
                        </FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            className="font-mono text-sm tabular-nums"
                            placeholder="商品 ID，可用逗号或换行分隔多个"
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">
                          支持逗号 / 空格 / 换行分隔多个商品 ID，自动去重
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            ))}
          </div>

          <Button
            type="button"
            variant="outline"
            size="sm"
            className="w-full border-dashed"
            onClick={() => append({ activityId: '', productIdsRaw: '' })}
          >
            <Plus className="mr-1 size-4" strokeWidth={1.75} />
            新增一组
          </Button>
        </div>

        <div className="flex flex-wrap items-start gap-4">
          <FormField
            control={form.control}
            name="auditStatus"
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormLabel>
                  当前审核状态 <span className="text-destructive">*</span>
                </FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择审核状态" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {AUDIT_STATUS_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  新提交一般默认「待一审」
                </p>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isNegotiating"
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormLabel>
                  是否议价中 <span className="text-destructive">*</span>
                </FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择是否议价中" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {NEGOTIATING_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="remark"
          render={({ field }) => (
            <FormItem>
              <FormLabel>其他备注信息</FormLabel>
              <FormControl>
                <RemarkImageInput
                  value={field.value}
                  onValueChange={field.onChange}
                  images={form.watch('remarkImages')}
                  onImagesChange={(imgs) =>
                    form.setValue('remarkImages', imgs)
                  }
                  placeholder="补充特殊情况、异常说明、沟通记录等，可直接粘贴图片"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          disabled={isSubmitting}
          className="h-11 w-full text-[15px]"
        >
          {isSubmitting ? '提交中…' : submitText}
        </Button>
      </form>
    </Form>
  );
};

export default RecordForm;
