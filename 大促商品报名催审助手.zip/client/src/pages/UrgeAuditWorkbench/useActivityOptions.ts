import { useCallback, useEffect, useState } from 'react';

import { logger } from '@lark-apaas/client-toolkit/logger';
import * as activityOptionApi from '@/api/activity-option';
import type { ActivityOption } from '@shared/api.interface';

export interface UseActivityOptionsResult {
  options: ActivityOption[];
  activityIds: string[];
  loading: boolean;
  refresh: () => Promise<void>;
}

export function useActivityOptions(): UseActivityOptionsResult {
  const [options, setOptions] = useState<ActivityOption[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await activityOptionApi.listActivityOptions();
      setOptions(res.items);
    } catch (error) {
      logger.error('加载活动 ID 列表失败', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return {
    options,
    activityIds: options.map((item) => item.activityId),
    loading,
    refresh,
  };
}
