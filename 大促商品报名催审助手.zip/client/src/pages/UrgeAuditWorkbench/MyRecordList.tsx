import React from 'react';
import type { AuditStatus, UrgeAuditRecord } from '@shared/api.interface';

import { groupRecordsByGroupId } from './utils';
import StatusBadge, { NegotiatingTag } from './StatusBadge';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

interface MyRecordListProps {
  data: UrgeAuditRecord[];
  loading: boolean;
}

const ProcessBlock: React.FC<{ row: UrgeAuditRecord }> = ({ row }) => {
  if (
    !row.processResult &&
    !row.processNote &&
    !(row.processNoteImages?.length > 0)
  ) {
    return null;
  }
  return (
    <div className="mt-2 flex flex-col gap-1.5 rounded-md bg-muted/60 p-3">
      {row.processResult && (
        <div className="flex gap-1 text-xs">
          <span className="shrink-0 text-muted-foreground">处理结果：</span>
          <span className="text-foreground">{row.processResult}</span>
        </div>
      )}
      {row.processNote && (
        <div className="flex gap-1 text-xs">
          <span className="shrink-0 text-muted-foreground">处理说明：</span>
          <span className="whitespace-pre-wrap break-words text-foreground">
            {row.processNote}
          </span>
        </div>
      )}
      {row.processNoteImages?.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {row.processNoteImages.map((url, idx) => (
            <UniversalLink
              key={`${url}-${idx}`}
              to={url}
              target="_blank"
              rel="noopener noreferrer"
              className="block size-16 overflow-hidden rounded-sm border border-border"
            >
              <img
                src={url}
                alt={`处理说明图片 ${idx + 1}`}
                className="size-full object-cover"
              />
            </UniversalLink>
          ))}
        </div>
      )}
    </div>
  );
};

const MyRecordList: React.FC<MyRecordListProps> = ({ data, loading }) => {
  if (loading) {
    return (
      <div className="py-10 text-center text-sm text-muted-foreground">
        加载中...
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="py-10 text-center text-sm text-muted-foreground">
        暂无提交记录
      </div>
    );
  }

  const groups = groupRecordsByGroupId(data);

  return (
    <div className="flex flex-col gap-3">
      {groups.map((group) => (
        <div
          key={group.groupId}
          className="rounded-lg border border-border bg-card p-4 shadow-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <span className="text-sm tabular-nums text-foreground">
                {group.date}
              </span>
              <span className="text-sm font-medium text-foreground">
                {group.applicantName || '-'}
              </span>
            </div>
            <span className="text-xs tabular-nums text-muted-foreground">
              活动ID：{group.activityId}
            </span>
          </div>

          <div className="mt-3 flex flex-col divide-y divide-border/70">
            {group.rows.map((row) => (
              <div key={row.id} className="py-2.5 first:pt-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="break-all text-xs tabular-nums text-foreground">
                    商品ID：{row.productId}
                  </span>
                  <div className="flex shrink-0 items-center gap-2">
                    {row.isNegotiating && <NegotiatingTag />}
                    <StatusBadge status={row.auditStatus as AuditStatus} />
                  </div>
                </div>
                {row.remark && (
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    备注：{row.remark}
                  </p>
                )}
                {row.remarkImages?.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-2">
                    {row.remarkImages.map((url, idx) => (
                      <UniversalLink
                        key={`${url}-${idx}`}
                        to={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block size-16 overflow-hidden rounded-sm border border-border"
                      >
                        <img
                          src={url}
                          alt={`备注图片 ${idx + 1}`}
                          className="size-full object-cover"
                        />
                      </UniversalLink>
                    ))}
                  </div>
                )}
                <ProcessBlock row={row} />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MyRecordList;
