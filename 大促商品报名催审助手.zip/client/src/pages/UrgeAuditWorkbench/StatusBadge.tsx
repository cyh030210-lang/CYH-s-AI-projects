import React from 'react';
import { cn } from '@/lib/utils';
import type { AuditStatus } from '@shared/api.interface';

import {
  AUDIT_STATUS_BADGE_CLASS,
  AUDIT_STATUS_ICON_MAP,
  AUDIT_STATUS_LABEL_MAP,
} from './utils';

interface StatusBadgeProps {
  status: AuditStatus;
  className?: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const Icon = AUDIT_STATUS_ICON_MAP[status];
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        AUDIT_STATUS_BADGE_CLASS[status],
        className,
      )}
    >
      <Icon className="size-3" strokeWidth={2} aria-hidden="true" />
      {AUDIT_STATUS_LABEL_MAP[status]}
    </span>
  );
};

export const NegotiatingTag: React.FC<{ className?: string }> = ({
  className,
}) => (
  <span
    className={cn(
      'inline-flex items-center rounded-md border border-warning/30 bg-warning/10 px-1.5 py-0.5 text-xs font-medium text-[hsl(32_90%_38%)]',
      className,
    )}
  >
    议价中
  </span>
);

export default StatusBadge;
