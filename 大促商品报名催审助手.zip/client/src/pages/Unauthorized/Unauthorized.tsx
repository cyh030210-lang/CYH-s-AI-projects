import React from 'react';
import { ShieldAlert } from 'lucide-react';
import { NavLink } from 'react-router-dom';

import { Button } from '@/components/ui/button';

const Unauthorized: React.FC = () => {
  return (
    <div className="flex min-h-screen w-full flex-col items-center justify-center gap-5 bg-background px-6 text-center">
      <div className="flex size-14 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
        <ShieldAlert className="size-7" strokeWidth={1.5} />
      </div>
      <div className="flex flex-col gap-2">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          无访问权限
        </h1>
        <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
          催审记录管理仅对授权管理员开放，你当前没有访问权限，请联系管理员分配角色。
        </p>
      </div>
      <Button asChild variant="outline">
        <NavLink to="/">返回信息录入页</NavLink>
      </Button>
    </div>
  );
};

export default Unauthorized;
