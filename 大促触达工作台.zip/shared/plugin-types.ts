// ---- plugin:marketing_copy_generator_1 ----
// ============================================================
// 插件 marketing_copy_generator_1 (营销触达文案生成) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface MarketingCopyGeneratorOneInput {
  /** 促销周期，文本，如618/双11 */
  promotionPeriod: string;
  /** 类目，文本，如服饰鞋包/美妆护肤 */
  category: string;
  /** 关键心智，文本，影响文案方向利益点和表达重点 */
  coreMindset: string;
  /** 写作风格，文本，可选，描述语气结构字数等要求 */
  writingStyle?: string;
}

/**
 * capabilityClient.load('marketing_copy_generator_1').call<MarketingCopyGeneratorOneOutput>('textGenerate', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { response, content } = result;
 */
export interface MarketingCopyGeneratorOneOutput {
  /** [object Object] */
  response?: string;
  /** [object Object] */
  content: string;
}
// ---- end:marketing_copy_generator_1 ----

// ---- plugin:ecommerce_category_trend_search_1 ----
// ============================================================
// 插件 ecommerce_category_trend_search_1 (电商类目消费趋势搜索) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface EcommerceCategoryTrendSearchOneInput {
  /** 搜索关键词，例如'618 美妆护肤 消费趋势 热销 增长' */
  query: string;
}

/**
 * capabilityClient.load('ecommerce_category_trend_search_1').call<EcommerceCategoryTrendSearchOneOutput>('searchSummary', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { summary } = result;
 */
export interface EcommerceCategoryTrendSearchOneOutput {
  /** [object Object] */
  summary: string;
}
// ---- end:ecommerce_category_trend_search_1 ----


// ---- plugin:writing_high_quality_text_1 ----
// ============================================================
// 插件 writing_high_quality_text_1 (智能写作) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface WritingHighQualityTextOneInput {
  /** 触达趋势数据分析提示词，由调用方完整拼装后传入 */
  prompt: string;
}

/**
 * capabilityClient.load('writing_high_quality_text_1').call<WritingHighQualityTextOneOutput>('textGenerate', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { content, response } = result;
 */
export interface WritingHighQualityTextOneOutput {
  /** [object Object] */
  content: string;
  /** [object Object] */
  response?: string;
}
// ---- end:writing_high_quality_text_1 ----

// ---- plugin:ai_search_info_retrieval_1 ----
// ============================================================
// 插件 ai_search_info_retrieval_1 (AI 搜索) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface AiSearchInfoRetrievalOneInput {
  /** 搜索关键词 */
  query: string;
  /** 对搜索结果的处理/整理方式说明 */
  instruction?: string;
}

/**
 * capabilityClient.load('ai_search_info_retrieval_1').call<AiSearchInfoRetrievalOneOutput>('searchSummary', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { summary } = result;
 */
export interface AiSearchInfoRetrievalOneOutput {
  /** [object Object] */
  summary: string;
}
// ---- end:ai_search_info_retrieval_1 ----