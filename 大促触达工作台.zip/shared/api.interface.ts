/* 前后端共享的类型写在这里 */

export interface ReachTaskRow {
  taskId: string;
  taskName: string;
  channel: string;
  category: string | null;
  copyStage: string | null;
  copyTitle: string | null;
  copyContent: string | null;
  sendDateBatch: number | null;
  sendTimeStart: string | null;
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  actionRate: number;
  reachRatePp: number | null;
  actionRatePp: number | null;
  channelSort: number;
}

export interface ChannelSummary {
  channel: string;
  channelSort: number;
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  taskCount: number;
  reachRate: number;
  actionRate: number;
}

export interface TouchDashboardResponse {
  channelSummary: ChannelSummary[];
  tasks: ReachTaskRow[];
}

export interface ImportReachDataRequest {
  rows: ReachTaskRow[];
}

export interface ImportReachDataResponse {
  inserted: number;
  batch: string;
}

export interface ClearReachDataResponse {
  deleted: number;
}

export interface TouchDetailOptionsResponse {
  channels: string[];
  minDate: string;
  maxDate: string;
}

export interface TouchDetailDayRow {
  sendDate: string;
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  doneRate: number;
}

export interface TouchDetailSummary {
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  doneRate: number;
}

export interface TouchDetailQueryResponse {
  summary: TouchDetailSummary;
  days: TouchDetailDayRow[];
}
