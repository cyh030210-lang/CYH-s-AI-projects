import { Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { DashboardOpenApiController } from './dashboard.openapi.controller';
import { DashboardService } from './dashboard.service';

@Module({
  controllers: [DashboardController, DashboardOpenApiController],
  providers: [DashboardService],
})
export class DashboardModule {}
