import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Post,
  Query,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type {
  ImportReachDataRequest,
  ImportReachDataResponse,
  ClearReachDataResponse,
  TouchDashboardResponse,
  TouchDetailOptionsResponse,
  TouchDetailQueryResponse,
} from '@shared/api.interface';
import { DashboardService } from './dashboard.service';

@Controller('api/dashboard')
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Get('touch-data')
  async getTouchData(): Promise<TouchDashboardResponse> {
    return this.dashboardService.getTouchData();
  }

  @Get('detail/options')
  async getDetailOptions(): Promise<TouchDetailOptionsResponse> {
    return this.dashboardService.getDetailOptions();
  }

  @Get('detail/query')
  async queryDetail(
    @Query('channel') channel: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
    @Query('taskIds') taskIds?: string,
  ): Promise<TouchDetailQueryResponse> {
    if (!channel) {
      throw new BadRequestException('channel 不能为空');
    }
    const datePattern = /^\d{4}-\d{2}-\d{2}$/u;
    if (!datePattern.test(startDate) || !datePattern.test(endDate)) {
      throw new BadRequestException('startDate/endDate 格式需为 YYYY-MM-DD');
    }
    if (startDate > endDate) {
      throw new BadRequestException('startDate 不能晚于 endDate');
    }
    const idList = taskIds
      ? taskIds.split(',').map((s) => s.trim()).filter(Boolean)
      : undefined;
    return this.dashboardService.queryDetail(
      channel,
      startDate,
      endDate,
      idList,
    );
  }

  @Get('detail/popup-subtype')
  async queryPopupSubtypeDetail(
    @Query('taskIds') taskIds: string,
  ): Promise<TouchDetailQueryResponse> {
    const idList = taskIds
      ? taskIds.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    return this.dashboardService.queryPopupSubtypeDetail(idList);
  }

  @NeedLogin()
  @Post('import')
  async importRecords(
    @Body() body: ImportReachDataRequest,
  ): Promise<ImportReachDataResponse> {
    if (!body || !Array.isArray(body.rows) || body.rows.length === 0) {
      throw new BadRequestException('rows \u4e0d\u80fd\u4e3a\u7a7a\uff0c\u9700\u4e3a\u975e\u7a7a\u6570\u7ec4');
    }
    return this.dashboardService.importRecords(body.rows);
  }

  @NeedLogin()
  @Delete('records')
  async clearRecords(): Promise<ClearReachDataResponse> {
    return this.dashboardService.clearRecords();
  }
}
