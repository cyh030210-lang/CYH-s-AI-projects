import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Post,
} from '@nestjs/common';
import type {
  ImportReachDataRequest,
  ImportReachDataResponse,
  ClearReachDataResponse,
} from '@shared/api.interface';
import { DashboardService } from './dashboard.service';

@Controller('openapi/dashboard')
export class DashboardOpenApiController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Post('records')
  async importRecords(
    @Body() body: ImportReachDataRequest,
  ): Promise<ImportReachDataResponse> {
    if (!body || !Array.isArray(body.rows) || body.rows.length === 0) {
      throw new BadRequestException('rows \u4e0d\u80fd\u4e3a\u7a7a\uff0c\u9700\u4e3a\u975e\u7a7a\u6570\u7ec4');
    }
    return this.dashboardService.importRecords(body.rows);
  }

  @Delete('records')
  async clearRecords(): Promise<ClearReachDataResponse> {
    return this.dashboardService.clearRecords();
  }
}
