import { Inject, Injectable, Logger } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { asc, and, eq, gte, lte, inArray, sql } from 'drizzle-orm';
import { chuDaShuJu, chuDaMingXi } from '@server/database/schema';
import type {
  ChannelSummary,
  ImportReachDataResponse,
  ClearReachDataResponse,
  ReachTaskRow,
  TouchDashboardResponse,
  TouchDetailOptionsResponse,
  TouchDetailQueryResponse,
  TouchDetailDayRow,
} from '@shared/api.interface';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async getTouchData(): Promise<TouchDashboardResponse> {
    const records = await this.db
      .select({
        taskId: chuDaShuJu.taskId,
        taskName: chuDaShuJu.taskName,
        channel: chuDaShuJu.channel,
        category: chuDaShuJu.category,
        copyStage: chuDaShuJu.copyStage,
        copyTitle: chuDaShuJu.copyTitle,
        copyContent: chuDaShuJu.copyContent,
        sendDateBatch: chuDaShuJu.sendDateBatch,
        sendTimeStart: chuDaShuJu.sendTimeStart,
        sendMerchants: chuDaShuJu.sendMerchants,
        clickMerchants: chuDaShuJu.clickMerchants,
        doneMerchants: chuDaShuJu.doneMerchants,
        reachRate: chuDaShuJu.reachRate,
        actionRate: chuDaShuJu.actionRate,
        reachRatePp: chuDaShuJu.reachRatePp,
        actionRatePp: chuDaShuJu.actionRatePp,
        channelSort: chuDaShuJu.channelSort,
      })
      .from(chuDaShuJu)
      .orderBy(asc(chuDaShuJu.channelSort), asc(chuDaShuJu.sendDateBatch));

    const tasks: ReachTaskRow[] = records.map((r) => ({
      taskId: r.taskId ?? '',
      taskName: r.taskName ?? '',
      channel: r.channel ?? '',
      category: r.category,
      copyStage: r.copyStage,
      copyTitle: r.copyTitle,
      copyContent: r.copyContent,
      sendDateBatch: r.sendDateBatch,
      sendTimeStart: r.sendTimeStart,
      sendMerchants: r.sendMerchants ?? 0,
      clickMerchants: r.clickMerchants ?? 0,
      doneMerchants: r.doneMerchants ?? 0,
      reachRate: r.reachRate ?? 0,
      actionRate: r.actionRate ?? 0,
      reachRatePp: r.reachRatePp,
      actionRatePp: r.actionRatePp,
      channelSort: r.channelSort ?? 0,
    }));

    const channelSummary = this.aggregateByChannel(tasks);

    return { channelSummary, tasks };
  }

  private aggregateByChannel(tasks: ReachTaskRow[]): ChannelSummary[] {
    const map = new Map<string, ChannelSummary>();

    for (const t of tasks) {
      const existing = map.get(t.channel);
      if (existing) {
        existing.sendMerchants += t.sendMerchants;
        existing.clickMerchants += t.clickMerchants;
        existing.doneMerchants += t.doneMerchants;
        existing.taskCount += 1;
      } else {
        map.set(t.channel, {
          channel: t.channel,
          channelSort: t.channelSort,
          sendMerchants: t.sendMerchants,
          clickMerchants: t.clickMerchants,
          doneMerchants: t.doneMerchants,
          taskCount: 1,
          reachRate: 0,
          actionRate: 0,
        });
      }
    }

    const summary = Array.from(map.values());
    for (const s of summary) {
      s.reachRate = s.sendMerchants > 0 ? s.clickMerchants / s.sendMerchants : 0;
      s.actionRate = s.sendMerchants > 0 ? s.doneMerchants / s.sendMerchants : 0;
    }

    summary.sort((a, b) => a.channelSort - b.channelSort);
    return summary;
  }

  async importRecords(rows: ReachTaskRow[]): Promise<ImportReachDataResponse> {
    const importBatch = `batch_${Date.now()}`;

    await this.db.delete(chuDaShuJu);

    const values = rows.map((row: ReachTaskRow) => ({
      taskId: row.taskId,
      taskName: row.taskName,
      channel: row.channel,
      category: row.category,
      copyStage: row.copyStage,
      copyTitle: row.copyTitle,
      copyContent: row.copyContent,
      sendDateBatch: row.sendDateBatch,
      sendTimeStart: row.sendTimeStart,
      sendMerchants: row.sendMerchants,
      clickMerchants: row.clickMerchants,
      doneMerchants: row.doneMerchants,
      reachRate: row.reachRate,
      actionRate: row.actionRate,
      reachRatePp: row.reachRatePp,
      actionRatePp: row.actionRatePp,
      channelSort: row.channelSort,
      importBatch,
    }));

    await this.db.insert(chuDaShuJu).values(values);

    this.logger.log(
      `\u8986\u76d6\u5bfc\u5165\u89e6\u8fbe\u770b\u677f\u6570\u636e ${values.length} \u6761, batch=${importBatch}`,
    );

    return { inserted: values.length, batch: importBatch };
  }

  async clearRecords(): Promise<ClearReachDataResponse> {
    const deleted = await this.db
      .delete(chuDaShuJu)
      .returning({ id: chuDaShuJu.id });

    this.logger.log(`清空触达看板数据 ${deleted.length} 条`);

    return { deleted: deleted.length };
  }

  async getDetailOptions(): Promise<TouchDetailOptionsResponse> {
    const channelRows = await this.db
      .selectDistinct({ channel: chuDaMingXi.channel })
      .from(chuDaMingXi)
      .orderBy(asc(chuDaMingXi.channel));

    const range = await this.db
      .select({
        minDate: sql<string>`min(${chuDaMingXi.sendDate})`,
        maxDate: sql<string>`max(${chuDaMingXi.sendDate})`,
      })
      .from(chuDaMingXi);

    return {
      channels: channelRows.map((r) => r.channel),
      minDate: range[0]?.minDate ?? '',
      maxDate: range[0]?.maxDate ?? '',
    };
  }

  async queryDetail(
    channel: string,
    startDate: string,
    endDate: string,
    taskIds?: string[],
  ): Promise<TouchDetailQueryResponse> {
    const taskIdCondition =
      taskIds && taskIds.length > 0
        ? inArray(chuDaMingXi.taskId, taskIds)
        : undefined;

    const rows = await this.db
      .select({
        sendDate: chuDaMingXi.sendDate,
        sendMerchants: sql<number>`coalesce(sum(${chuDaMingXi.sendMerchants}), 0)`,
        clickMerchants: sql<number>`coalesce(sum(${chuDaMingXi.clickMerchants}), 0)`,
        doneMerchants: sql<number>`coalesce(sum(${chuDaMingXi.doneMerchants}), 0)`,
      })
      .from(chuDaMingXi)
      .where(
        and(
          eq(chuDaMingXi.channel, channel),
          gte(chuDaMingXi.sendDate, startDate),
          lte(chuDaMingXi.sendDate, endDate),
          taskIdCondition,
        ),
      )
      .groupBy(chuDaMingXi.sendDate)
      .orderBy(asc(chuDaMingXi.sendDate));

    const days: TouchDetailDayRow[] = rows.map((r) => {
      const send = Number(r.sendMerchants) || 0;
      const click = Number(r.clickMerchants) || 0;
      const done = Number(r.doneMerchants) || 0;
      return {
        sendDate: r.sendDate,
        sendMerchants: send,
        clickMerchants: click,
        doneMerchants: done,
        reachRate: send > 0 ? click / send : 0,
        doneRate: send > 0 ? done / send : 0,
      };
    });

    const totalSend = days.reduce((acc, d) => acc + d.sendMerchants, 0);
    const totalClick = days.reduce((acc, d) => acc + d.clickMerchants, 0);
    const totalDone = days.reduce((acc, d) => acc + d.doneMerchants, 0);

    return {
      summary: {
        sendMerchants: totalSend,
        clickMerchants: totalClick,
        doneMerchants: totalDone,
        reachRate: totalSend > 0 ? totalClick / totalSend : 0,
        doneRate: totalSend > 0 ? totalDone / totalSend : 0,
      },
      days,
    };
  }

  async queryPopupSubtypeDetail(
    taskIds: string[],
  ): Promise<TouchDetailQueryResponse> {
    const emptyResult: TouchDetailQueryResponse = {
      summary: {
        sendMerchants: 0,
        clickMerchants: 0,
        doneMerchants: 0,
        reachRate: 0,
        doneRate: 0,
      },
      days: [],
    };

    if (!taskIds || taskIds.length === 0) {
      return emptyResult;
    }

    const rows = await this.db
      .select({
        sendDate: chuDaMingXi.sendDate,
        sendMerchants: sql<number>`coalesce(sum(${chuDaMingXi.sendMerchants}), 0)`,
        clickMerchants: sql<number>`coalesce(sum(${chuDaMingXi.clickMerchants}), 0)`,
        doneMerchants: sql<number>`coalesce(sum(${chuDaMingXi.doneMerchants}), 0)`,
      })
      .from(chuDaMingXi)
      .where(
        and(
          eq(chuDaMingXi.channel, '弹窗'),
          inArray(chuDaMingXi.taskId, taskIds),
        ),
      )
      .groupBy(chuDaMingXi.sendDate)
      .orderBy(asc(chuDaMingXi.sendDate));

    const days: TouchDetailDayRow[] = rows.map((r) => {
      const send = Number(r.sendMerchants) || 0;
      const click = Number(r.clickMerchants) || 0;
      const done = Number(r.doneMerchants) || 0;
      return {
        sendDate: r.sendDate,
        sendMerchants: send,
        clickMerchants: click,
        doneMerchants: done,
        reachRate: send > 0 ? click / send : 0,
        doneRate: send > 0 ? done / send : 0,
      };
    });

    const totalSend = days.reduce((acc, d) => acc + d.sendMerchants, 0);
    const totalClick = days.reduce((acc, d) => acc + d.clickMerchants, 0);
    const totalDone = days.reduce((acc, d) => acc + d.doneMerchants, 0);

    return {
      summary: {
        sendMerchants: totalSend,
        clickMerchants: totalClick,
        doneMerchants: totalDone,
        reachRate: totalSend > 0 ? totalClick / totalSend : 0,
        doneRate: totalSend > 0 ? totalDone / totalSend : 0,
      },
      days,
    };
  }
}
