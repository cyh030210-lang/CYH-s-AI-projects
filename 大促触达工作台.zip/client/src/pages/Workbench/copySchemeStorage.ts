import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  DEFAULT_DESCRIPTION_TEMPLATE,
  PC_DEFAULT_DESCRIPTION_TEMPLATE,
  renderDescriptionTemplate,
} from './descriptionTemplateStorage';

export interface CopyScheme {
  id: string;
  name: string;
  nameTemplate: string;
  descTemplate: string;
}

export const NAME_TOKENS: { token: string; label: string }[] = [
  { token: '{dateCode}', label: '日期码' },
  { token: '{categoryLabel}', label: '类目名称' },
];

export const PC_NAME_TOKENS: { token: string; label: string }[] = [
  { token: '{year}', label: '年份码' },
  { token: '{periodLabel}', label: '促销周期' },
  { token: '{slotLabel}', label: '资源位名' },
  { token: '{stage}', label: '阶段号' },
];

export const PC_DEFAULT_NAME_TEMPLATE = 'Y{year}{periodLabel}-{slotLabel}-{stage}';

// 上一版 PC 名称模板（UI 不可编辑），加载时迁移为新格式
const OLD_PC_NAME_TEMPLATE = '{dateCode}｜{categoryLabel}｜PC触达';

export interface CopyScope {
  key: string;
  label: string;
}

export const BARGAIN_POPUP_LABEL = '议价弹窗';
export const EXCLUSIVE_POPUP_LABEL = '大促专属弹窗';

export const POPUP_SCOPES: CopyScope[] = [
  { key: 'popup_key_category', label: '重点类目弹窗（默认）' },
  { key: 'popup_bargain', label: '议价弹窗' },
  { key: 'popup_exclusive', label: '大促专属弹窗' },
];

const PC_SCOPE_LEGACY_KEY = 'pc_s_card_app_belt';

export const PC_SUB_SCOPES: CopyScope[] = [
  { key: 'pc_s_card_l2', label: 'S卡二级页面' },
  { key: 'pc_app_promo_atmos', label: 'APP大促氛围' },
  { key: 'pc_app_belt', label: 'APP腰封' },
];

const PC_SCOPE_KEYS = new Set(PC_SUB_SCOPES.map((s) => s.key));

export const getScopesForSlot = (
  slot: string,
  slotLabel?: string,
  mode?: 'popup' | 'pc',
): CopyScope[] => {
  if (slot === 'pc_s_card_app_belt') return PC_SUB_SCOPES;
  if (slot === 'popup') return POPUP_SCOPES;
  // 自定义资源位：单一文案分组，key 即资源位 key
  return [{ key: slot, label: slotLabel ?? slot }];
};

export const getCategoryScope = (categoryLabel: string): string => {
  if (categoryLabel === BARGAIN_POPUP_LABEL) return 'popup_bargain';
  if (categoryLabel === EXCLUSIVE_POPUP_LABEL) return 'popup_exclusive';
  return 'popup_key_category';
};

const SCHEMES_KEY_PREFIX = 'workbench:copy-schemes';
const ACTIVE_KEY_PREFIX = 'workbench:copy-scheme-active';
const LEGACY_DESC_KEY_PREFIX = 'workbench:reach-description-template';

const schemesKey = (scope: string): string => `${SCHEMES_KEY_PREFIX}:${scope}`;
const activeKey = (scope: string): string => `${ACTIVE_KEY_PREFIX}:${scope}`;
const legacyDescKey = (slot: string): string =>
  `${LEGACY_DESC_KEY_PREFIX}:${slot}`;

const genId = (): string =>
  `scheme_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

const isPcScope = (scope: string, mode?: 'popup' | 'pc'): boolean =>
  PC_SCOPE_KEYS.has(scope) || mode === 'pc';

const defaultNameTemplate = (
  scope: string,
  mode?: 'popup' | 'pc',
): string =>
  isPcScope(scope, mode)
    ? PC_DEFAULT_NAME_TEMPLATE
    : '{dateCode}｜{categoryLabel}｜弹窗push';

// S卡二级页面 scope 首次加载时，尝试迁移上一版按单一 PC scope 存储的方案
const migrateLegacyPcSchemes = (): CopyScheme[] | null => {
  try {
    const raw = localStorage.getItem(`${SCHEMES_KEY_PREFIX}:${PC_SCOPE_LEGACY_KEY}`);
    if (raw) {
      const parsed = JSON.parse(raw) as CopyScheme[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (error) {
    logger.warn('迁移旧 PC 文案方案失败', String(error));
  }
  return null;
};

// popup_key_category 首次加载时，尝试迁移上一版按资源位存储的 popup 方案
const migrateLegacyPopupSchemes = (): CopyScheme[] | null => {
  try {
    const raw = localStorage.getItem(`${SCHEMES_KEY_PREFIX}:popup`);
    if (raw) {
      const parsed = JSON.parse(raw) as CopyScheme[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (error) {
    logger.warn('迁移旧 popup 文案方案失败', String(error));
  }
  return null;
};

const createDefaultScheme = (
  scope: string,
  mode?: 'popup' | 'pc',
): CopyScheme => {
  if (PC_SCOPE_KEYS.has(scope) || mode === 'pc') {
    return {
      id: genId(),
      name: '默认方案',
      nameTemplate: defaultNameTemplate(scope, mode),
      descTemplate: PC_DEFAULT_DESCRIPTION_TEMPLATE,
    };
  }
  let descTemplate = DEFAULT_DESCRIPTION_TEMPLATE;
  const legacySlot =
    scope === 'pc_s_card_app_belt' ? 'pc_s_card_app_belt' : 'popup';
  try {
    const legacy = localStorage.getItem(legacyDescKey(legacySlot));
    if (legacy && legacy.trim()) {
      descTemplate = legacy;
    }
  } catch (error) {
    logger.warn('读取旧描述模板缓存失败', String(error));
  }
  return {
    id: genId(),
    name: '默认方案',
    nameTemplate: defaultNameTemplate(scope),
    descTemplate,
  };
};

const writeSchemes = (slot: string, list: CopyScheme[]): void => {
  try {
    localStorage.setItem(schemesKey(slot), JSON.stringify(list));
  } catch (error) {
    logger.warn('保存文案方案缓存失败', String(error));
  }
};

export const loadSchemes = (
  scope: string,
  mode?: 'popup' | 'pc',
): CopyScheme[] => {
  try {
    const raw = localStorage.getItem(schemesKey(scope));
    if (raw) {
      const parsed = JSON.parse(raw) as CopyScheme[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        if (isPcScope(scope, mode)) {
          let migrated = false;
          const next = parsed.map((s) => {
            if (s.nameTemplate === OLD_PC_NAME_TEMPLATE) {
              migrated = true;
              return { ...s, nameTemplate: PC_DEFAULT_NAME_TEMPLATE };
            }
            return s;
          });
          if (migrated) {
            writeSchemes(scope, next);
            return next;
          }
        }
        return parsed;
      }
    }
  } catch (error) {
    logger.warn('读取文案方案缓存失败', String(error));
  }
  if (scope === 'popup_key_category') {
    const migrated = migrateLegacyPopupSchemes();
    if (migrated) {
      writeSchemes(scope, migrated);
      return migrated;
    }
  }
  if (scope === 'pc_s_card_l2') {
    const migrated = migrateLegacyPcSchemes();
    if (migrated) {
      writeSchemes(scope, migrated);
      return migrated;
    }
  }
  const seed = [createDefaultScheme(scope, mode)];
  writeSchemes(scope, seed);
  return seed;
};

export const getActiveScheme = (
  slot: string,
  mode?: 'popup' | 'pc',
): CopyScheme => {
  const list = loadSchemes(slot, mode);
  let activeId = '';
  try {
    activeId = localStorage.getItem(activeKey(slot)) ?? '';
  } catch (error) {
    logger.warn('读取生效方案缓存失败', String(error));
  }
  return list.find((s) => s.id === activeId) ?? list[0];
};

export const setActiveScheme = (slot: string, id: string): void => {
  try {
    localStorage.setItem(activeKey(slot), id);
  } catch (error) {
    logger.warn('保存生效方案缓存失败', String(error));
  }
};

export const addScheme = (
  slot: string,
  name: string,
  mode?: 'popup' | 'pc',
): CopyScheme => {
  const list = loadSchemes(slot, mode);
  const item: CopyScheme = {
    id: genId(),
    name: name.trim() || `新方案${list.length + 1}`,
    nameTemplate: defaultNameTemplate(slot, mode),
    descTemplate: isPcScope(slot, mode)
      ? PC_DEFAULT_DESCRIPTION_TEMPLATE
      : DEFAULT_DESCRIPTION_TEMPLATE,
  };
  writeSchemes(slot, [...list, item]);
  return item;
};

export const updateScheme = (slot: string, scheme: CopyScheme): void => {
  const list = loadSchemes(slot);
  writeSchemes(
    slot,
    list.map((s) => (s.id === scheme.id ? scheme : s)),
  );
};

export const saveSchemes = (slot: string, list: CopyScheme[]): void => {
  writeSchemes(slot, list);
};

export const removeScheme = (
  slot: string,
  id: string,
  mode?: 'popup' | 'pc',
): CopyScheme[] => {
  const list = loadSchemes(slot, mode).filter((s) => s.id !== id);
  if (list.length === 0) {
    const seed = [createDefaultScheme(slot, mode)];
    writeSchemes(slot, seed);
    setActiveScheme(slot, seed[0].id);
    return seed;
  }
  writeSchemes(slot, list);
  return list;
};

export const renderNameTemplate = (
  template: string,
  params: { dateCode: string; categoryLabel: string },
): string =>
  template
    .replace(/\{dateCode\}/g, params.dateCode)
    .replace(/\{categoryLabel\}/g, params.categoryLabel);

export const renderPcNameTemplate = (
  template: string,
  params: {
    year: string;
    periodLabel: string;
    slotLabel: string;
    stage: string;
  },
): string =>
  template
    .replace(/\{year\}/g, params.year)
    .replace(/\{periodLabel\}/g, params.periodLabel)
    .replace(/\{slotLabel\}/g, params.slotLabel)
    .replace(/\{stage\}/g, params.stage);

export { renderDescriptionTemplate };
