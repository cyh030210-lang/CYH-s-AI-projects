export interface PromotionPeriod {
  id: string;
  label: string;
  defaultMindset: string;
}

export interface CategoryOption {
  id: string;
  label: string;
}

export interface ReachStage {
  id: string;
  label: string;
}

export const REACH_STAGES: ReachStage[] = [
  { id: 'stage_1', label: '阶段1' },
  { id: 'stage_2', label: '阶段2' },
  { id: 'stage_3', label: '阶段3' },
  { id: 'stage_4', label: '阶段4' },
  { id: 'stage_5', label: '阶段5' },
];

export const PROMOTION_PERIODS: PromotionPeriod[] = [
  {
    id: 'new_year_goods',
    label: '年货节',
    defaultMindset: '囤货备年、年货送礼、家庭消费、春节前置采购、年味氛围',
  },
  {
    id: 'spring_festival',
    label: '春节',
    defaultMindset: '阖家团圆、新春焕新、送礼心意、节庆消费、开年好彩头',
  },
  {
    id: 'womens_day',
    label: '38促',
    defaultMindset: '悦己消费、女王宠爱、品质升级、限时福利、为她种草',
  },
  {
    id: 'refresh_season',
    label: '焕新季',
    defaultMindset: '换季焕新、品质升级、以旧换新、焕新生活、上新尝鲜',
  },
  {
    id: 'love_520',
    label: '520',
    defaultMindset: '礼赠表白、心意表达、情侣消费、悦己宠爱、浪漫氛围',
  },
  {
    id: 'mid_year_618',
    label: '618',
    defaultMindset: '大促爆发、流量加码、成交增长、限时报名、爆款直降',
  },
  {
    id: 'qixi',
    label: '七夕',
    defaultMindset: '浪漫礼赠、情侣消费、心意表达、限定好礼、节日仪式感',
  },
  {
    id: 'mid_autumn',
    label: '中秋',
    defaultMindset: '团圆送礼、节庆囤货、月饼礼盒、家庭消费、传统佳节氛围',
  },
  {
    id: 'double_11',
    label: '双11',
    defaultMindset: '全年最大促、流量爆发、预售种草、满减跨店、限时抢购',
  },
  {
    id: 'year_end',
    label: '年终促',
    defaultMindset: '年终清仓、囤货备年、回馈福利、冲量收官、跨年优惠',
  },
];

export const CATEGORIES: CategoryOption[] = [
  { id: 'apparel', label: '服饰鞋包' },
  { id: 'sports_outdoor', label: '运动户外' },
  { id: 'digital_appliance', label: '数码家电' },
  { id: 'furniture_home', label: '家具家装' },
  { id: 'books_education', label: '图书教育' },
  { id: 'home_personal_care', label: '家清个护' },
  { id: 'maternal_toys', label: '母婴玩具' },
  { id: 'beauty_skincare', label: '美妆护肤' },
  { id: 'food_health', label: '食饮保健' },
];
