import React, { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import ConfigPanel, { ConfigErrors } from './ConfigPanel';
import ResultPanel from './ResultPanel';
import { useCopyGeneration } from './useCopyGeneration';
import { loadMindset, saveMindset, removeMindset } from './mindsetStorage';
import { getAllPeriods } from './periodStorage';
import {
  StyleSkill,
  resolveDefaultSkill,
  saveSelectedSkillId,
} from './styleSkillStorage';

const Workbench: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('');
  const [categoryIds, setCategoryIds] = useState<string[]>([]);
  const [coreMindsets, setCoreMindsets] = useState<string[]>([]);
  const [selectedStyleSkill, setSelectedStyleSkill] =
    useState<StyleSkill | null>(() => resolveDefaultSkill());
  const [enableSearch, setEnableSearch] = useState(true);
  const [errors, setErrors] = useState<ConfigErrors>({});

  const { results, isGenerating, hasStarted, generate, retryItem, reset } =
    useCopyGeneration();

  const handleSelectPeriod = useCallback((id: string) => {
    setSelectedPeriod(id);
    setErrors((prev) => ({ ...prev, period: false, mindset: false }));
    const period = getAllPeriods().find((p) => p.id === id);
    if (period) {
      const saved = loadMindset(id);
      setCoreMindsets(saved ?? [period.defaultMindset]);
    }
  }, []);

  const handleChangeMindset = useCallback(
    (index: number, v: string) => {
      setErrors((prev) => ({ ...prev, mindset: false }));
      setCoreMindsets((prev) => {
        const next = prev.map((m, i) => (i === index ? v : m));
        if (selectedPeriod) {
          saveMindset(selectedPeriod, next);
        }
        return next;
      });
    },
    [selectedPeriod],
  );

  const handleAddMindset = useCallback(() => {
    setCoreMindsets((prev) => {
      const next = [...prev, ''];
      if (selectedPeriod) {
        saveMindset(selectedPeriod, next);
      }
      return next;
    });
  }, [selectedPeriod]);

  const handleRemoveMindset = useCallback(
    (index: number) => {
      if (index <= 0) return;
      setErrors((prev) => ({ ...prev, mindset: false }));
      setCoreMindsets((prev) => {
        const next = prev.filter((_, i) => i !== index);
        if (selectedPeriod) {
          saveMindset(selectedPeriod, next);
        }
        return next;
      });
    },
    [selectedPeriod],
  );

  const handleResetMindset = useCallback(() => {
    if (!selectedPeriod) return;
    const period = getAllPeriods().find((p) => p.id === selectedPeriod);
    if (!period) return;
    setCoreMindsets([period.defaultMindset]);
    removeMindset(selectedPeriod);
    setErrors((prev) => ({ ...prev, mindset: false }));
  }, [selectedPeriod]);

  const handleChangeCategories = useCallback((ids: string[]) => {
    setCategoryIds(ids);
    setErrors((prev) => ({ ...prev, categories: false }));
  }, []);

  const handleGenerate = useCallback(() => {
    const mindsetInvalid =
      coreMindsets.length === 0 ||
      coreMindsets.some((m) => m.trim().length === 0);
    const nextErrors: ConfigErrors = {
      period: !selectedPeriod,
      categories: categoryIds.length === 0,
      mindset: mindsetInvalid,
    };
    setErrors(nextErrors);

    if (nextErrors.period) {
      toast.error('请选择一个促销周期');
      return;
    }
    if (nextErrors.categories) {
      toast.error('请至少选择一个类目');
      return;
    }
    if (nextErrors.mindset) {
      toast.error('关键心智不能为空，请填写或删除空白项');
      return;
    }

    const periodLabel =
      getAllPeriods().find((p) => p.id === selectedPeriod)?.label ?? '';
    generate({
      promotionPeriodLabel: periodLabel,
      categoryIds,
      coreMindsets: coreMindsets.map((m) => m.trim()),
      writingStyle: selectedStyleSkill?.content?.trim() || undefined,
      enableSearch,
    });
  }, [
    selectedPeriod,
    categoryIds,
    coreMindsets,
    selectedStyleSkill,
    enableSearch,
    generate,
  ]);

  const handleSelectStyleSkill = useCallback((skill: StyleSkill | null) => {
    setSelectedStyleSkill(skill);
    saveSelectedSkillId(skill?.id ?? null);
  }, []);

  const handleClear = useCallback(() => {
    setSelectedPeriod('');
    setCategoryIds([]);
    setCoreMindsets([]);
    setSelectedStyleSkill(resolveDefaultSkill());
    setEnableSearch(true);
    setErrors({});
    reset();
  }, [reset]);

  const handleCopyAll = useCallback(async () => {
    const successResults = results.filter(
      (r) => r.status === 'success' && r.content,
    );
    const multiMindset = successResults.some((r) => r.mindsetIndex > 0);
    const text = successResults
      .map((r) => {
        const label = multiMindset
          ? `${r.categoryLabel} · ${r.mindsetLabel}`
          : r.categoryLabel;
        return `【${label}】\n${r.content}`;
      })
      .join('\n\n');
    if (!text) {
      toast.error('暂无可复制的文案');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      toast.success('已复制全部文案');
    } catch (error) {
      logger.error('全部复制失败', String(error));
      toast.error('复制失败，请手动复制');
    }
  }, [results]);

  const exportTitle =
    getAllPeriods().find((p) => p.id === selectedPeriod)?.label || '营销文案';

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* 主体左右分栏 */}
      <div className="flex min-h-0 flex-1 flex-col gap-6 lg:flex-row lg:gap-3">
        <section className="flex min-h-0 flex-col overflow-hidden rounded-lg border border-border bg-card shadow-sm lg:w-[calc((100%-1.5rem)/3)] lg:shrink-0">
          <ConfigPanel
            selectedPeriod={selectedPeriod}
            categoryIds={categoryIds}
            coreMindsets={coreMindsets}
            errors={errors}
            isGenerating={isGenerating}
            onSelectPeriod={handleSelectPeriod}
            onChangeCategories={handleChangeCategories}
            onChangeMindset={handleChangeMindset}
            onAddMindset={handleAddMindset}
            onRemoveMindset={handleRemoveMindset}
            onResetMindset={handleResetMindset}
            canResetMindset={!!selectedPeriod}
            selectedStyleSkillId={selectedStyleSkill?.id ?? null}
            onSelectStyleSkill={handleSelectStyleSkill}
            enableSearch={enableSearch}
            onToggleSearch={setEnableSearch}
            onGenerate={handleGenerate}
            onClear={handleClear}
          />
        </section>
        <section className="flex min-h-0 flex-col overflow-hidden rounded-lg border border-border bg-background lg:flex-1">
          <ResultPanel
            hasStarted={hasStarted}
            results={results}
            exportTitle={exportTitle}
            onRetry={retryItem}
            onCopyAll={handleCopyAll}
          />
        </section>
      </div>
    </div>
  );
};

export default Workbench;
