import React from 'react';
import {
  Sparkles,
  Eraser,
  Loader2,
  RotateCcw,
  Globe,
  Plus,
  X,
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { PROMOTION_PERIODS, PromotionPeriod } from './constants';
import {
  loadCustomPeriods,
  addCustomPeriod,
  removeCustomPeriod,
} from './periodStorage';
import CategoryMultiSelect from './CategoryMultiSelect';
import StyleSkillManager from './StyleSkillManager';
import StepSection from './StepSection';
import MindsetList from './MindsetList';
import { StyleSkill } from './styleSkillStorage';

export interface ConfigErrors {
  period?: boolean;
  categories?: boolean;
  mindset?: boolean;
}

interface ConfigPanelProps {
  selectedPeriod: string;
  categoryIds: string[];
  coreMindsets: string[];
  errors: ConfigErrors;
  isGenerating: boolean;
  onSelectPeriod: (id: string) => void;
  onChangeCategories: (ids: string[]) => void;
  onChangeMindset: (index: number, v: string) => void;
  onAddMindset: () => void;
  onRemoveMindset: (index: number) => void;
  onResetMindset: () => void;
  canResetMindset: boolean;
  selectedStyleSkillId: string | null;
  onSelectStyleSkill: (skill: StyleSkill | null) => void;
  enableSearch: boolean;
  onToggleSearch: (v: boolean) => void;
  onGenerate: () => void;
  onClear: () => void;
}

const ConfigPanel: React.FC<ConfigPanelProps> = ({
  selectedPeriod,
  categoryIds,
  coreMindsets,
  errors,
  isGenerating,
  onSelectPeriod,
  onChangeCategories,
  onChangeMindset,
  onAddMindset,
  onRemoveMindset,
  onResetMindset,
  canResetMindset,
  selectedStyleSkillId,
  onSelectStyleSkill,
  enableSearch,
  onToggleSearch,
  onGenerate,
  onClear,
}) => {
  const [customPeriods, setCustomPeriods] = React.useState<PromotionPeriod[]>(
    () => loadCustomPeriods(),
  );
  const [addOpen, setAddOpen] = React.useState(false);
  const [nameDraft, setNameDraft] = React.useState('');
  const [mindsetDraft, setMindsetDraft] = React.useState('');

  const allPeriods = React.useMemo(
    () => [...PROMOTION_PERIODS, ...customPeriods],
    [customPeriods],
  );
  const customIds = React.useMemo(
    () => new Set(customPeriods.map((p) => p.id)),
    [customPeriods],
  );

  const handleDeletePeriod = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    removeCustomPeriod(id);
    setCustomPeriods((prev) => prev.filter((p) => p.id !== id));
    if (selectedPeriod === id) {
      onSelectPeriod('');
    }
  };

  const handleConfirmAdd = () => {
    const label = nameDraft.trim();
    if (!label) {
      toast.error('请输入周期名称');
      return;
    }
    const exists = allPeriods.some((p) => p.label === label);
    if (exists) {
      toast.error('该周期已存在');
      return;
    }
    const item = addCustomPeriod(label, mindsetDraft);
    setCustomPeriods((prev) => [...prev, item]);
    onSelectPeriod(item.id);
    setNameDraft('');
    setMindsetDraft('');
    setAddOpen(false);
  };

  return (
    <div className="flex h-full flex-col">
      {/* 配置区头部 */}
      <div className="shrink-0 border-b border-border px-6 py-5">
        <h2 className="t-heading c-primary">文案配置</h2>
        <p className="mt-1 t-caption c-secondary">
          按步骤填写，生成贴合业务的触达文案
        </p>
      </div>

      <div className="flex-1 space-y-8 overflow-auto p-6">
        {/* 1. 促销周期 */}
        <StepSection
          index={1}
          title="促销周期"
          desc="选择本次触达对应的大促节点"
          required
        >
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
            {allPeriods.map((p) => {
              const active = selectedPeriod === p.id;
              const isCustom = customIds.has(p.id);
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onSelectPeriod(p.id)}
                  className={cn(
                    'group relative rounded-lg border px-2 py-2.5 t-label transition-all duration-150',
                    active
                      ? 'border-brand bg-brand-muted text-brand shadow-sm'
                      : 'border-border bg-card text-foreground hover:border-brand/40 hover:bg-accent/60',
                    errors.period && !selectedPeriod && 'border-destructive',
                  )}
                >
                  {p.label}
                  {isCustom && (
                    <span
                      role="button"
                      tabIndex={-1}
                      aria-label="删除周期"
                      onClick={(e) => handleDeletePeriod(p.id, e)}
                      className="absolute -right-1.5 -top-1.5 flex size-4 items-center justify-center rounded-full border border-border bg-card text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                    >
                      <X className="size-2.5" />
                    </span>
                  )}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => setAddOpen(true)}
              className="flex items-center justify-center gap-1 rounded-lg border border-dashed border-border px-2 py-2.5 t-label c-secondary transition-colors hover:border-brand/40 hover:text-brand"
            >
              <Plus className="size-3.5" />
              新增
            </button>
          </div>
          {errors.period && (
            <p className="mt-1.5 t-caption text-destructive">请选择一个促销周期</p>
          )}
        </StepSection>

        {/* 2. 触达类目 */}
        <StepSection
          index={2}
          title="触达类目"
          desc="可多选，每个类目将分别生成文案"
          required
        >
          <CategoryMultiSelect
            value={categoryIds}
            onChange={onChangeCategories}
            invalid={errors.categories}
          />
          {errors.categories && (
            <p className="mt-1.5 t-caption text-destructive">请至少选择一个类目</p>
          )}
        </StepSection>

        {/* 3. 关键心智 */}
        <StepSection
          index={3}
          title="关键心智"
          required
          action={
            canResetMindset ? (
              <button
                type="button"
                onClick={onResetMindset}
                className="flex items-center gap-1 t-caption c-secondary transition-colors hover:text-foreground"
              >
                <RotateCcw className="size-3" />
                恢复默认
              </button>
            ) : undefined
          }
        >
          <MindsetList
            values={coreMindsets}
            invalid={errors.mindset}
            onChange={onChangeMindset}
            onAdd={onAddMindset}
            onRemove={onRemoveMindset}
          />
        </StepSection>

        {/* 4. 联网搜索趋势 */}
        <StepSection
          index={4}
          title="联网搜索趋势"
          desc="开启后先搜索该类目最新趋势作为写作参考，生成稍慢"
        >
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3">
            <span className="flex items-center gap-2 t-body c-primary">
              <Globe className="size-4 shrink-0 text-muted-foreground" />
              先联网搜索消费趋势再写作
            </span>
            <Switch
              checked={enableSearch}
              onCheckedChange={onToggleSearch}
              disabled={isGenerating}
            />
          </div>
        </StepSection>

        {/* 5. 写作风格 Skill */}
        <StepSection
          index={5}
          title="写作风格 Skill"
          desc="可选，上传文本作为 AI 写作风格参考"
        >
          <StyleSkillManager
            selectedSkillId={selectedStyleSkillId}
            onSelect={onSelectStyleSkill}
          />
        </StepSection>
      </div>

      {/* 底部操作栏 */}
      <div className="flex items-center gap-3 border-t border-border bg-card/80 px-6 py-4 backdrop-blur-md">
        <Button
          className="flex-1 bg-brand text-brand-foreground hover:bg-brand/90"
          onClick={onGenerate}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              生成中...
            </>
          ) : (
            <>
              <Sparkles className="size-4" />
              生成文案
            </>
          )}
        </Button>
        <Button variant="ghost" onClick={onClear} disabled={isGenerating}>
          <Eraser className="size-4" />
          清空
        </Button>
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>新增促销周期</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div>
              <label className="mb-2 block t-label c-primary">周期名称</label>
              <Input
                autoFocus
                value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                placeholder="例如：开学季"
              />
            </div>
            <div>
              <label className="mb-2 block t-label c-primary">关键心智</label>
              <Textarea
                value={mindsetDraft}
                onChange={(e) => setMindsetDraft(e.target.value)}
                placeholder="选填，选中该周期后将自动填充到关键心智"
                className="min-h-20 resize-y"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAddOpen(false)}>
              取消
            </Button>
            <Button
              className="bg-brand text-brand-foreground hover:bg-brand/90"
              onClick={handleConfirmAdd}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ConfigPanel;
