import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Upload, FileText, FileArchive, Trash2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  StyleSkill,
  loadSkills,
  addSkill,
  removeSkill,
} from './styleSkillStorage';
import { parseZipStyle, ZipParseError } from './zipStyleParser';

const MAX_SIZE = 200 * 1024;
const ALLOWED_EXT = ['.txt', '.md', '.markdown'];

interface StyleSkillManagerProps {
  selectedSkillId: string | null;
  onSelect: (skill: StyleSkill | null) => void;
}

const formatTime = (ts: number): string => {
  const d = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`;
};

const StyleSkillManager: React.FC<StyleSkillManagerProps> = ({
  selectedSkillId,
  onSelect,
}) => {
  const [skills, setSkills] = useState<StyleSkill[]>(() => loadSkills());

  const handleZip = useCallback(
    async (file: File) => {
      try {
        const { merged, fileCount, truncated } = await parseZipStyle(file);
        const skill = addSkill(file.name, merged, {
          source: 'zip',
          fileCount,
        });
        setSkills(loadSkills());
        onSelect(skill);
        toast.success(`已解析压缩包内 ${fileCount} 个风格文件并选用`);
        if (truncated) {
          toast.warning('风格内容较多，已截断部分内容');
        }
      } catch (error) {
        if (error instanceof ZipParseError) {
          toast.error(error.message);
        } else {
          logger.error('解析写作风格压缩包失败', String(error));
          toast.error('压缩包解析失败，请重试');
        }
      }
    },
    [onSelect],
  );

  const handleFile = useCallback(
    (file: File) => {
      const name = file.name;
      const lower = name.toLowerCase();
      if (lower.endsWith('.zip')) {
        void handleZip(file);
        return;
      }
      const extOk = ALLOWED_EXT.some((ext) => lower.endsWith(ext));
      if (!extOk) {
        toast.error('仅支持上传 .txt / .md / .zip 文件');
        return;
      }
      if (file.size > MAX_SIZE) {
        toast.error('文件过大，请上传 200KB 以内的文本');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const content = String(reader.result ?? '').trim();
        if (!content) {
          toast.error('文件内容为空');
          return;
        }
        const skill = addSkill(name, content);
        setSkills(loadSkills());
        onSelect(skill);
        toast.success('已上传写作风格 Skill 并选用');
      };
      reader.onerror = () => {
        toast.error('文件读取失败，请重试');
      };
      reader.readAsText(file);
    },
    [handleZip, onSelect],
  );

  const onDrop = useCallback(
    (accepted: File[]) => {
      const file = accepted[0];
      if (file) handleFile(file);
    },
    [handleFile],
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: {
      'text/plain': ['.txt'],
      'text/markdown': ['.md', '.markdown'],
      'application/zip': ['.zip'],
      'application/x-zip-compressed': ['.zip'],
    },
  });

  const handleRemove = useCallback(
    (id: string) => {
      removeSkill(id);
      setSkills(loadSkills());
      if (selectedSkillId === id) onSelect(null);
    },
    [selectedSkillId, onSelect],
  );

  const handleToggle = useCallback(
    (skill: StyleSkill) => {
      if (selectedSkillId === skill.id) onSelect(null);
      else onSelect(skill);
    },
    [selectedSkillId, onSelect],
  );

  return (
    <div className="space-y-3">
      <div
        {...getRootProps()}
        className={cn(
          'flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed px-4 py-6 text-center transition-colors',
          isDragActive
            ? 'border-primary bg-accent'
            : 'border-border bg-card hover:border-primary/40 hover:bg-accent/50',
        )}
      >
        <input {...getInputProps()} />
        <Upload className="size-5 text-muted-foreground" />
        <p className="t-label c-primary">
          点击或拖拽上传写作风格 Skill
        </p>
        <p className="t-caption c-secondary">
          支持 .txt / .md / .zip，zip 内多个文本将合并为综合风格（≤5MB）
        </p>
      </div>

      {skills.length === 0 ? (
        <p className="px-1 t-caption c-secondary">
          暂无已上传的 Skill，上传后可多次选用
        </p>
      ) : (
        <div className="space-y-2">
          {skills.map((skill) => {
            const active = selectedSkillId === skill.id;
            return (
              <div
                key={skill.id}
                onClick={() => handleToggle(skill)}
                className={cn(
                  'group flex cursor-pointer items-start gap-2.5 rounded-lg border px-3 py-2.5 transition-all duration-150',
                  active
                    ? 'border-primary bg-accent shadow-sm'
                    : 'border-border bg-card hover:border-primary/40 hover:bg-accent/50',
                )}
              >
                <div
                  className={cn(
                    'mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-full border',
                    active
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-card',
                  )}
                >
                  {active && <Check className="size-3" />}
                </div>
                <FileText className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <p className="truncate t-label c-primary">
                    {skill.name}
                  </p>
                  {skill.source === 'zip' && (
                    <span className="mt-0.5 inline-flex items-center gap-1 t-caption c-subtle">
                      <FileArchive className="size-3" />
                      压缩包 · {skill.fileCount ?? 0} 个文件
                    </span>
                  )}
                  <p className="mt-0.5 line-clamp-2 t-caption c-secondary">
                    {skill.content}
                  </p>
                  <p className="mt-1 t-caption c-subtle">
                    {formatTime(skill.createdAt)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemove(skill.id);
                  }}
                  className="shrink-0 rounded-md p-1 text-muted-foreground opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                  aria-label="删除"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default StyleSkillManager;
