import React from 'react';
import { Check, ChevronDown, Plus, Trash2, X } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { CATEGORIES, CategoryOption } from './constants';
import {
  loadCustomCategories,
  addCustomCategory,
  removeCustomCategory,
} from './categoryStorage';

interface CategoryMultiSelectProps {
  value: string[];
  onChange: (next: string[]) => void;
  invalid?: boolean;
}

const CategoryMultiSelect: React.FC<CategoryMultiSelectProps> = ({
  value,
  onChange,
  invalid,
}) => {
  const [open, setOpen] = React.useState(false);
  const [customCategories, setCustomCategories] = React.useState<
    CategoryOption[]
  >(() => loadCustomCategories());
  const [adding, setAdding] = React.useState(false);
  const [draft, setDraft] = React.useState('');

  const allCategories = React.useMemo(
    () => [...CATEGORIES, ...customCategories],
    [customCategories],
  );
  const customIds = React.useMemo(
    () => new Set(customCategories.map((c) => c.id)),
    [customCategories],
  );

  const toggle = (id: string) => {
    if (value.includes(id)) {
      onChange(value.filter((v) => v !== id));
    } else {
      onChange([...value, id]);
    }
  };

  const remove = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(value.filter((v) => v !== id));
  };

  const handleDeleteCustom = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    removeCustomCategory(id);
    setCustomCategories((prev) => prev.filter((c) => c.id !== id));
    if (value.includes(id)) {
      onChange(value.filter((v) => v !== id));
    }
  };

  const handleConfirmAdd = () => {
    const label = draft.trim();
    if (!label) {
      toast.error('请输入类目名称');
      return;
    }
    const exists = allCategories.some((c) => c.label === label);
    if (exists) {
      toast.error('该类目已存在');
      return;
    }
    const item = addCustomCategory(label);
    setCustomCategories((prev) => [...prev, item]);
    onChange([...value, item.id]);
    setDraft('');
    setAdding(false);
  };

  const handleAddKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleConfirmAdd();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setDraft('');
      setAdding(false);
    }
  };

  const selectedLabels = allCategories.filter((c) => value.includes(c.id));

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className={cn(
            'flex min-h-10 w-full items-center justify-between gap-2 rounded-md border border-input bg-card px-3 py-2 text-left text-sm transition-colors',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-ring/30',
            invalid && 'border-destructive',
          )}
        >
          <div className="flex flex-1 flex-wrap items-center gap-1.5">
            {selectedLabels.length === 0 ? (
              <span className="text-muted-foreground">请选择类目（可多选）</span>
            ) : (
              selectedLabels.map((c) => (
                <Badge
                  key={c.id}
                  variant="secondary"
                  className="gap-1 bg-accent text-accent-foreground"
                >
                  {c.label}
                  <X
                    className="size-3 cursor-pointer opacity-60 hover:opacity-100"
                    onClick={(e) => remove(c.id, e)}
                  />
                </Badge>
              ))
            )}
          </div>
          <ChevronDown className="size-4 shrink-0 text-muted-foreground" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[var(--radix-popover-trigger-width)] p-1"
        align="start"
      >
        <div className="max-h-64 overflow-auto">
          {allCategories.map((c) => {
            const checked = value.includes(c.id);
            const isCustom = customIds.has(c.id);
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => toggle(c.id)}
                className={cn(
                  'flex w-full items-center justify-between rounded-sm px-2 py-2 t-body transition-colors hover:bg-accent',
                  checked && 'text-accent-foreground',
                )}
              >
                <span>{c.label}</span>
                <span className="flex items-center gap-1">
                  {checked && <Check className="size-4 text-primary" />}
                  {isCustom && (
                    <span
                      role="button"
                      tabIndex={-1}
                      aria-label="删除类目"
                      className="flex size-5 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-background hover:text-destructive"
                      onClick={(e) => handleDeleteCustom(c.id, e)}
                    >
                      <Trash2 className="size-3.5" />
                    </span>
                  )}
                </span>
              </button>
            );
          })}
        </div>
        <div className="mt-1 border-t border-border pt-1">
          {adding ? (
            <div className="flex items-center gap-1.5 px-1 py-1">
              <Input
                autoFocus
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={handleAddKeyDown}
                placeholder="输入新类目名称"
                className="h-8 text-sm"
              />
              <button
                type="button"
                onClick={handleConfirmAdd}
                className="flex h-8 shrink-0 items-center rounded-md bg-primary px-3 t-label text-primary-foreground transition-colors hover:bg-primary/90"
              >
                确认
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setAdding(true)}
              className="flex w-full items-center gap-2 rounded-sm px-2 py-2 t-body c-secondary transition-colors hover:bg-accent hover:text-foreground"
            >
              <Plus className="size-4" />
              新增类目
            </button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default CategoryMultiSelect;
