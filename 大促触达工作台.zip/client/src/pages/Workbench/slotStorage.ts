import { logger } from '@lark-apaas/client-toolkit/logger';

export type SlotMode = 'popup' | 'pc';

export interface ResourceSlot {
  key: string;
  label: string;
  mode: SlotMode;
  builtin?: boolean;
}

export const BUILTIN_SLOTS: ResourceSlot[] = [
  {
    key: 'pc_s_card_app_belt',
    label: 'PC抖店S卡及APP大促氛围&腰封',
    mode: 'pc',
    builtin: true,
  },
  { key: 'popup', label: '弹窗', mode: 'popup', builtin: true },
];

const CUSTOM_SLOTS_KEY = 'workbench:custom-slots';
const LABEL_OVERRIDES_KEY = 'workbench:slot-label-overrides';

const loadCustomSlots = (): ResourceSlot[] => {
  try {
    const raw = localStorage.getItem(CUSTOM_SLOTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as ResourceSlot[];
      if (Array.isArray(parsed)) {
        return parsed.map((s) => ({ ...s, builtin: false }));
      }
    }
  } catch (error) {
    logger.warn('读取自定义资源位缓存失败', String(error));
  }
  return [];
};

const saveCustomSlots = (list: ResourceSlot[]): void => {
  try {
    localStorage.setItem(CUSTOM_SLOTS_KEY, JSON.stringify(list));
  } catch (error) {
    logger.warn('保存自定义资源位缓存失败', String(error));
  }
};

const loadLabelOverrides = (): Record<string, string> => {
  try {
    const raw = localStorage.getItem(LABEL_OVERRIDES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Record<string, string>;
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch (error) {
    logger.warn('读取资源位名称覆盖缓存失败', String(error));
  }
  return {};
};

const saveLabelOverrides = (overrides: Record<string, string>): void => {
  try {
    localStorage.setItem(LABEL_OVERRIDES_KEY, JSON.stringify(overrides));
  } catch (error) {
    logger.warn('保存资源位名称覆盖缓存失败', String(error));
  }
};

export const getAllSlots = (): ResourceSlot[] => {
  const overrides = loadLabelOverrides();
  const builtin = BUILTIN_SLOTS.map((s) => ({
    ...s,
    label: overrides[s.key] ?? s.label,
  }));
  return [...builtin, ...loadCustomSlots()];
};

export const getSlotMode = (key: string): SlotMode =>
  getAllSlots().find((s) => s.key === key)?.mode ?? 'popup';

export const addCustomSlot = (label: string, mode: SlotMode): ResourceSlot => {
  const item: ResourceSlot = {
    key: `slot_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    label: label.trim(),
    mode,
    builtin: false,
  };
  saveCustomSlots([...loadCustomSlots(), item]);
  return item;
};

export const renameSlot = (key: string, label: string): void => {
  const trimmed = label.trim();
  if (!trimmed) return;
  const isBuiltin = BUILTIN_SLOTS.some((s) => s.key === key);
  if (isBuiltin) {
    const overrides = loadLabelOverrides();
    overrides[key] = trimmed;
    saveLabelOverrides(overrides);
    return;
  }
  const list = loadCustomSlots().map((s) =>
    s.key === key ? { ...s, label: trimmed } : s,
  );
  saveCustomSlots(list);
};

export const removeCustomSlot = (key: string): void => {
  saveCustomSlots(loadCustomSlots().filter((s) => s.key !== key));
};
