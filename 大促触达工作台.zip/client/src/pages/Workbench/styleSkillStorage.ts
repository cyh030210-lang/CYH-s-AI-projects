import { logger } from '@lark-apaas/client-toolkit/logger';

const STORAGE_KEY = 'workbench:style-skills';
const SELECTED_KEY = 'workbench:style-skill-selected';

export const DEFAULT_STYLE_SKILL_NAME = 'outreach-copy-writer (2).zip';
const DEFAULT_STYLE_SKILL_KEYWORD = 'outreach-copy-writer';

export interface StyleSkill {
  id: string;
  name: string;
  content: string;
  createdAt: number;
  source?: 'file' | 'zip';
  fileCount?: number;
}

export const loadSkills = (): StyleSkill[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as StyleSkill[];
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    logger.warn('读取写作风格 skill 缓存失败', String(error));
    return [];
  }
};

const writeSkills = (skills: StyleSkill[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(skills));
  } catch (error) {
    logger.warn('保存写作风格 skill 缓存失败', String(error));
  }
};

export const addSkill = (
  name: string,
  content: string,
  meta?: { source?: 'file' | 'zip'; fileCount?: number },
): StyleSkill => {
  const skill: StyleSkill = {
    id: `skill_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name,
    content,
    createdAt: Date.now(),
    source: meta?.source ?? 'file',
    fileCount: meta?.fileCount,
  };
  const skills = loadSkills();
  skills.unshift(skill);
  writeSkills(skills);
  return skill;
};

export const removeSkill = (id: string): void => {
  const skills = loadSkills().filter((s) => s.id !== id);
  writeSkills(skills);
};

export const saveSelectedSkillId = (id: string | null): void => {
  try {
    if (id) localStorage.setItem(SELECTED_KEY, id);
    else localStorage.removeItem(SELECTED_KEY);
  } catch (error) {
    logger.warn('保存写作风格选中态失败', String(error));
  }
};

export const loadSelectedSkillId = (): string | null => {
  try {
    return localStorage.getItem(SELECTED_KEY);
  } catch (error) {
    logger.warn('读取写作风格选中态失败', String(error));
    return null;
  }
};

export const resolveDefaultSkill = (): StyleSkill | null => {
  const skills = loadSkills();
  if (skills.length === 0) return null;

  const selectedId = loadSelectedSkillId();
  if (selectedId) {
    const matched = skills.find((s) => s.id === selectedId);
    if (matched) return matched;
  }

  const exact = skills.find((s) => s.name === DEFAULT_STYLE_SKILL_NAME);
  if (exact) return exact;

  const fuzzy = skills.find((s) =>
    s.name.toLowerCase().includes(DEFAULT_STYLE_SKILL_KEYWORD),
  );
  return fuzzy ?? null;
};
