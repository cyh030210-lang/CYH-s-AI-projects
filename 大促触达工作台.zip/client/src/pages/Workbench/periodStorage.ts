import { logger } from '@lark-apaas/client-toolkit/logger';
import { PROMOTION_PERIODS, PromotionPeriod } from './constants';

const STORAGE_KEY = 'workbench:custom-periods';

export const loadCustomPeriods = (): PromotionPeriod[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as PromotionPeriod[]) : [];
  } catch (error) {
    logger.warn('读取自定义促销周期本地缓存失败', String(error));
    return [];
  }
};

const saveCustomPeriods = (list: PromotionPeriod[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch (error) {
    logger.warn('保存自定义促销周期到本地缓存失败', String(error));
  }
};

export const addCustomPeriod = (
  label: string,
  defaultMindset: string,
): PromotionPeriod => {
  const item: PromotionPeriod = {
    id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    label: label.trim(),
    defaultMindset: defaultMindset.trim(),
  };
  const list = loadCustomPeriods();
  saveCustomPeriods([...list, item]);
  return item;
};

export const removeCustomPeriod = (id: string): void => {
  const list = loadCustomPeriods();
  saveCustomPeriods(list.filter((p) => p.id !== id));
};

export const getAllPeriods = (): PromotionPeriod[] => [
  ...PROMOTION_PERIODS,
  ...loadCustomPeriods(),
];
