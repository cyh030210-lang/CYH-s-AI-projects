import { logger } from '@lark-apaas/client-toolkit/logger';

const STORAGE_KEY = 'workbench:reach-tasks';

export interface ReachTask {
  id: string;
  name: string;
  dateCode: string;
  categoryId: string;
  categoryLabel: string;
  description: string;
  createdAt: number;
}

export const loadTasks = (): ReachTask[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as ReachTask[];
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    logger.warn('读取触达任务缓存失败', String(error));
    return [];
  }
};

const writeTasks = (tasks: ReachTask[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    logger.warn('保存触达任务缓存失败', String(error));
  }
};

export interface AddTasksResult {
  added: ReachTask[];
  skipped: number;
}

export const addTasks = (tasks: ReachTask[]): AddTasksResult => {
  const existing = loadTasks();
  const existingIds = new Set(existing.map((t) => t.id));
  const added: ReachTask[] = [];
  let skipped = 0;
  tasks.forEach((task) => {
    if (existingIds.has(task.id)) {
      skipped += 1;
    } else {
      existingIds.add(task.id);
      added.push(task);
    }
  });
  if (added.length > 0) {
    writeTasks([...added, ...existing]);
  }
  return { added, skipped };
};

export const removeTask = (id: string): void => {
  writeTasks(loadTasks().filter((t) => t.id !== id));
};

export const clearTasks = (): void => {
  writeTasks([]);
};
