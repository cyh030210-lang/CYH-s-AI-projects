import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
} from 'docx';
import { CopyResult } from './useCopyGeneration';

export interface ExportCopyItem {
  categoryLabel: string;
  content: string;
}

export const buildExportItems = (results: CopyResult[]): ExportCopyItem[] => {
  const multiMindset = results.some((r) => r.mindsetIndex > 0);
  return results
    .filter((r) => r.status === 'success' && r.content.trim())
    .map((r) => ({
      categoryLabel: multiMindset
        ? `${r.categoryLabel} · ${r.mindsetLabel}`
        : r.categoryLabel,
      content: r.content.trim(),
    }));
};

const sanitizeFileName = (name: string): string =>
  name.replace(/[/\\:*?"<>|]/gu, '_').trim() || '营销文案';

const triggerDownload = (blob: Blob, filename: string): void => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const exportAsMarkdown = (
  items: ExportCopyItem[],
  title: string,
): void => {
  const safeTitle = sanitizeFileName(title);
  const body = items
    .map((item) => `## ${item.categoryLabel}\n\n${item.content}`)
    .join('\n\n');
  const md = `# ${safeTitle}\n\n${body}\n`;
  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  triggerDownload(blob, `${safeTitle}.md`);
};

export const exportAsWord = async (
  items: ExportCopyItem[],
  title: string,
): Promise<void> => {
  const safeTitle = sanitizeFileName(title);
  const children: Paragraph[] = [
    new Paragraph({ text: safeTitle, heading: HeadingLevel.HEADING_1 }),
  ];

  for (const item of items) {
    children.push(
      new Paragraph({
        text: item.categoryLabel,
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 240, after: 120 },
      }),
    );
    const lines = item.content.split('\n');
    for (const line of lines) {
      children.push(
        new Paragraph({
          children: [new TextRun(line)],
          spacing: { after: 80 },
        }),
      );
    }
  }

  const doc = new Document({ sections: [{ children }] });
  const blob = await Packer.toBlob(doc);
  triggerDownload(blob, `${safeTitle}.docx`);
};
