import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  ResourceSlot,
  SlotMode,
  getAllSlots,
  addCustomSlot,
  renameSlot,
  removeCustomSlot,
} from './slotStorage';

interface SlotManageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
}

const MODE_LABEL: Record<SlotMode, string> = {
  popup: '弹窗模式',
  pc: 'S卡模式',
};

const SlotManageDialog: React.FC<SlotManageDialogProps> = ({
  open,
  onOpenChange,
  onChanged,
}) => {
  const [slots, setSlots] = useState<ResourceSlot[]>([]);
  const [labels, setLabels] = useState<Record<string, string>>({});
  const [newLabel, setNewLabel] = useState('');
  const [newMode, setNewMode] = useState<SlotMode>('popup');

  const refresh = (): void => {
    const list = getAllSlots();
    setSlots(list);
    setLabels(
      list.reduce<Record<string, string>>((acc, s) => {
        acc[s.key] = s.label;
        return acc;
      }, {}),
    );
  };

  useEffect(() => {
    if (open) {
      refresh();
      setNewLabel('');
      setNewMode('popup');
    }
  }, [open]);

  const handleRenameBlur = (slot: ResourceSlot): void => {
    const next = (labels[slot.key] ?? '').trim();
    if (!next) {
      setLabels((prev) => ({ ...prev, [slot.key]: slot.label }));
      toast.error('资源位名称不能为空');
      return;
    }
    if (next === slot.label) return;
    const duplicate = slots.some(
      (s) => s.key !== slot.key && s.label === next,
    );
    if (duplicate) {
      setLabels((prev) => ({ ...prev, [slot.key]: slot.label }));
      toast.error('已存在同名资源位');
      return;
    }
    renameSlot(slot.key, next);
    refresh();
    onChanged();
  };

  const handleDelete = (slot: ResourceSlot): void => {
    removeCustomSlot(slot.key);
    refresh();
    onChanged();
  };

  const handleAdd = (): void => {
    const label = newLabel.trim();
    if (!label) {
      toast.error('请输入资源位名称');
      return;
    }
    if (slots.some((s) => s.label === label)) {
      toast.error('已存在同名资源位');
      return;
    }
    addCustomSlot(label, newMode);
    setNewLabel('');
    setNewMode('popup');
    refresh();
    onChanged();
    toast.success('已新增资源位');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>管理资源位</DialogTitle>
          <DialogDescription>
            重命名任意资源位，或新增自定义资源位并指定生成模式。弹窗模式按触达类目+日期生成；S卡模式按促销周期+阶段生成。
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          {slots.map((slot) => (
            <div
              key={slot.key}
              className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2"
            >
              <Input
                value={labels[slot.key] ?? ''}
                onChange={(e) =>
                  setLabels((prev) => ({ ...prev, [slot.key]: e.target.value }))
                }
                onBlur={() => handleRenameBlur(slot)}
                className="flex-1"
              />
              <span className="shrink-0 rounded-md bg-accent px-2 py-0.5 t-caption text-brand">
                {MODE_LABEL[slot.mode]}
              </span>
              {slot.builtin ? (
                <span className="shrink-0 t-caption c-secondary">内置</span>
              ) : (
                <button
                  type="button"
                  aria-label="删除资源位"
                  onClick={() => handleDelete(slot)}
                  className="flex size-8 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        <div className="rounded-lg border border-dashed border-border p-3">
          <label className="mb-2 block t-label c-primary">新增资源位</label>
          <div className="flex items-center gap-2">
            <Input
              value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              placeholder="资源位名称"
              className="flex-1"
            />
            <Select
              value={newMode}
              onValueChange={(v) => setNewMode(v as SlotMode)}
            >
              <SelectTrigger className="w-32 shrink-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popup">弹窗模式</SelectItem>
                <SelectItem value="pc">S卡模式</SelectItem>
              </SelectContent>
            </Select>
            <Button
              type="button"
              className="shrink-0 gap-1 bg-brand text-brand-foreground hover:bg-brand/90"
              onClick={handleAdd}
            >
              <Plus className="size-4" />
              新增
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            完成
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SlotManageDialog;
