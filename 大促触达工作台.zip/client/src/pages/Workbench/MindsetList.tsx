import React from 'react';
import { Lightbulb, Plus, X } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

interface MindsetListProps {
  values: string[];
  invalid?: boolean;
  onChange: (index: number, value: string) => void;
  onAdd: () => void;
  onRemove: (index: number) => void;
}

const MindsetList: React.FC<MindsetListProps> = ({
  values,
  invalid,
  onChange,
  onAdd,
  onRemove,
}) => {
  return (
    <div>
      <div className="mb-2.5 flex items-start gap-2 rounded-md border border-border bg-muted/50 px-3 py-2 t-caption c-secondary">
        <Lightbulb className="mt-0.5 size-3.5 shrink-0" />
        <span>
          关键心智将影响文案的方向、利益点和表达重点。可新增多条，每个类目将围绕每条心智各生成一条文案
        </span>
      </div>

      <div className="space-y-3">
        {values.map((value, index) => (
          <div key={index}>
            <div className="mb-1.5 flex items-center justify-between">
              <span className="t-caption font-medium c-secondary">
                {index === 0 ? '默认心智' : `心智${index + 1}`}
              </span>
              {index > 0 && (
                <button
                  type="button"
                  onClick={() => onRemove(index)}
                  aria-label="删除该心智"
                  className="flex items-center gap-0.5 t-caption c-secondary transition-colors hover:text-destructive"
                >
                  <X className="size-3" />
                  删除
                </button>
              )}
            </div>
            <Textarea
              value={value}
              onChange={(e) => onChange(index, e.target.value)}
              placeholder={
                index === 0
                  ? '选择促销周期后自动填充，可自由修改。例如：大促爆发、流量加码、成交增长、限时报名'
                  : '输入另一条关键心智，将单独生成一条文案'
              }
              className={cn(
                'min-h-24 resize-y',
                invalid && !value.trim() && 'border-destructive',
              )}
            />
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={onAdd}
        className="mt-3 flex w-full items-center justify-center gap-1 rounded-lg border border-dashed border-border px-2 py-2.5 t-label c-secondary transition-colors hover:border-brand/40 hover:text-brand"
      >
        <Plus className="size-3.5" />
        新增心智
      </button>

      {invalid && (
        <p className="mt-1.5 t-caption text-destructive">
          关键心智不能为空，请填写或删除空白项
        </p>
      )}
    </div>
  );
};

export default MindsetList;
