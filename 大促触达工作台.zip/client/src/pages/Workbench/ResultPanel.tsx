import React from 'react';
import { Sparkles, AlertCircle, Copy, Download, Loader2, PenLine } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { CopyResult } from './useCopyGeneration';
import CopyCard from './CopyCard';
import {
  ExportCopyItem,
  buildExportItems,
  exportAsMarkdown,
  exportAsWord,
} from './exportCopy';

interface ResultPanelProps {
  hasStarted: boolean;
  results: CopyResult[];
  exportTitle: string;
  onRetry: (categoryId: string) => void;
  onCopyAll: () => void;
}

const GUIDE_STEPS = ['选周期', '选类目', '确认心智', '生成'];

const EmptyGuide: React.FC = () => (
  <div className="flex h-full flex-col items-center justify-center px-8 py-16 text-center">
    <div className="mb-7 flex size-16 items-center justify-center rounded-full border border-border bg-muted/60">
      <PenLine className="size-7 text-muted-foreground" strokeWidth={1.5} />
    </div>
    <h3 className="mb-2.5 t-heading c-primary">
      准备就绪
    </h3>
    <p className="max-w-sm t-body c-secondary">
      在左侧配置促销周期、类目、关键心智与写作风格，点击「生成文案」即可获得贴合业务触达场景的营销文案。
    </p>
    <div className="mt-7 flex flex-wrap items-center justify-center gap-x-3 gap-y-2 t-caption c-secondary">
      {GUIDE_STEPS.map((hint, i) => (
        <React.Fragment key={hint}>
          {i > 0 && <span className="text-border">·</span>}
          <span className="tabular-nums">
            <span className="mr-1 text-foreground/40">{i + 1}</span>
            {hint}
          </span>
        </React.Fragment>
      ))}
    </div>
  </div>
);

const LoadingCard: React.FC<{ label: string; hint?: string }> = ({
  label,
  hint,
}) => (
  <div className="rounded-lg border border-border bg-card p-6 shadow-sm">
    <div className="mb-4 flex items-center justify-between">
      <span className="rounded-md bg-muted px-2.5 py-0.5 t-caption font-medium c-primary">
        {label}
      </span>
      <Skeleton className="h-4 w-10 rounded bg-muted" />
    </div>
    {hint && (
      <div className="mb-3 flex items-center gap-1.5 t-caption c-secondary">
        <Loader2 className="size-3.5 animate-spin text-muted-foreground" />
        {hint}
      </div>
    )}
    <div className="space-y-2">
      <Skeleton className="h-4 w-full bg-muted" />
      <Skeleton className="h-4 w-[92%] bg-muted" />
      <Skeleton className="h-4 w-[78%] bg-muted" />
    </div>
  </div>
);

const ErrorCard: React.FC<{
  result: CopyResult;
  label: string;
  onRetry: () => void;
}> = ({ result, label, onRetry }) => (
  <div className="rounded-lg border border-destructive/40 bg-card p-6 shadow-sm">
    <div className="mb-3 flex items-center justify-between">
      <span className="rounded-md bg-muted px-2.5 py-0.5 t-caption font-medium c-primary">
        {label}
      </span>
    </div>
    <div className="flex items-center gap-2 t-body text-destructive">
      <AlertCircle className="size-4" />
      {result.error || '生成失败'}
    </div>
    <Button variant="outline" size="sm" className="mt-4" onClick={onRetry}>
      重试
    </Button>
  </div>
);

const ResultHeader: React.FC<{
  total: number;
  done: number;
  failed: number;
  canCopyAll: boolean;
  items: ExportCopyItem[];
  exportTitle: string;
  onCopyAll: () => void;
}> = ({ total, done, failed, canCopyAll, items, exportTitle, onCopyAll }) => {
  const handleExportWord = async () => {
    try {
      await exportAsWord(items, exportTitle);
      toast.success(`已导出 ${items.length} 条文案（Word）`);
    } catch (error) {
      logger.error('导出 Word 失败', String(error));
      toast.error('导出失败，请重试');
    }
  };

  const handleExportMarkdown = () => {
    try {
      exportAsMarkdown(items, exportTitle);
      toast.success(`已导出 ${items.length} 条文案（Markdown）`);
    } catch (error) {
      logger.error('导出 Markdown 失败', String(error));
      toast.error('导出失败，请重试');
    }
  };

  return (
    <div className="flex shrink-0 items-center justify-between border-b border-border bg-background/80 px-6 py-5 backdrop-blur-md">
      <div>
        <h2 className="t-heading c-primary">生成结果</h2>
        <p className="mt-0.5 t-caption c-secondary tabular-nums">
          共 {total} 条 · 完成 {done}
          {failed > 0 && (
            <span className="text-destructive"> · 失败 {failed}</span>
          )}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              disabled={!canCopyAll}
            >
              <Download className="size-3.5" />
              导出
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleExportWord}>
              导出为 Word
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleExportMarkdown}>
              导出为 Markdown
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={!canCopyAll}
          onClick={onCopyAll}
        >
          <Copy className="size-3.5" />
          全部复制
        </Button>
      </div>
    </div>
  );
};

const ResultPanel: React.FC<ResultPanelProps> = ({
  hasStarted,
  results,
  exportTitle,
  onRetry,
  onCopyAll,
}) => {
  if (!hasStarted) {
    return <EmptyGuide />;
  }

  const total = results.length;
  const done = results.filter((r) => r.status === 'success').length;
  const failed = results.filter((r) => r.status === 'error').length;
  const exportItems = buildExportItems(results);
  const multiMindset = results.some((r) => r.mindsetIndex > 0);

  const renderCard = (result: CopyResult): React.ReactNode => {
    const label = multiMindset ? result.mindsetLabel : result.categoryLabel;
    if (result.status === 'error') {
      return (
        <ErrorCard
          key={result.id}
          result={result}
          label={label}
          onRetry={() => onRetry(result.id)}
        />
      );
    }
    if (result.status === 'pending' || result.status === 'searching') {
      return (
        <LoadingCard
          key={result.id}
          label={label}
          hint={
            result.status === 'searching'
              ? '正在联网搜索消费趋势…'
              : '正在生成文案…'
          }
        />
      );
    }
    return <CopyCard key={result.id} result={result} label={label} />;
  };

  const groups: { categoryId: string; categoryLabel: string; items: CopyResult[] }[] =
    [];
  results.forEach((r) => {
    const group = groups.find((g) => g.categoryId === r.categoryId);
    if (group) {
      group.items.push(r);
    } else {
      groups.push({
        categoryId: r.categoryId,
        categoryLabel: r.categoryLabel,
        items: [r],
      });
    }
  });

  return (
    <div className="flex h-full flex-col">
      <ResultHeader
        total={total}
        done={done}
        failed={failed}
        canCopyAll={done > 0}
        items={exportItems}
        exportTitle={exportTitle}
        onCopyAll={onCopyAll}
      />
      <div className="flex-1 space-y-4 overflow-auto p-6">
        {multiMindset
          ? groups.map((group) => (
              <div key={group.categoryId} className="space-y-3">
                <div className="flex items-center gap-2 t-label c-secondary">
                  <span className="font-medium text-foreground">
                    {group.categoryLabel}
                  </span>
                  <span className="tabular-nums">{group.items.length} 条</span>
                </div>
                {group.items.map((result) => renderCard(result))}
              </div>
            ))
          : results.map((result) => renderCard(result))}
      </div>
    </div>
  );
};

export default ResultPanel;
