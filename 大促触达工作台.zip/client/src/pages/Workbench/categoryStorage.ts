import { logger } from '@lark-apaas/client-toolkit/logger';
import { CATEGORIES, CategoryOption } from './constants';

const STORAGE_KEY = 'workbench:custom-categories';

export const loadCustomCategories = (): CategoryOption[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as CategoryOption[]) : [];
  } catch (error) {
    logger.warn('读取自定义类目本地缓存失败', String(error));
    return [];
  }
};

const saveCustomCategories = (list: CategoryOption[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch (error) {
    logger.warn('保存自定义类目到本地缓存失败', String(error));
  }
};

export const addCustomCategory = (label: string): CategoryOption => {
  const item: CategoryOption = {
    id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    label: label.trim(),
  };
  const list = loadCustomCategories();
  saveCustomCategories([...list, item]);
  return item;
};

export const removeCustomCategory = (id: string): void => {
  const list = loadCustomCategories();
  saveCustomCategories(list.filter((c) => c.id !== id));
};

export const getAllCategories = (): CategoryOption[] => [
  ...CATEGORIES,
  ...loadCustomCategories(),
];
