import React, { useState } from 'react';
import { toast } from 'sonner';
import {
  Copy,
  Trash2,
  ClipboardList,
  ChevronDown,
  FileText,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { cn } from '@/lib/utils';
import { ReachTask } from './reachTaskStorage';

interface ReachTaskListProps {
  tasks: ReachTask[];
  onRemove: (id: string) => void;
}

const ReachTaskList: React.FC<ReachTaskListProps> = ({ tasks, onRemove }) => {
  const [collapsedIds, setCollapsedIds] = useState<Set<string>>(new Set());

  const toggleExpand = (id: string) => {
    setCollapsedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleCopy = async (text: string, message: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(message);
    } catch (error) {
      logger.warn('复制触达任务内容失败', String(error));
      toast.error('复制失败，请手动复制');
    }
  };

  if (tasks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card px-4 py-10 text-center">
        <ClipboardList className="size-6 text-muted-foreground" />
        <p className="mt-2 t-body c-secondary">
          暂无触达任务，选择类目后点击生成
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {tasks.map((task) => {
        const expanded = !collapsedIds.has(task.id);
        return (
          <div
            key={task.id}
            className="group rounded-lg border border-border bg-card px-3.5 py-3 shadow-sm transition-colors hover:border-foreground/30"
          >
            <div className="flex items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className="truncate t-label c-primary">
                  {task.name}
                </p>
              </div>
              <button
                type="button"
                onClick={() => toggleExpand(task.id)}
                className={cn(
                  'flex shrink-0 items-center gap-1 rounded-md px-1.5 py-1.5 t-caption c-secondary transition-colors hover:bg-accent hover:text-accent-foreground',
                )}
                aria-label="展开描述"
              >
                <FileText className="size-4" />
                <ChevronDown
                  className={cn(
                    'size-3.5 transition-transform',
                    expanded && 'rotate-180',
                  )}
                />
              </button>
              <button
                type="button"
                onClick={() => handleCopy(task.name, '已复制任务名称')}
                className="shrink-0 rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                aria-label="复制任务名称"
              >
                <Copy className="size-4" />
              </button>
              <button
                type="button"
                onClick={() => onRemove(task.id)}
                className="shrink-0 rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                aria-label="删除任务"
              >
                <Trash2 className="size-4" />
              </button>
            </div>

            {expanded && (
              <div className="mt-3 rounded-md bg-muted p-3">
                {task.description ? (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="t-caption font-medium c-primary">
                        触达任务描述
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          handleCopy(task.description, '已复制描述')
                        }
                        className="flex items-center gap-1 rounded-md px-1.5 py-1 t-caption c-secondary transition-colors hover:bg-accent hover:text-accent-foreground"
                      >
                        <Copy className="size-3.5" />
                        复制描述
                      </button>
                    </div>
                    <p className="mt-2 whitespace-pre-wrap t-body c-secondary">
                      {task.description}
                    </p>
                  </>
                ) : (
                  <p className="t-body c-secondary">暂无描述</p>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default ReachTaskList;
