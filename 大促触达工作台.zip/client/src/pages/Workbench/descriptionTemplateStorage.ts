import { logger } from '@lark-apaas/client-toolkit/logger';

const STORAGE_KEY_PREFIX = 'workbench:reach-description-template';

const storageKey = (slot: string): string => `${STORAGE_KEY_PREFIX}:${slot}`;

export const TEMPLATE_TOKENS: { token: string; label: string }[] = [
  { token: '{periodLabel}', label: '大促周期' },
  { token: '{categoryLabel}', label: '类目名称' },
  { token: '{reachRate}', label: '报名率' },
  { token: '{completeRate}', label: '完成率' },
  { token: '{volume}', label: '量级' },
];

export const DEFAULT_DESCRIPTION_TEMPLATE =
  '【1】触达目标和收益：对于{categoryLabel}报名大促商品全店不足{reachRate}的商家，' +
  '发送图文弹窗、push触达，敦促商家报名；本阶段预计完成率持平/略领先上阶段平均完成率{completeRate}\n' +
  '【2】触达人群画像：符合报名门槛，且非官旗/双高/世界杯/重点类目核品，' +
  '且全店报名大促商品占比不足{reachRate}的近7天抖店活跃普通正常营业商家；量级为{volume}\n' +
  '【３】对商家权益：报名后享受大促资源权益，促进订单转化，提升成交';

export const PC_DEFAULT_DESCRIPTION_TEMPLATE =
  '【１】触达目的和收益：通过pc首页s卡、app二级页面动态、pc二级页面动态这三个资源位向商家传达{periodLabel}活动利益点，督促商家报名；预期本次触达率持平/略高于上期平均触达率（{completeRate}）\n' +
  '【２】触达人群画像：全体商家，量级：{volume}（正常营业的普通店，且双端后台活跃度＞0）\n' +
  '【３】对商家权益：了解并报名{periodLabel}大促，提升成交额';

export const loadDescriptionTemplate = (slot: string): string => {
  try {
    const raw = localStorage.getItem(storageKey(slot));
    return raw && raw.trim() ? raw : DEFAULT_DESCRIPTION_TEMPLATE;
  } catch (error) {
    logger.warn('读取触达描述模板本地缓存失败', String(error));
    return DEFAULT_DESCRIPTION_TEMPLATE;
  }
};

export const saveDescriptionTemplate = (slot: string, value: string): void => {
  try {
    localStorage.setItem(storageKey(slot), value);
  } catch (error) {
    logger.warn('保存触达描述模板到本地缓存失败', String(error));
  }
};

export const resetDescriptionTemplate = (slot: string): void => {
  try {
    localStorage.removeItem(storageKey(slot));
  } catch (error) {
    logger.warn('重置触达描述模板本地缓存失败', String(error));
  }
};

export const renderDescriptionTemplate = (
  template: string,
  params: {
    periodLabel: string;
    categoryLabel: string;
    reachRate: string;
    completeRate: string;
    volume: string;
  },
): string => {
  const volume = params.volume.trim() || '—';
  return template
    .replace(/\{periodLabel\}/g, params.periodLabel)
    .replace(/\{categoryLabel\}/g, params.categoryLabel)
    .replace(/\{reachRate\}/g, params.reachRate)
    .replace(/\{completeRate\}/g, params.completeRate)
    .replace(/\{volume\}/g, volume);
};
