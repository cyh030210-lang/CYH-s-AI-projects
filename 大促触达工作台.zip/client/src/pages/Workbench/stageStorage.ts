import { logger } from '@lark-apaas/client-toolkit/logger';
import { REACH_STAGES, ReachStage } from './constants';

const STORAGE_KEY = 'workbench:custom-stages';

export const loadCustomStages = (): ReachStage[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as ReachStage[]) : [];
  } catch (error) {
    logger.warn('读取自定义触达阶段本地缓存失败', String(error));
    return [];
  }
};

const saveCustomStages = (list: ReachStage[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch (error) {
    logger.warn('保存自定义触达阶段到本地缓存失败', String(error));
  }
};

export const addCustomStage = (label: string): ReachStage => {
  const item: ReachStage = {
    id: `custom_stage_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    label: label.trim(),
  };
  const list = loadCustomStages();
  saveCustomStages([...list, item]);
  return item;
};

export const removeCustomStage = (id: string): void => {
  const list = loadCustomStages();
  saveCustomStages(list.filter((s) => s.id !== id));
};

export const getAllStages = (): ReachStage[] => [
  ...REACH_STAGES,
  ...loadCustomStages(),
];
