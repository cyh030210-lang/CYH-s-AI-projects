import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Plus, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { TEMPLATE_TOKENS } from './descriptionTemplateStorage';
import {
  CopyScheme,
  NAME_TOKENS,
  PC_NAME_TOKENS,
  PC_DEFAULT_NAME_TEMPLATE,
  getScopesForSlot,
  loadSchemes,
  getActiveScheme,
  addScheme,
  removeScheme,
  saveSchemes,
  setActiveScheme,
} from './copySchemeStorage';
import { SlotMode } from './slotStorage';

interface DefaultConfigDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  slot: string;
  slotLabel: string;
  slotMode: SlotMode;
  onSaved: () => void;
}

const TokenChips: React.FC<{ tokens: { token: string; label: string }[] }> = ({
  tokens,
}) => (
  <div className="mb-2 flex flex-wrap items-center gap-1.5">
    <span className="t-caption c-secondary">可用变量：</span>
    {tokens.map((t) => (
      <span
        key={t.token}
        className="rounded-md bg-accent px-2 py-0.5 font-mono t-caption text-brand"
      >
        {t.token}
        <span className="ml-1 font-sans text-accent-foreground/70">
          {t.label}
        </span>
      </span>
    ))}
  </div>
);

const DefaultConfigDialog: React.FC<DefaultConfigDialogProps> = ({
  open,
  onOpenChange,
  slot,
  slotLabel,
  slotMode,
  onSaved,
}) => {
  const scopes = getScopesForSlot(slot, slotLabel, slotMode);
  const isPcMode = slotMode === 'pc';
  const [scopeKey, setScopeKey] = useState<string>('');
  const [schemes, setSchemes] = useState<CopyScheme[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [activeId, setActiveId] = useState<string>('');

  const loadScope = (scope: string): void => {
    const list = loadSchemes(scope, slotMode);
    const active = getActiveScheme(scope, slotMode);
    setSchemes(list);
    setSelectedId(active.id);
    setActiveId(active.id);
  };

  useEffect(() => {
    if (open) {
      const firstScope = scopes[0].key;
      setScopeKey(firstScope);
      loadScope(firstScope);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, slot]);

  const persistCurrentScope = (): void => {
    if (!scopeKey) return;
    saveSchemes(scopeKey, schemes);
    setActiveScheme(scopeKey, activeId);
  };

  const handleScopeChange = (nextScope: string): void => {
    if (nextScope === scopeKey) return;
    persistCurrentScope();
    setScopeKey(nextScope);
    loadScope(nextScope);
  };

  const selected = schemes.find((s) => s.id === selectedId) ?? null;

  const patchSelected = (patch: Partial<CopyScheme>): void => {
    setSchemes((prev) =>
      prev.map((s) => (s.id === selectedId ? { ...s, ...patch } : s)),
    );
  };

  const handleAdd = (): void => {
    const item = addScheme(scopeKey, '', slotMode);
    setSchemes((prev) => [...prev, item]);
    setSelectedId(item.id);
  };

  const handleDelete = (id: string, e: React.MouseEvent): void => {
    e.stopPropagation();
    if (schemes.length <= 1) {
      toast.error('至少保留一个方案');
      return;
    }
    const next = removeScheme(scopeKey, id, slotMode);
    setSchemes(next);
    if (selectedId === id) {
      setSelectedId(next[0].id);
    }
    if (activeId === id) {
      setActiveId(next[0].id);
      setActiveScheme(scopeKey, next[0].id);
    }
  };

  const handleSave = (): void => {
    const invalid = schemes.find(
      (s) => !s.name.trim() || !s.nameTemplate.trim() || !s.descTemplate.trim(),
    );
    if (invalid) {
      toast.error('方案名称、任务名称、任务描述均不能为空');
      setSelectedId(invalid.id);
      return;
    }
    saveSchemes(scopeKey, schemes);
    setActiveScheme(scopeKey, activeId);
    onSaved();
    toast.success('已保存文案方案');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{slotLabel}｜文案方案配置</DialogTitle>
          <DialogDescription>
            为「{slotLabel}」维护多套文案方案，每套含触达任务名称与任务描述模板；
            设为「当前生效」的方案将在生成任务时使用。触达任务名称的命名规则为“
            {slot === 'pc_s_card_app_belt'
              ? '大促周期-资源位名称-阶段'
              : isPcMode
                ? '大促周期-资源位名称-阶段'
                : '日期｜类目名or自定义｜资源位'}
            ”
          </DialogDescription>
        </DialogHeader>

        {scopes.length > 1 && (
          <div>
            <label className="mb-2 block t-label c-primary">文案分组</label>
            <Select value={scopeKey} onValueChange={handleScopeChange}>
              <SelectTrigger className="min-h-10 w-full">
                <SelectValue placeholder="请选择文案分组" />
              </SelectTrigger>
              <SelectContent>
                {scopes.map((sc) => (
                  <SelectItem key={sc.key} value={sc.key}>
                    {sc.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="mt-1.5 t-caption c-secondary">
              {isPcMode
                ? 'PC 三个子资源位（S卡二级页面 / APP大促氛围 / APP腰封）各自维护独立文案，生成时按子资源位取用。'
                : '触达类目「议价弹窗」「大促专属弹窗」分别关联同名分组，其余类目关联「重点类目弹窗（默认）」。'}
            </p>
          </div>
        )}

        <div className="flex gap-4">
          {/* 左侧方案列表 */}
          <div className="flex w-48 shrink-0 flex-col gap-1">
            <div className="max-h-[360px] space-y-1 overflow-auto pr-1">
              {schemes.map((s) => {
                const active = s.id === activeId;
                const selectedItem = s.id === selectedId;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedId(s.id)}
                    className={cn(
                      'group flex w-full items-center gap-1.5 rounded-md border px-2.5 py-2 text-left t-label transition-all duration-150',
                      selectedItem
                        ? 'border-brand bg-brand-muted text-brand shadow-sm'
                        : 'border-border bg-card text-foreground hover:border-brand/40 hover:bg-accent/60',
                    )}
                  >
                    {active && (
                      <Check className="size-3.5 shrink-0 text-brand" />
                    )}
                    <span className="flex-1 truncate">{s.name || '未命名'}</span>
                    <span
                      role="button"
                      tabIndex={-1}
                      aria-label="删除方案"
                      onClick={(e) => handleDelete(s.id, e)}
                      className="flex size-5 shrink-0 items-center justify-center rounded-sm text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                    >
                      <Trash2 className="size-3.5" />
                    </span>
                  </button>
                );
              })}
            </div>
            <button
              type="button"
              onClick={handleAdd}
              className="flex items-center justify-center gap-1 rounded-md border border-dashed border-border px-2 py-2 t-label c-secondary transition-colors hover:border-brand/40 hover:text-brand"
            >
              <Plus className="size-3.5" />
              新增方案
            </button>
          </div>

          {/* 右侧编辑区 */}
          {selected && (
            <div className="min-w-0 flex-1 space-y-4">
              <div>
                <label className="mb-2 block t-label c-primary">方案名称</label>
                <div className="flex items-center gap-2">
                  <Input
                    value={selected.name}
                    onChange={(e) => patchSelected({ name: e.target.value })}
                    placeholder="如：大促首推方案"
                  />
                  {selected.id === activeId ? (
                    <span className="flex shrink-0 items-center gap-1 rounded-md bg-brand-muted px-2.5 py-1.5 t-caption text-brand">
                      <Check className="size-3.5" />
                      当前生效
                    </span>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="shrink-0"
                      onClick={() => setActiveId(selected.id)}
                    >
                      设为生效
                    </Button>
                  )}
                </div>
              </div>

              <div>
                <label className="mb-2 block t-label c-primary">
                  触达任务名称
                </label>
                <TokenChips tokens={isPcMode ? PC_NAME_TOKENS : NAME_TOKENS} />
                <Input
                  value={selected.nameTemplate}
                  onChange={(e) =>
                    patchSelected({ nameTemplate: e.target.value })
                  }
                  className="font-mono"
                  placeholder={
                    isPcMode
                      ? PC_DEFAULT_NAME_TEMPLATE
                      : '如 {dateCode}｜{categoryLabel}｜弹窗push'
                  }
                />
              </div>

              <div>
                <label className="mb-2 block t-label c-primary">
                  触达任务描述
                </label>
                <TokenChips tokens={TEMPLATE_TOKENS} />
                <Textarea
                  value={selected.descTemplate}
                  onChange={(e) =>
                    patchSelected({ descTemplate: e.target.value })
                  }
                  rows={10}
                  className="min-h-[220px] whitespace-pre-wrap font-mono leading-relaxed"
                  placeholder="输入默认描述模板，使用花括号变量占位"
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleSave}>保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DefaultConfigDialog;
