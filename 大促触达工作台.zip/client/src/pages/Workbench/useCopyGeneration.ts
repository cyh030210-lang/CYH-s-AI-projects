import { useState, useCallback, useRef } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { generateMarketingCopy, searchCategoryTrend } from '@client/src/api';
import { getAllCategories } from './categoryStorage';
import { sanitizeAndValidate } from './copyValidator';

export type CopyStatus =
  | 'pending'
  | 'searching'
  | 'streaming'
  | 'success'
  | 'error';

export interface CopyResult {
  id: string;
  categoryId: string;
  categoryLabel: string;
  mindsetIndex: number;
  mindsetLabel: string;
  status: CopyStatus;
  content: string;
  trend?: string;
  error?: string;
  warnings?: string[];
}

export interface GenerateParams {
  promotionPeriodLabel: string;
  categoryIds: string[];
  coreMindsets: string[];
  writingStyle?: string;
  enableSearch: boolean;
}

const categoryLabelOf = (id: string): string =>
  getAllCategories().find((c) => c.id === id)?.label ?? id;

const stripCodeFence = (text: string): string => {
  let out = text.replace(/^\s*```[^\n]*\n?/u, '');
  out = out.replace(/\n?```\s*$/u, '');
  return out.trim();
};

const resultId = (categoryId: string, mindsetIndex: number): string =>
  `${categoryId}#${mindsetIndex}`;

export const useCopyGeneration = () => {
  const [results, setResults] = useState<CopyResult[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const lastParamsRef = useRef<GenerateParams | null>(null);

  const updateResult = useCallback(
    (id: string, patch: Partial<CopyResult>) => {
      setResults((prev) =>
        prev.map((r) => (r.id === id ? { ...r, ...patch } : r)),
      );
    },
    [],
  );

  const searchTrend = useCallback(
    async (
      params: GenerateParams,
      categoryId: string,
      categoryLabel: string,
      itemIds: string[],
    ): Promise<string> => {
      if (!params.enableSearch) return '';
      itemIds.forEach((id) => updateResult(id, { status: 'searching' }));
      try {
        const year = new Date().getFullYear();
        const query = `${year}年 ${params.promotionPeriodLabel} ${categoryLabel} 消费趋势 热销 增长（仅检索${year}年当年的最新资讯，不要引用往年数据；请在总结最后单独用「参考来源：」开头，逐条列出信息来源的网页标题与完整网址）`;
        return await searchCategoryTrend(query, (accumulated) => {
          itemIds.forEach((id) =>
            updateResult(id, { status: 'searching', trend: accumulated }),
          );
        });
      } catch (searchError) {
        logger.warn(
          '类目消费趋势搜索失败，降级为直接生成',
          JSON.stringify({ categoryId, message: String(searchError) }),
        );
        itemIds.forEach((id) => updateResult(id, { trend: undefined }));
        return '';
      }
    },
    [updateResult],
  );

  const runOne = useCallback(
    async (
      params: GenerateParams,
      categoryId: string,
      categoryLabel: string,
      mindsetIndex: number,
      trend: string,
    ) => {
      const id = resultId(categoryId, mindsetIndex);
      const baseMindset = params.coreMindsets[mindsetIndex];
      const coreMindset = trend
        ? `${baseMindset}\n\n【该类目最新消费趋势参考】\n${trend}`
        : baseMindset;
      const callOnce = async (mindset: string): Promise<string> => {
        let latest = '';
        await generateMarketingCopy(
          {
            promotionPeriod: params.promotionPeriodLabel,
            category: categoryLabel,
            coreMindset: mindset,
            writingStyle: params.writingStyle || undefined,
          },
          (_delta, accumulated) => {
            latest = accumulated;
            updateResult(id, { status: 'streaming', content: accumulated });
          },
        );
        return stripCodeFence(latest);
      };

      try {
        const firstRaw = await callOnce(coreMindset);
        let best = sanitizeAndValidate(firstRaw);
        logger.info(
          '文案首版校验',
          JSON.stringify({ id, issues: best.issues }),
        );

        if (best.issues.length > 0) {
          const retryMindset =
            `${coreMindset}\n\n【上一版文案存在以下问题，请修正后重写】\n` +
            `${best.issues.map((s) => `- ${s}`).join('\n')}\n` +
            '请严格遵守：标题≤14字、正文≤50字（数字/标点/空格/字母均按1字计）；' +
            '曝光/流量/资源类必带「至高5倍」；成交/订单/转化类必带「至高两倍/至高2倍」且用涨/翻等结果动词；' +
            '报名/提报动作须穿插在利益点之间；禁止用+或＋堆砌利益点。';
          const retryRaw = await callOnce(retryMindset);
          const retryResult = sanitizeAndValidate(retryRaw);
          logger.info(
            '文案重试校验',
            JSON.stringify({ id, issues: retryResult.issues }),
          );
          if (retryResult.issues.length <= best.issues.length) {
            best = retryResult;
          }
        }

        updateResult(id, {
          status: 'success',
          content: best.fixed,
          warnings: best.issues.length > 0 ? best.issues : undefined,
        });
      } catch (error) {
        logger.error(
          '生成营销文案失败',
          JSON.stringify({ id, message: String(error) }),
        );
        updateResult(id, { status: 'error', error: '生成失败，请重试' });
      }
    },
    [updateResult],
  );

  const runCategory = useCallback(
    async (params: GenerateParams, categoryId: string) => {
      const categoryLabel = categoryLabelOf(categoryId);
      const itemIds = params.coreMindsets.map((_, i) =>
        resultId(categoryId, i),
      );
      const trend = await searchTrend(
        params,
        categoryId,
        categoryLabel,
        itemIds,
      );
      for (let i = 0; i < params.coreMindsets.length; i += 1) {
        await runOne(params, categoryId, categoryLabel, i, trend);
      }
    },
    [searchTrend, runOne],
  );

  const generate = useCallback(
    async (params: GenerateParams) => {
      lastParamsRef.current = params;
      setHasStarted(true);
      setIsGenerating(true);
      const initial: CopyResult[] = [];
      params.categoryIds.forEach((categoryId) => {
        const categoryLabel = categoryLabelOf(categoryId);
        params.coreMindsets.forEach((_, mindsetIndex) => {
          initial.push({
            id: resultId(categoryId, mindsetIndex),
            categoryId,
            categoryLabel,
            mindsetIndex,
            mindsetLabel: `心智${mindsetIndex + 1}`,
            status: 'pending',
            content: '',
          });
        });
      });
      setResults(initial);

      for (const id of params.categoryIds) {
        await runCategory(params, id);
      }
      setIsGenerating(false);
    },
    [runCategory],
  );

  const retryItem = useCallback(
    async (id: string) => {
      const params = lastParamsRef.current;
      if (!params) return;
      const target = results.find((r) => r.id === id);
      if (!target) return;
      const { categoryId, categoryLabel, mindsetIndex } = target;
      updateResult(id, {
        status: 'pending',
        content: '',
        trend: undefined,
        error: undefined,
        warnings: undefined,
      });
      setIsGenerating(true);
      const trend = await searchTrend(params, categoryId, categoryLabel, [id]);
      await runOne(params, categoryId, categoryLabel, mindsetIndex, trend);
      setIsGenerating(false);
    },
    [results, updateResult, searchTrend, runOne],
  );

  const reset = useCallback(() => {
    setResults([]);
    setHasStarted(false);
    setIsGenerating(false);
    lastParamsRef.current = null;
  }, []);

  return {
    results,
    isGenerating,
    hasStarted,
    generate,
    retryItem,
    reset,
  };
};
