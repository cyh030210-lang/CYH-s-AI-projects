import React, { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { CalendarDays, Sparkles, Trash2, Settings, Plus, X, ListPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import {
  CATEGORIES,
  PROMOTION_PERIODS,
  PromotionPeriod,
  CategoryOption,
  REACH_STAGES,
  ReachStage,
} from './constants';
import { getAllCategories } from './categoryStorage';
import CategoryMultiSelect from './CategoryMultiSelect';
import ReachTaskList from './ReachTaskList';
import {
  ReachTask,
  loadTasks,
  addTasks,
  removeTask,
  clearTasks,
} from './reachTaskStorage';
import DefaultConfigDialog from './DefaultConfigDialog';
import SlotManageDialog from './SlotManageDialog';
import {
  ResourceSlot,
  getAllSlots,
} from './slotStorage';
import {
  loadCustomPeriods,
  addCustomPeriod,
  removeCustomPeriod,
} from './periodStorage';
import {
  loadCustomStages,
  addCustomStage,
  removeCustomStage,
} from './stageStorage';
import {
  CopyScheme,
  BARGAIN_POPUP_LABEL,
  EXCLUSIVE_POPUP_LABEL,
  getActiveScheme,
  getCategoryScope,
  renderNameTemplate,
  renderPcNameTemplate,
  renderDescriptionTemplate,
} from './copySchemeStorage';

const DEFAULT_REACH_RATE = '90%';
const NON_APPLICABLE_REACH_RATE = '不涉及 无需填写';

const hasNonApplicableCategory = (labels: string[]): boolean =>
  labels.some(
    (label) =>
      label === BARGAIN_POPUP_LABEL || label === EXCLUSIVE_POPUP_LABEL,
  );

const formatDateCode = (date: Date): string =>
  `${date.getMonth() + 1}${String(date.getDate()).padStart(2, '0')}`;

const formatDateLabel = (date: Date): string =>
  `${date.getMonth() + 1}月${date.getDate()}日`;

const BUILTIN_PC_COMBO_KEY = 'pc_s_card_app_belt';

const PC_SUB_SLOTS: { key: string; label: string }[] = [
  { key: 's_card_l2', label: 'S卡二级页面' },
  { key: 'app_promo_atmos', label: 'APP大促氛围' },
  { key: 'app_belt', label: 'APP腰封' },
];

const FieldLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="mb-2 block t-label c-primary">
    {children}
  </span>
);

const ConfigPreparePanel: React.FC = () => {
  const [categoryIds, setCategoryIds] = useState<string[]>([]);
  const [resourceSlot, setResourceSlot] = useState<string>('popup');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('');
  const [merchantVolume, setMerchantVolume] = useState<string>('');
  const [pcVolumes, setPcVolumes] = useState<Record<string, string>>({});
  const [date, setDate] = useState<Date>(() => new Date());
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [selectedStage, setSelectedStage] = useState<string>(
    REACH_STAGES[0].id,
  );
  const [customStages, setCustomStages] = useState<ReachStage[]>(
    () => loadCustomStages(),
  );
  const [stageAddOpen, setStageAddOpen] = useState(false);
  const [stageNameDraft, setStageNameDraft] = useState('');
  const [customPeriods, setCustomPeriods] = useState<PromotionPeriod[]>(
    () => loadCustomPeriods(),
  );
  const [periodAddOpen, setPeriodAddOpen] = useState(false);
  const [periodNameDraft, setPeriodNameDraft] = useState('');
  const [reachRate, setReachRate] = useState(DEFAULT_REACH_RATE);
  const [reachRateTouched, setReachRateTouched] = useState(false);
  const [completeRate, setCompleteRate] = useState('2.27%');
  const [volumes, setVolumes] = useState<Record<string, string>>({});
  const [tasks, setTasks] = useState<ReachTask[]>(() => loadTasks());
  const [configOpen, setConfigOpen] = useState(false);
  const [slots, setSlots] = useState<ResourceSlot[]>(() => getAllSlots());
  const [slotManageOpen, setSlotManageOpen] = useState(false);

  const currentSlot = slots.find((s) => s.key === resourceSlot);
  const isPcMode = currentSlot?.mode === 'pc';
  const isBuiltinPcCombo = resourceSlot === BUILTIN_PC_COMBO_KEY;

  const resourceSlotLabel = currentSlot?.label ?? '';

  const handleSlotChanged = useCallback(() => {
    const next = getAllSlots();
    setSlots(next);
    setResourceSlot((prev) =>
      next.some((s) => s.key === prev) ? prev : next[0]?.key ?? 'popup',
    );
  }, []);

  const allPeriods: PromotionPeriod[] = [...PROMOTION_PERIODS, ...customPeriods];
  const customPeriodIds = new Set(customPeriods.map((p) => p.id));

  const allStages: ReachStage[] = [...REACH_STAGES, ...customStages];
  const customStageIds = new Set(customStages.map((s) => s.id));

  const handleDeleteStage = useCallback(
    (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      removeCustomStage(id);
      setCustomStages((prev) => prev.filter((s) => s.id !== id));
      setSelectedStage((prev) => (prev === id ? REACH_STAGES[0].id : prev));
    },
    [],
  );

  const handleConfirmAddStage = useCallback(() => {
    const label = stageNameDraft.trim();
    if (!label) {
      toast.error('请输入阶段名称');
      return;
    }
    if ([...REACH_STAGES, ...customStages].some((s) => s.label === label)) {
      toast.error('该阶段已存在');
      return;
    }
    const item = addCustomStage(label);
    setCustomStages((prev) => [...prev, item]);
    setSelectedStage(item.id);
    setStageNameDraft('');
    setStageAddOpen(false);
  }, [stageNameDraft, customStages]);

  const handleDeletePeriod = useCallback(
    (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      removeCustomPeriod(id);
      setCustomPeriods((prev) => prev.filter((p) => p.id !== id));
      setSelectedPeriod((prev) => (prev === id ? '' : prev));
    },
    [],
  );

  const handleConfirmAddPeriod = useCallback(() => {
    const label = periodNameDraft.trim();
    if (!label) {
      toast.error('请输入周期名称');
      return;
    }
    if ([...PROMOTION_PERIODS, ...customPeriods].some((p) => p.label === label)) {
      toast.error('该周期已存在');
      return;
    }
    const item = addCustomPeriod(label, '');
    setCustomPeriods((prev) => [...prev, item]);
    setSelectedPeriod(item.id);
    setPeriodNameDraft('');
    setPeriodAddOpen(false);
  }, [periodNameDraft, customPeriods]);

  const allCategories = getAllCategories();
  const selectedCategories = categoryIds
    .map((id) => allCategories.find((c) => c.id === id))
    .filter((c): c is CategoryOption => Boolean(c));

  const handleCategoryChange = useCallback(
    (nextIds: string[]) => {
      setCategoryIds(nextIds);
      if (reachRateTouched) {
        return;
      }
      const nextLabels = nextIds
        .map((id) => getAllCategories().find((c) => c.id === id)?.label)
        .filter((label): label is string => Boolean(label));
      setReachRate(
        hasNonApplicableCategory(nextLabels)
          ? NON_APPLICABLE_REACH_RATE
          : DEFAULT_REACH_RATE,
      );
    },
    [reachRateTouched],
  );

  const handleGenerate = useCallback(() => {
    if (isPcMode) {
      if (!selectedPeriod) {
        toast.error('请先选择促销周期');
        return;
      }
      const periodLabel =
        allPeriods.find((p) => p.id === selectedPeriod)?.label ?? '';
      const yy = String(new Date().getFullYear()).slice(-2);
      const stageIndex = allStages.findIndex((s) => s.id === selectedStage);
      const stageNum = String(stageIndex >= 0 ? stageIndex + 1 : 1);
      const now = Date.now();
      if (isBuiltinPcCombo) {
        const pcTasks: ReachTask[] = PC_SUB_SLOTS.map((sub) => {
          const scheme: CopyScheme = getActiveScheme(`pc_${sub.key}`, 'pc');
          return {
            id: `pc_${selectedPeriod}_${sub.key}_${selectedStage}`,
            name: renderPcNameTemplate(scheme.nameTemplate, {
              year: yy,
              periodLabel,
              slotLabel: sub.label,
              stage: stageNum,
            }),
            dateCode: '',
            categoryId: sub.key,
            categoryLabel: sub.label,
            description: renderDescriptionTemplate(scheme.descTemplate, {
              periodLabel,
              categoryLabel: sub.label,
              reachRate: '',
              completeRate,
              volume: pcVolumes[sub.key] ?? '',
            }),
            createdAt: now,
          };
        });
        const { added, skipped } = addTasks(pcTasks);
        setTasks(loadTasks());
        if (added.length > 0 && skipped > 0) {
          toast.success(`已生成 ${added.length} 条任务，跳过 ${skipped} 条重复`);
        } else if (added.length > 0) {
          toast.success(`已生成 ${added.length} 条触达任务`);
        } else {
          toast.info('该促销周期与阶段的任务已存在，未重复生成');
        }
        return;
      }
      // 自定义 PC 模式资源位：生成单条任务
      const scheme: CopyScheme = getActiveScheme(resourceSlot, 'pc');
      const slotLabel = currentSlot?.label ?? '资源位';
      const pcTask: ReachTask = {
        id: `pc_${selectedPeriod}_${resourceSlot}_${selectedStage}`,
        name: renderPcNameTemplate(scheme.nameTemplate, {
          year: yy,
          periodLabel,
          slotLabel,
          stage: stageNum,
        }),
        dateCode: '',
        categoryId: resourceSlot,
        categoryLabel: slotLabel,
        description: renderDescriptionTemplate(scheme.descTemplate, {
          periodLabel,
          categoryLabel: slotLabel,
          reachRate: '',
          completeRate,
          volume: merchantVolume,
        }),
        createdAt: now,
      };
      const { added, skipped } = addTasks([pcTask]);
      setTasks(loadTasks());
      if (added.length > 0) {
        toast.success('已生成 1 条触达任务');
      } else if (skipped > 0) {
        toast.info('该促销周期与阶段的任务已存在，未重复生成');
      }
      return;
    }
    if (categoryIds.length === 0) {
      toast.error('请先选择至少一个类目');
      return;
    }
    const dateCode = formatDateCode(date);
    const now = Date.now();
    const isBuiltinPopup = resourceSlot === 'popup';
    const newTasks: ReachTask[] = selectedCategories.map((c) => {
      const scheme: CopyScheme = isBuiltinPopup
        ? getActiveScheme(getCategoryScope(c.label))
        : getActiveScheme(resourceSlot, 'popup');
      return {
        id: `${dateCode}_${c.id}_${resourceSlot}`,
        name: renderNameTemplate(scheme.nameTemplate, {
          dateCode,
          categoryLabel: c.label,
        }),
        dateCode,
        categoryId: c.id,
        categoryLabel: c.label,
        description: renderDescriptionTemplate(scheme.descTemplate, {
          periodLabel: '',
          categoryLabel: c.label,
          reachRate,
          completeRate,
          volume: volumes[c.id] ?? '',
        }),
        createdAt: now,
      };
    });

    const { added, skipped } = addTasks(newTasks);
    setTasks(loadTasks());

    if (added.length > 0 && skipped > 0) {
      toast.success(`已生成 ${added.length} 条任务，跳过 ${skipped} 条重复`);
    } else if (added.length > 0) {
      toast.success(`已生成 ${added.length} 条触达任务`);
    } else {
      toast.info('所选类目任务已存在，未重复生成');
    }
  }, [
    isPcMode,
    isBuiltinPcCombo,
    resourceSlot,
    currentSlot,
    categoryIds,
    date,
    reachRate,
    completeRate,
    volumes,
    selectedCategories,
    selectedPeriod,
    selectedStage,
    allPeriods,
    allStages,
    merchantVolume,
    pcVolumes,
  ]);

  const handleRemove = useCallback((id: string) => {
    removeTask(id);
    setTasks(loadTasks());
  }, []);

  const handleClear = useCallback(() => {
    clearTasks();
    setTasks([]);
    toast.success('已清空全部触达任务');
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-6 overflow-auto lg:flex-row lg:gap-3">
      {/* 左侧配置区 */}
      <div className="flex flex-col gap-6 rounded-lg border border-border bg-card p-6 shadow-sm lg:w-[calc((100%-1.5rem)/3)] lg:shrink-0">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="t-heading c-primary">触达任务配置</h2>
            <p className="mt-1.5 t-label c-secondary">勾选类目并选择日期，一键生成弹窗、抖店首页S卡等多种触达任务</p>
          </div>
        </div>

        {/* 资源位 */}
        <div>
          <div className="mb-2 flex items-center justify-between gap-3">
            <span className="t-label c-primary">资源位</span>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0 gap-1.5"
                  onClick={() => setConfigOpen(true)}
                >
                  <Settings className="size-4" />
                  默认文案配置
                </Button>
              </TooltipTrigger>
              <TooltipContent>更改触达任务名称及触达任务描述文案</TooltipContent>
            </Tooltip>
          </div>
          <div className="flex items-center gap-2">
            <Select value={resourceSlot} onValueChange={setResourceSlot}>
              <SelectTrigger className="min-h-10 w-full">
                <SelectValue placeholder="请选择资源位" />
              </SelectTrigger>
              <SelectContent>
                {slots.map((slot) => (
                  <SelectItem key={slot.key} value={slot.key}>
                    {slot.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="size-10 shrink-0"
                  onClick={() => setSlotManageOpen(true)}
                >
                  <ListPlus className="size-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>新增或重命名资源位</TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* 类目 / 促销周期 */}
        <div>
          {isPcMode ? (
            <>
              <FieldLabel>促销周期</FieldLabel>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                {allPeriods.map((p) => {
                  const active = selectedPeriod === p.id;
                  const isCustom = customPeriodIds.has(p.id);
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setSelectedPeriod(p.id)}
                      className={cn(
                        'group relative rounded-lg border px-2 py-2.5 t-label transition-all duration-150',
                        active
                          ? 'border-brand bg-brand-muted text-brand shadow-sm'
                          : 'border-border bg-card text-foreground hover:border-brand/40 hover:bg-accent/60',
                      )}
                    >
                      {p.label}
                      {isCustom && (
                        <span
                          role="button"
                          tabIndex={-1}
                          aria-label="删除周期"
                          onClick={(e) => handleDeletePeriod(p.id, e)}
                          className="absolute -right-1.5 -top-1.5 flex size-4 items-center justify-center rounded-full border border-border bg-card text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                        >
                          <X className="size-2.5" />
                        </span>
                      )}
                    </button>
                  );
                })}
                <button
                  type="button"
                  onClick={() => setPeriodAddOpen(true)}
                  className="flex items-center justify-center gap-1 rounded-lg border border-dashed border-border px-2 py-2.5 t-label c-secondary transition-colors hover:border-brand/40 hover:text-brand"
                >
                  <Plus className="size-3.5" />
                  新增
                </button>
              </div>
            </>
          ) : (
            <>
              <FieldLabel>触达类目</FieldLabel>
              <CategoryMultiSelect value={categoryIds} onChange={handleCategoryChange} />
            </>
          )}
        </div>

        {/* 报名率 & 完成率 */}
        {isPcMode ? (
          <>
            {isBuiltinPcCombo ? (
              <div className="space-y-3">
                <div>
                  <FieldLabel>完成率</FieldLabel>
                  <Input
                    value={completeRate}
                    onChange={(e) => setCompleteRate(e.target.value)}
                    placeholder="如 2.27%"
                  />
                </div>
                <div>
                  <FieldLabel>各资源位商家量级</FieldLabel>
                  <div className="space-y-2">
                    {PC_SUB_SLOTS.map((sub) => (
                      <div key={sub.key}>
                        <span className="mb-1 block t-caption c-secondary">
                          {sub.label}
                        </span>
                        <Input
                          value={pcVolumes[sub.key] ?? ''}
                          onChange={(e) =>
                            setPcVolumes((prev) => ({
                              ...prev,
                              [sub.key]: e.target.value,
                            }))
                          }
                          placeholder="如 约 12 万"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <FieldLabel>完成率</FieldLabel>
                  <Input
                    value={completeRate}
                    onChange={(e) => setCompleteRate(e.target.value)}
                    placeholder="如 2.27%"
                  />
                </div>
                <div>
                  <FieldLabel>商家量级</FieldLabel>
                  <Input
                    value={merchantVolume}
                    onChange={(e) => setMerchantVolume(e.target.value)}
                    placeholder="如 约 12 万"
                  />
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <FieldLabel>报名率</FieldLabel>
              <Input
                value={reachRate}
                onChange={(e) => {
                  setReachRate(e.target.value);
                  setReachRateTouched(true);
                }}
                placeholder="如 90%"
              />
            </div>
            <div>
              <FieldLabel>完成率</FieldLabel>
              <Input
                value={completeRate}
                onChange={(e) => setCompleteRate(e.target.value)}
                placeholder="如 2.27%"
              />
            </div>
          </div>
        )}

        {/* 各类目量级 */}
        {!isPcMode && selectedCategories.length > 0 && (
          <div>
            <FieldLabel>各类目量级</FieldLabel>
            <div className="space-y-2">
              {selectedCategories.map((c) => (
                <div key={c.id} className="flex items-center gap-3">
                  <span className="w-20 shrink-0 t-body c-primary">
                    {c.label}
                  </span>
                  <Input
                    value={volumes[c.id] ?? ''}
                    onChange={(e) =>
                      setVolumes((prev) => ({ ...prev, [c.id]: e.target.value }))
                    }
                    placeholder="如 约 12 万"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 日期 / 触达阶段 */}
        {isPcMode ? (
          <div>
            <FieldLabel>触达阶段</FieldLabel>
            <div className="flex items-center gap-2">
              <Select value={selectedStage} onValueChange={setSelectedStage}>
                <SelectTrigger className="min-h-10 w-full">
                  <SelectValue placeholder="请选择触达阶段" />
                </SelectTrigger>
                <SelectContent>
                  {allStages.map((stage) => {
                    const isCustom = customStageIds.has(stage.id);
                    return (
                      <SelectItem
                        key={stage.id}
                        value={stage.id}
                        className={cn(isCustom && 'pr-8')}
                      >
                        <span className="flex items-center gap-1">
                          {stage.label}
                          {isCustom && (
                            <span
                              role="button"
                              tabIndex={-1}
                              aria-label="删除阶段"
                              onPointerDown={(e) => e.stopPropagation()}
                              onClick={(e) => handleDeleteStage(stage.id, e)}
                              className="absolute right-2 flex size-4 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-destructive"
                            >
                              <X className="size-3" />
                            </span>
                          )}
                        </span>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    className="size-10 shrink-0"
                    onClick={() => setStageAddOpen(true)}
                  >
                    <Plus className="size-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>新增自定义阶段</TooltipContent>
              </Tooltip>
            </div>
          </div>
        ) : (
          <div>
            <FieldLabel>触达日期</FieldLabel>
            <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                <button
                  type="button"
                  className={cn(
                    'flex min-h-10 w-full items-center justify-between gap-2 rounded-md border border-input bg-card px-3 py-2 text-left text-sm transition-colors',
                    'focus:outline-none focus-visible:ring-2 focus-visible:ring-ring/30',
                  )}
                >
                  <span className="text-foreground">
                    {formatDateLabel(date)}
                    <span
                      className="ml-2 t-caption c-secondary tabular-nums"
                      style={{ fontFamily: "'Times New Roman', Times, serif" }}
                    >
                      {formatDateCode(date)}
                    </span>
                  </span>
                  <CalendarDays className="size-4 shrink-0 text-muted-foreground" />
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(d) => {
                    if (d) {
                      setDate(d);
                      setCalendarOpen(false);
                    }
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        )}

        <Button
          onClick={handleGenerate}
          disabled={isPcMode ? !selectedPeriod : categoryIds.length === 0}
          className="mt-1 w-full gap-2"
        >
          <Sparkles className="size-4" />
          生成触达任务
        </Button>
      </div>

      <DefaultConfigDialog
        open={configOpen}
        onOpenChange={setConfigOpen}
        slot={resourceSlot}
        slotLabel={resourceSlotLabel}
        slotMode={currentSlot?.mode ?? 'popup'}
        onSaved={() => {}}
      />

      <SlotManageDialog
        open={slotManageOpen}
        onOpenChange={setSlotManageOpen}
        onChanged={handleSlotChanged}
      />

      <Dialog open={periodAddOpen} onOpenChange={setPeriodAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>新增促销周期</DialogTitle>
          </DialogHeader>
          <div className="py-1">
            <label className="mb-2 block t-label c-primary">周期名称</label>
            <Input
              autoFocus
              value={periodNameDraft}
              onChange={(e) => setPeriodNameDraft(e.target.value)}
              placeholder="例如：开学季"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPeriodAddOpen(false)}>
              取消
            </Button>
            <Button
              className="bg-brand text-brand-foreground hover:bg-brand/90"
              onClick={handleConfirmAddPeriod}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={stageAddOpen} onOpenChange={setStageAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>新增触达阶段</DialogTitle>
          </DialogHeader>
          <div className="py-1">
            <label className="mb-2 block t-label c-primary">阶段名称</label>
            <Input
              autoFocus
              value={stageNameDraft}
              onChange={(e) => setStageNameDraft(e.target.value)}
              placeholder="例如：二阶段爆发"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setStageAddOpen(false)}>
              取消
            </Button>
            <Button
              className="bg-brand text-brand-foreground hover:bg-brand/90"
              onClick={handleConfirmAddStage}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 右侧任务列表 */}
      <div className="flex min-w-0 flex-1 flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="t-heading c-primary">已生成触达任务</h2>
          {tasks.length > 0 && (
            <div className="flex items-center gap-3">
              <span className="t-label c-secondary tabular-nums">
                共 {tasks.length} 条
              </span>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground">
                    <Trash2 className="size-4" />
                    清空
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>清空全部触达任务？</AlertDialogTitle>
                    <AlertDialogDescription>
                      将删除当前已生成的 {tasks.length} 条任务，此操作不可撤销。
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>取消</AlertDialogCancel>
                    <AlertDialogAction onClick={handleClear}>确认清空</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>
        <ReachTaskList tasks={tasks} onRemove={handleRemove} />
      </div>
    </div>
  );
};

export default ConfigPreparePanel;
