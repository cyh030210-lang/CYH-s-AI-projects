import React from 'react';
import { Copy, Check, Loader2, TrendingUp, ChevronDown, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { CopyResult } from './useCopyGeneration';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

interface CopyCardProps {
  result: CopyResult;
  label?: string;
}

const URL_PATTERN = /(https?:\/\/[^\s，。、）)】]+)/g;

const isUrl = (part: string): boolean => /^https?:\/\//.test(part);

const renderWithLinks = (text: string): React.ReactNode[] =>
  text.split(URL_PATTERN).map((part, i) =>
    isUrl(part) ? (
      <UniversalLink
        key={i}
        to={part}
        target="_blank"
        rel="noopener noreferrer"
        className="text-brand underline underline-offset-2 hover:text-brand/80 break-all"
      >
        {part}
      </UniversalLink>
    ) : (
      <React.Fragment key={i}>{part}</React.Fragment>
    ),
  );

const CopyCard: React.FC<CopyCardProps> = ({ result, label }) => {
  const [copied, setCopied] = React.useState(false);
  const [trendOpen, setTrendOpen] = React.useState(false);
  const isStreaming = result.status === 'streaming';
  const hasTrend = !!result.trend && result.trend.trim().length > 0;
  const hasWarnings = !isStreaming && !!result.warnings?.length;

  const handleCopy = async () => {
    if (!result.content) return;
    try {
      await navigator.clipboard.writeText(result.content);
      setCopied(true);
      toast.success('已复制');
      window.setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      logger.error('复制失败', String(error));
      toast.error('复制失败，请手动选择文案复制');
    }
  };

  return (
    <div className="group rounded-lg border border-border bg-card p-6 shadow-sm transition-shadow hover:shadow-md">
      <div className="mb-3 flex items-center justify-between">
        <span className="rounded-md bg-muted px-2.5 py-0.5 t-caption font-medium c-primary">
          {label ?? result.categoryLabel}
        </span>
        <div className="flex items-center gap-1.5">
          {!isStreaming && result.content && (
            <span className="t-caption tabular-nums c-secondary">
              {result.content.length} 字
            </span>
          )}
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              'size-8 opacity-60 transition-opacity group-hover:opacity-100',
              copied && 'opacity-100',
            )}
            disabled={isStreaming || !result.content}
            onClick={handleCopy}
            aria-label="复制文案"
          >
            {copied ? (
              <Check className="size-4 text-success" />
            ) : (
              <Copy className="size-4" />
            )}
          </Button>
        </div>
      </div>
      <p className="whitespace-pre-wrap t-body-lg c-primary">
        {result.content}
        {isStreaming && (
          <Loader2 className="ml-1 inline size-4 animate-spin text-muted-foreground align-middle" />
        )}
      </p>
      {hasWarnings && (
        <div className="mt-3 rounded-md border border-[hsl(0_72%_51%)]/30 bg-[hsl(0_72%_51%)]/5 px-3 py-2.5">
          <div className="flex items-center gap-1.5 t-caption font-medium text-[hsl(0_72%_51%)]">
            <AlertTriangle className="size-3.5" />
            规范校验提示
          </div>
          <ul className="mt-1.5 space-y-1 pl-5 t-caption text-[hsl(0_72%_51%)]">
            {result.warnings?.map((w, i) => (
              <li key={i} className="list-disc">
                {w}
              </li>
            ))}
          </ul>
        </div>
      )}
      {hasTrend && (
        <div className="mt-4 border-t border-border pt-3">
          <button
            type="button"
            onClick={() => setTrendOpen((v) => !v)}
            className="flex items-center gap-1.5 t-caption font-medium c-secondary transition-colors hover:text-foreground"
          >
            <TrendingUp className="size-3.5" />
            消费趋势参考
            <ChevronDown
              className={cn(
                'size-3.5 transition-transform duration-150',
                trendOpen && 'rotate-180',
              )}
            />
          </button>
          {trendOpen && (
            <div className="mt-2 whitespace-pre-wrap rounded-md border border-border bg-muted/40 px-3 py-2.5 t-caption c-secondary">
              {renderWithLinks(result.trend ?? '')}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CopyCard;
