import { logger } from '@lark-apaas/client-toolkit/logger';

const STORAGE_KEY = 'workbench:custom-mindset';

type MindsetMap = Record<string, string | string[]>;

const readMap = (): MindsetMap => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as MindsetMap) : {};
  } catch (error) {
    logger.warn('读取关键心智本地缓存失败', String(error));
    return {};
  }
};

export const loadMindset = (periodId: string): string[] | undefined => {
  if (!periodId) return undefined;
  const value = readMap()[periodId];
  if (value === undefined) return undefined;
  return Array.isArray(value) ? value : [value];
};

export const saveMindset = (periodId: string, values: string[]): void => {
  if (!periodId) return;
  try {
    const map = readMap();
    map[periodId] = values;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch (error) {
    logger.warn('保存关键心智到本地缓存失败', String(error));
  }
};

export const removeMindset = (periodId: string): void => {
  if (!periodId) return;
  try {
    const map = readMap();
    delete map[periodId];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch (error) {
    logger.warn('清除关键心智本地缓存失败', String(error));
  }
};
