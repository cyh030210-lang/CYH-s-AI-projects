import React, { useState } from 'react';
import { Target, Settings2, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import Workbench from './Workbench';
import ConfigPreparePanel from './ConfigPreparePanel';
import TouchDashboard from '../TouchDashboard/TouchDashboard';

type TabKey = 'write' | 'prepare' | 'review';

const TABS: { key: TabKey; step: number; label: string }[] = [
  { key: 'prepare', step: 1, label: '触达配置准备' },
  { key: 'write', step: 2, label: '触达文案写作' },
  { key: 'review', step: 3, label: '触达数据复盘' },
];

const TAGE_CIRCLE_URL =
  'https://ecop.bytedance.net/tagPlatform/circle-list?cjSiteCode=St12403140000002&tenantId=t_dcfb5714fb5440b0bdf65f9f0a10b757&code=&cardBizCode=';
const DONGFENG_CONFIG_URL =
  'https://ecop.bytedance.net/workstation/arrival/single-task/list?cjSiteCode=St12403050000001';
const DONGFENG_MULTI_CONFIG_URL =
  'https://ecop.bytedance.net/workstation/arrival/multi-task/list?cjSiteCode=St12403050000001';
const SOP_DOC_URL =
  'https://bytedance.larkoffice.com/docx/UdEtdT9YmoIALnxyHKrcpuLonua';

const openExternal = (url: string): void => {
  window.open(url, '_blank', 'noopener,noreferrer');
};

const WorkbenchTabs: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabKey>('prepare');

  return (
    <div className="mx-auto flex min-h-dvh max-w-[1200px] flex-col px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
      {/* 顶部标题区 */}
      <header className="mb-8 shrink-0 rounded-lg border border-border bg-card p-6 shadow-sm">
        <h1 className="t-title c-primary">
          触达文案生产工具
        </h1>
        <p className="mt-1.5 max-w-xl t-body-lg c-secondary">
          选择促销周期、类目和写作风格，完成触达任务准备、文案生成与数据复盘
        </p>
        <div className="mt-4 flex items-center gap-3">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={() => openExternal(TAGE_CIRCLE_URL)}
              >
                <Target className="mr-1.5 size-4 text-brand" />
                塔阁圈选
              </Button>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs whitespace-pre-line leading-relaxed">
              {'1. 跳转到塔阁平台后，点击新建圈选包，按要求圈选出符合条件的商家包。\n2. 圈选完成后点击预估数量，然后将数据填写到下方“类目量级”'}
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={() => openExternal(DONGFENG_CONFIG_URL)}
              >
                <Settings2 className="mr-1.5 size-4 text-brand" />
                东风配置（单次）
              </Button>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs leading-relaxed">
              单次触达多用于重点类目弹窗、追发货弹窗、抖店PUSH、抖店站内信等
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={() => openExternal(DONGFENG_MULTI_CONFIG_URL)}
              >
                <Settings2 className="mr-1.5 size-4 text-brand" />
                东风配置（多次）
              </Button>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs leading-relaxed">
              东风多次触达多用于PC大促banner、App大促banner（可报名商家）、App大促腰封（不可报名商家）、PC二级页动态（公告/banner）、大促专属弹窗、议价弹窗等
            </TooltipContent>
          </Tooltip>
          <button
            type="button"
            onClick={() => openExternal(SOP_DOC_URL)}
            className="ml-auto inline-flex shrink-0 items-center gap-1.5 t-label text-brand hover:underline"
          >
            <HelpCircle className="size-4" />
            如有疑问，点击查看详细SOP
          </button>
        </div>
      </header>

      {/* Tab 切换条：卡片步骤式 */}
      <div role="tablist" className="mb-6 flex shrink-0 items-stretch gap-3">
        {TABS.map((tab) => {
          const active = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'flex flex-1 items-center gap-3 rounded-lg border px-4 py-3 text-left transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40',
                active
                  ? 'border-brand bg-brand text-primary-foreground shadow-sm'
                  : 'border-border bg-card text-foreground hover:border-brand-border',
              )}
            >
              <span
                className={cn(
                  'flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold',
                  active
                    ? 'bg-primary-foreground/20 text-primary-foreground'
                    : 'bg-brand-muted text-brand',
                )}
              >
                {tab.step}
              </span>
              <span className="t-label">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 面板区：常驻挂载，CSS 控制显隐以保留各 tab 状态 */}
      <div className={cn('flex min-h-0 flex-1', activeTab !== 'write' && 'hidden')}>
        <Workbench />
      </div>
      <div
        className={cn(
          'flex min-h-0 flex-1',
          activeTab !== 'prepare' && 'hidden',
        )}
      >
        <ConfigPreparePanel />
      </div>
      <div
        className={cn(
          'flex min-h-0 flex-1',
          activeTab !== 'review' && 'hidden',
        )}
      >
        <TouchDashboard />
      </div>
    </div>
  );
};

export default WorkbenchTabs;
