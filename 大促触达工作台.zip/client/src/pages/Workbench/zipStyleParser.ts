import JSZip from 'jszip';

const ALLOWED_EXT = ['.txt', '.md', '.markdown'];
const MAX_ZIP_SIZE = 5 * 1024 * 1024;
const MAX_MERGED = 50000;

export interface ZipParseResult {
  merged: string;
  fileCount: number;
  truncated: boolean;
}

export class ZipParseError extends Error {}

const stripFrontmatter = (text: string): string => {
  const normalized = text.replace(/^\uFEFF/u, '');
  if (!normalized.startsWith('---')) return text;
  const match = normalized.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/u);
  if (!match) return text;
  return normalized.slice(match[0].length).trimStart();
};

const isTextEntry = (path: string): boolean => {
  const lower = path.toLowerCase();
  if (lower.startsWith('__macosx/')) return false;
  const base = lower.split('/').pop() ?? '';
  if (base.startsWith('.')) return false;
  return ALLOWED_EXT.some((ext) => lower.endsWith(ext));
};

export const parseZipStyle = async (file: File): Promise<ZipParseResult> => {
  if (file.size > MAX_ZIP_SIZE) {
    throw new ZipParseError('压缩包过大，请上传 5MB 以内的 zip');
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(file);
  } catch {
    throw new ZipParseError('压缩包解析失败，请确认为有效 zip');
  }

  const entries = Object.values(zip.files)
    .filter((entry) => !entry.dir && isTextEntry(entry.name))
    .sort((a, b) => a.name.localeCompare(b.name));

  if (entries.length === 0) {
    throw new ZipParseError('压缩包内未找到 .txt / .md 文本文件');
  }

  const segments: string[] = [];
  let fileCount = 0;
  for (const entry of entries) {
    const raw = (await entry.async('string')).trim();
    const text = stripFrontmatter(raw).trim();
    if (!text) continue;
    fileCount += 1;
    segments.push(`### ${entry.name}\n${text}`);
  }

  if (fileCount === 0) {
    throw new ZipParseError('压缩包内的文本文件均为空');
  }

  let merged = segments.join('\n\n');
  let truncated = false;
  if (merged.length > MAX_MERGED) {
    merged = merged.slice(0, MAX_MERGED);
    truncated = true;
  }

  return { merged, fileCount, truncated };
};
