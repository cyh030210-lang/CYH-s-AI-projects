/**
 * 618 触达文案校验器（TS 复现 skill 内 validate_length.py 与 benefit_metric_rules.py 的判定与修复逻辑）。
 *
 * 计数规则：每个 Unicode code point 计 1 字（中文/字母/数字/标点/空格一致）。
 * 量化规则：曝光类表达必带「至高5倍」，成交类表达必带「至高两倍/至高2倍」且用涨/翻等结果动词。
 * 反堆砌规则：禁止 + / ＋ 机械堆砌利益点；禁止「成交至高两倍」等缺结果动词表达。
 */

const TITLE_LIMIT = 14;
const BODY_LIMIT = 50;

const EXPOSURE_TRIGGERS = [
  '曝光',
  '流量',
  '引流',
  '触达',
  '客流',
  '出圈',
  '资源倾斜',
  '扶持',
  '加持',
  '高意向买家',
  '高意向客流',
];

const TRANSACTION_TRIGGERS = [
  '成交',
  '订单',
  '转化',
  '销售',
  '营收',
  '动销',
  '业绩',
  '生意增长',
  '爆单',
  '起量',
];

const ACTION_TRIGGERS = [
  '报名',
  '提报',
  '参与',
  '入场',
  '挂接',
  '承接',
  '入盟',
  '卡位',
];

const STACKING_MARKERS = [
  '报名享',
  '提报享',
  '抢先提报享',
  '速速报名享',
  '火速报名享',
  '火速提报尖货，享',
  '叠加至高5倍曝光',
  '叠加至高5倍流量',
  '消费券加持，叠加',
  '消费券，叠加',
  '消费券+',
  '曝光+',
  '成交+',
  '＋',
  '+',
];

const FORBIDDEN_CONVERSION_PHRASES = [
  '成交至高两倍',
  '订单至高两倍',
  '转化至高两倍',
  '销售至高两倍',
  '营收至高两倍',
  '动销至高两倍',
  '业绩至高两倍',
];

const BENEFIT_WORDS = [
  // coupon
  '消费券',
  '平台出资消费券',
  '消费券重磅加码',
  '消费券平台出资',
  '国补',
  '国补加消费券双重补贴',
  '补贴加持',
  // exposure
  '至高5倍曝光',
  '至高5倍流量',
  '至高5倍流量倾斜',
  '至高5倍曝光扶持',
  '至高5倍资源倾斜',
  '放大至高5倍曝光机会',
  // transaction
  '成交至高涨两倍',
  '成交至高翻两倍',
  '成交至高翻2倍',
  '至高两倍成交',
  '至高2倍成交额',
  '助力成交至高涨两倍',
  '冲刺成交至高翻两倍',
  '推动至高两倍成交',
  '带动成交至高涨两倍',
  '拉升下单转化至高两倍',
  // distribution
  '精选联盟',
  '达人分销',
  '货找人',
  '达人分销放大至高5倍曝光',
];

const TRANSACTION_REPAIRS: [string, string][] = [
  ['成交至高两倍', '成交至高涨两倍'],
  ['成交至高2倍', '成交至高涨2倍'],
  ['助力成交至高两倍', '助力成交至高涨两倍'],
  ['推动成交至高两倍', '推动成交至高涨两倍'],
  ['带动成交至高两倍', '带动成交至高涨两倍'],
  ['轻松成交至高翻两倍', '助力成交至高翻两倍'],
  ['轻松成交至高翻2倍', '助力成交至高翻2倍'],
  ['享至高5倍引流', '承接至高5倍曝光触达'],
  ['享至高5倍曝光', '承接至高5倍曝光'],
];

const countChars = (text: string): number => Array.from(text).length;

const containsAny = (text: string, words: string[]): boolean =>
  words.some((w) => text.includes(w));

const hasExposureMetric = (text: string): boolean => text.includes('至高5倍');

const hasTransactionMetric = (text: string): boolean =>
  ['至高两倍', '至高2倍', '翻两倍', '翻2倍', '涨两倍', '涨2倍'].some((m) =>
    text.includes(m),
  );

const replaceFirst = (text: string, from: string, to: string): string => {
  const idx = text.indexOf(from);
  if (idx < 0) return text;
  return text.slice(0, idx) + to + text.slice(idx + from.length);
};

const repairTransactionExpression = (input: string): string => {
  let text = input;
  for (const [from, to] of TRANSACTION_REPAIRS) {
    text = text.split(from).join(to);
  }
  return text;
};

/**
 * 强制量化词绑定：曝光类补「至高5倍」，成交类补「至高两倍」并修复生硬表达。
 * 逐条对齐 benefit_metric_rules.enforce_metric_binding。
 */
const enforceMetricBinding = (input: string): string => {
  let copy = repairTransactionExpression(input);

  if (containsAny(copy, EXPOSURE_TRIGGERS) && !hasExposureMetric(copy)) {
    if (copy.includes('流量')) {
      copy = replaceFirst(copy, '流量', '至高5倍流量');
    } else if (copy.includes('资源倾斜')) {
      copy = replaceFirst(copy, '资源倾斜', '至高5倍资源倾斜');
    } else if (copy.includes('曝光')) {
      copy = replaceFirst(copy, '曝光', '至高5倍曝光');
    } else if (copy.includes('高意向客流')) {
      copy = replaceFirst(copy, '高意向客流', '至高5倍曝光带来的高意向客流');
    } else if (copy.includes('高意向买家')) {
      copy = replaceFirst(copy, '高意向买家', '至高5倍曝光触达的高意向买家');
    } else {
      copy = copy.replace(/[。！]+$/u, '') + '，借至高5倍曝光触达高意向买家！';
    }
  }

  if (containsAny(copy, TRANSACTION_TRIGGERS) && !hasTransactionMetric(copy)) {
    if (copy.includes('成交')) {
      copy = replaceFirst(copy, '成交', '成交至高涨两倍');
    } else if (copy.includes('订单')) {
      copy = replaceFirst(copy, '订单', '订单至高涨两倍');
    } else if (copy.includes('转化')) {
      copy = replaceFirst(copy, '转化', '转化至高两倍');
    } else {
      copy = copy.replace(/[。！]+$/u, '') + '，助力成交至高涨两倍！';
    }
  }

  return repairTransactionExpression(copy);
};

const detectStackedBenefits = (copy: string): string[] => {
  const hits = STACKING_MARKERS.filter((marker) => copy.includes(marker));
  const commaCount =
    (copy.match(/，/gu) ?? []).length + (copy.match(/、/gu) ?? []).length;
  const benefitMentions = BENEFIT_WORDS.filter((w) => copy.includes(w)).length;
  if (
    commaCount >= 3 &&
    benefitMentions >= 3 &&
    !containsAny(copy, ['降低', '撬动', '承接', '触达', '转成', '挂接'])
  ) {
    hits.push('多利益点逗号堆砌');
  }
  return Array.from(new Set(hits)).sort();
};

/** 复现 benefit_metric_rules.validate_copy 的语义规则校验。 */
const validateCopyRules = (copy: string): string[] => {
  const issues: string[] = [];

  if (!containsAny(copy, ACTION_TRIGGERS)) {
    issues.push('缺少报名/提报/承接等商家动作');
  }
  if (containsAny(copy, EXPOSURE_TRIGGERS) && !hasExposureMetric(copy)) {
    issues.push('曝光/流量/资源类表达缺少至高5倍');
  }
  if (containsAny(copy, TRANSACTION_TRIGGERS) && !hasTransactionMetric(copy)) {
    issues.push('成交/订单/转化/营收类表达缺少至高两倍或至高2倍');
  }
  if (copy.includes('成交至高两倍') || copy.includes('助力成交至高两倍')) {
    issues.push('成交表达缺少涨/翻等结果动词');
  }
  const stacked = detectStackedBenefits(copy);
  if (stacked.length > 0) {
    issues.push('存在利益点机械堆砌：' + stacked.join('、'));
  }
  if (copy.includes('轻松成交至高') || copy.includes('保证') || copy.includes('必爆')) {
    issues.push('存在过强承诺表达');
  }
  return issues;
};

const TITLE_RE = /^\s*(?:[-*]\s*)?(?:标题|app标题|app弹窗标题)\s*[:：]\s*(.+?)\s*$/iu;
const BODY_RE = /^\s*(?:[-*]\s*)?(?:正文|文案)\s*[:：]\s*(.+?)\s*$/u;

const hasForbiddenPlus = (text: string): boolean =>
  text.includes('+') || text.includes('＋');

const hasForbiddenConversionPhrase = (text: string): boolean =>
  FORBIDDEN_CONVERSION_PHRASES.some((p) => text.includes(p));

/**
 * 复现 validate_length.py：逐行提取「标题：/正文：」校验字数与禁用符号；
 * 未提取到分段时把整段作为正文按 50 字校验。
 */
const validateLength = (copy: string): string[] => {
  const issues: string[] = [];
  const lines = copy.split(/\r?\n/u);
  let matchedAny = false;

  const checkField = (field: '标题' | '正文', text: string, limit: number) => {
    matchedAny = true;
    const len = countChars(text);
    if (len > limit) issues.push(`${field}${len}/${limit}字`);
    if (hasForbiddenPlus(text)) issues.push(`${field}含+/＋堆砌符号`);
    if (hasForbiddenConversionPhrase(text)) {
      issues.push(`${field}成交表达缺结果动词（用涨/翻两倍）`);
    }
  };

  for (const line of lines) {
    const titleMatch = TITLE_RE.exec(line);
    if (titleMatch) {
      checkField('标题', titleMatch[1].trim(), TITLE_LIMIT);
      continue;
    }
    const bodyMatch = BODY_RE.exec(line);
    if (bodyMatch) {
      checkField('正文', bodyMatch[1].trim(), BODY_LIMIT);
    }
  }

  if (!matchedAny) {
    const text = copy.trim();
    const len = countChars(text);
    if (len > BODY_LIMIT) issues.push(`正文${len}/${BODY_LIMIT}字`);
    if (hasForbiddenPlus(text)) issues.push('正文含+/＋堆砌符号');
    if (hasForbiddenConversionPhrase(text)) {
      issues.push('正文成交表达缺结果动词（用涨/翻两倍）');
    }
  }

  return issues;
};

export interface SanitizeResult {
  fixed: string;
  issues: string[];
}

/**
 * 对生成文案做确定性修复（量化词绑定/生硬表达修复），并校验残余问题。
 * 字数超限、缺动作、堆砌等无法靠替换消除的问题会留在 issues 中，供重试与告警。
 */
export const sanitizeAndValidate = (copy: string): SanitizeResult => {
  const fixed = enforceMetricBinding(copy);
  const issues = [...validateCopyRules(fixed), ...validateLength(fixed)];
  return { fixed, issues };
};
