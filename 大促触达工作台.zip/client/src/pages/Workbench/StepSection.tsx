import React from 'react';
import { Label } from '@/components/ui/label';

interface StepSectionProps {
  index: number;
  title: string;
  desc?: string;
  required?: boolean;
  muted?: boolean;
  action?: React.ReactNode;
  children: React.ReactNode;
}

const StepSection: React.FC<StepSectionProps> = ({
  index,
  title,
  desc,
  required,
  muted,
  action,
  children,
}) => {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className={
              muted
                ? 'flex size-5 shrink-0 items-center justify-center rounded-full border border-border bg-transparent text-xs font-medium text-muted-foreground'
                : 'flex size-5 shrink-0 items-center justify-center rounded-full bg-brand-muted text-xs font-semibold text-brand'
            }
          >
            {index}
          </span>
          <Label className="t-body font-semibold c-primary">
            {title}
            {required && <span className="ml-0.5 text-destructive">*</span>}
          </Label>
        </div>
        {action}
      </div>
      {desc && (
        <p className="mb-2.5 pl-7 t-caption c-secondary">
          {desc}
        </p>
      )}
      <div className="pl-7">{children}</div>
    </div>
  );
};

export default StepSection;
