import { utils, writeFile, type CellObject } from 'xlsx';
import type { ReachTaskRow } from './types';

const HEADERS = [
  '任务ID/消息模版',
  '触达任务名称',
  '发送商家数',
  '点击商家数',
  '完成商家数',
  '触达率',
  '行动率',
  '触达率环比',
  '行动率环比',
];

const pct = (v: number | null | undefined): string =>
  `${((v ?? 0) * 100).toFixed(2)}%`;

const pp = (v: number | null | undefined): string => {
  if (v === null || v === undefined) return '-';
  const val = v * 100;
  const sign = val > 0 ? '+' : '';
  return `${sign}${val.toFixed(2)}pp`;
};

const sanitize = (name: string): string =>
  name.replace(/[/\\:*?"<>|]/gu, '_').trim() || '触达渠道';

export const exportChannelExcel = (
  channel: string,
  tasks: ReachTaskRow[],
): void => {
  const aoa: (string | number)[][] = [
    HEADERS,
    ...tasks.map((t) => [
      t.taskId,
      t.taskName,
      t.sendMerchants,
      t.clickMerchants,
      t.doneMerchants,
      pct(t.reachRate),
      pct(t.actionRate),
      pp(t.reachRatePp),
      pp(t.actionRatePp),
    ]),
  ];

  const ws = utils.aoa_to_sheet(aoa);

  // 强制任务ID列（第 0 列）为文本格式，避免长数字被科学计数法处理
  tasks.forEach((t, idx) => {
    const ref = utils.encode_cell({ r: idx + 1, c: 0 });
    const cell = ws[ref] as CellObject | undefined;
    if (cell) {
      cell.t = 's';
      cell.v = t.taskId;
      cell.z = '@';
    }
  });

  ws['!cols'] = [
    { wch: 22 },
    { wch: 32 },
    { wch: 12 },
    { wch: 12 },
    { wch: 12 },
    { wch: 10 },
    { wch: 10 },
    { wch: 12 },
    { wch: 12 },
  ];

  const wb = utils.book_new();
  utils.book_append_sheet(wb, ws, '任务明细');
  writeFile(wb, `商家触达效果复盘_${sanitize(channel)}.xlsx`);
};
