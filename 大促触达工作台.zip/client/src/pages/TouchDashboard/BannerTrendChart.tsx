import React, { useMemo } from 'react';
import { LineChart } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type { TopLevelFormatterParams } from 'echarts/types/dist/shared';
import type { StudyBannerPoint } from './studyAppBannerData';

interface BannerTrendChartProps {
  points: StudyBannerPoint[];
  title?: string;
}

const EXPOSURE_COLOR = '#1d74eb';
const CLICK_COLOR = '#3d8f66';
const CTR_COLOR = '#e8833a';

const BannerTrendChart: React.FC<BannerTrendChartProps> = ({
  points,
  title = '学习中心APP banner 数据趋势',
}) => {
  const option = useMemo<EChartsOption>(() => {
    const labels = points.map((p) => p.date);
    const exposureData = points.map((p) => p.exposure);
    const clickData = points.map((p) => p.clickUv);
    const ctrData = points.map((p) => Number((p.ctr * 100).toFixed(4)));
    const interval = Math.max(0, Math.floor(labels.length / 12));
    return {
      tooltip: {
        trigger: 'axis',
        formatter: (params: TopLevelFormatterParams) => {
          const list = Array.isArray(params) ? params : [params];
          const first = list[0] as { axisValueLabel?: string; name?: string };
          const title = first?.axisValueLabel ?? first?.name ?? '';
          const rows = list
            .map((p) => {
              const value = Number(p.value);
              const text =
                p.seriesName === 'CTR'
                  ? `${value.toFixed(4)}%`
                  : `${value}`;
              return `${p.marker as string}${p.seriesName}：${text}`;
            })
            .join('<br/>');
          return `${title}<br/>${rows}`;
        },
      },
      legend: {
        data: ['曝光', '点击UV', 'CTR'],
        top: 0,
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '12%',
        top: 40,
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: labels,
        axisLabel: { interval },
      },
      yAxis: [
        {
          type: 'value',
          name: '次数',
          min: 0,
        },
        {
          type: 'value',
          name: 'CTR',
          min: 0,
          axisLabel: {
            formatter: (value: number) => `${value}%`,
          },
          splitLine: { show: false },
        },
      ],
      series: [
        {
          name: '曝光',
          type: 'line',
          yAxisIndex: 0,
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          itemStyle: { color: EXPOSURE_COLOR },
          lineStyle: { color: EXPOSURE_COLOR, width: 2 },
          data: exposureData,
        },
        {
          name: '点击UV',
          type: 'line',
          yAxisIndex: 0,
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          itemStyle: { color: CLICK_COLOR },
          lineStyle: { color: CLICK_COLOR, width: 2 },
          data: clickData,
        },
        {
          name: 'CTR',
          type: 'line',
          yAxisIndex: 1,
          smooth: true,
          symbol: 'circle',
          symbolSize: 5,
          itemStyle: { color: CTR_COLOR },
          lineStyle: { color: CTR_COLOR, width: 2 },
          data: ctrData,
        },
      ],
    };
  }, [points]);

  return (
    <div className="min-w-0 rounded-lg border border-border bg-card p-4">
      <div className="flex items-center gap-1.5 t-heading c-primary">
        <LineChart className="size-4 text-brand" />
        {title}
      </div>
      <p className="mt-1 t-label c-secondary">
        展示曝光、点击 UV 与 CTR 的每日走势，曝光与点击走左轴计数，CTR 走右轴百分比。
      </p>
      <ReactECharts
        option={option}
        theme="ud"
        className="mt-3 h-[300px] w-full"
        notMerge
      />
    </div>
  );
};

export default BannerTrendChart;
