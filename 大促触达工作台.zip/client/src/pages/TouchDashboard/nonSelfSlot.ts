export const PC_DYNAMIC_CHANNEL = 'PC二级页面动态';

export type NonSelfSlot = 'study_app' | 'study_pc';

export interface NonSelfSlotOption {
  value: NonSelfSlot;
  label: string;
}

export const NON_SELF_SLOT_OPTIONS: NonSelfSlotOption[] = [
  { value: 'study_app', label: '学习中心APP banner' },
  { value: 'study_pc', label: '学习中心PC banner' },
];
