import React, { useMemo } from 'react';
import { LineChart } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type { TopLevelFormatterParams } from 'echarts/types/dist/shared';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { ReachTaskRow } from './types';

interface SelectedTrendDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tasks: ReachTaskRow[];
}

const REACH_COLOR = '#1d74eb';
const ACTION_COLOR = '#3d8f66';

const buildOption = (
  labels: string[],
  seriesName: string,
  color: string,
  data: number[],
): EChartsOption => ({
  tooltip: {
    trigger: 'axis',
    formatter: (params: TopLevelFormatterParams) => {
      const list = Array.isArray(params) ? params : [params];
      const first = list[0] as { axisValueLabel?: string; name?: string };
      const title = first?.axisValueLabel ?? first?.name ?? '';
      const rows = list
        .map(
          (p) =>
            `${p.marker as string}${p.seriesName}：${Number(p.value).toFixed(
              2,
            )}%`,
        )
        .join('<br/>');
      return `${title}<br/>${rows}`;
    },
  },
  legend: { data: [seriesName], top: 0 },
  grid: { left: '3%', right: '4%', bottom: 56, top: 40, containLabel: true },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: labels,
    axisLabel: {
      interval: 0,
      lineHeight: 14,
      formatter: (value: string) => {
        const max = 6;
        if (value.length <= max) return value;
        const first = value.slice(0, max);
        const rest = value.slice(max);
        if (rest.length <= max) return `${first}\n${rest}`;
        return `${first}\n${rest.slice(0, max - 1)}…`;
      },
    },
  },
  yAxis: {
    type: 'value',
    min: 0,
    axisLabel: { formatter: (value: number) => `${value}%` },
  },
  series: [
    {
      name: seriesName,
      type: 'line',
      smooth: true,
      symbol: 'circle',
      symbolSize: 7,
      itemStyle: { color },
      lineStyle: { color, width: 2 },
      data,
    },
  ],
});

const SelectedTrendDialog: React.FC<SelectedTrendDialogProps> = ({
  open,
  onOpenChange,
  tasks,
}) => {
  const labels = useMemo(() => tasks.map((t) => t.taskName), [tasks]);

  const reachOption = useMemo<EChartsOption>(
    () =>
      buildOption(
        labels,
        '触达率',
        REACH_COLOR,
        tasks.map((t) => Number((t.reachRate * 100).toFixed(2))),
      ),
    [labels, tasks],
  );

  const actionOption = useMemo<EChartsOption>(
    () =>
      buildOption(
        labels,
        '行动率',
        ACTION_COLOR,
        tasks.map((t) => Number((t.actionRate * 100).toFixed(2))),
      ),
    [labels, tasks],
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>选中任务触达对比</DialogTitle>
          <DialogDescription>
            共 {tasks.length} 个任务，分别展示各任务的触达率与行动率
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-xl border border-border bg-muted/40 p-4">
            <div className="flex items-center gap-1.5 t-heading c-primary">
              <LineChart className="size-4 text-brand" />
              触达率对比
            </div>
            <ReactECharts
              option={reachOption}
              theme="ud"
              className="mt-3 h-[320px] w-full"
              notMerge
            />
          </div>

          <div className="rounded-xl border border-border bg-muted/40 p-4">
            <div className="flex items-center gap-1.5 t-heading c-primary">
              <LineChart className="size-4 text-brand" />
              行动率对比
            </div>
            <ReactECharts
              option={actionOption}
              theme="ud"
              className="mt-3 h-[320px] w-full"
              notMerge
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SelectedTrendDialog;
