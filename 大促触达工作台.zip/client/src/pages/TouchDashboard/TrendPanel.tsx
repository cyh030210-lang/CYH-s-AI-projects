import React from 'react';
import { HelpCircle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { ChannelSummary, ReachTaskRow } from './types';
import type { TouchDetailDayRow } from '@shared/api.interface';
import { formatPct } from './format';
import TrendChart from './TrendChart';
import DetailDayChart from './DetailDayChart';
import type { StagePoint } from './stageTrend';

interface TrendPanelProps {
  channel: string;
  summary: ChannelSummary | undefined;
  tasks: ReachTaskRow[];
  detailDays?: TouchDetailDayRow[];
  detailReachRate?: number;
  detailCompletionRate?: number;
  stagePoints?: StagePoint[];
}

interface MiniMetricProps {
  label: string;
  value: string;
  tone?: 'default' | 'success' | 'destructive';
  tip?: string;
}

const MiniMetric: React.FC<MiniMetricProps> = ({
  label,
  value,
  tone = 'default',
  tip,
}) => (
  <div className="min-w-0">
    <div className="flex items-center justify-end gap-1">
      <p className="truncate t-caption c-secondary">{label}</p>
      {tip && (
        <Tooltip>
          <TooltipTrigger asChild>
            <HelpCircle className="size-3.5 shrink-0 cursor-help text-muted-foreground transition-colors hover:text-brand" />
          </TooltipTrigger>
          <TooltipContent className="max-w-xs whitespace-pre-line leading-relaxed">
            {tip}
          </TooltipContent>
        </Tooltip>
      )}
    </div>
    <p
      className={cn(
        'mt-0.5 truncate text-sm font-semibold tabular-nums',
        tone === 'success' && 'text-[hsl(150_40%_40%)]',
        tone === 'destructive' && 'text-destructive',
        tone === 'default' && 'c-primary',
      )}
    >
      {value}
    </p>
  </div>
);

const TrendPanel: React.FC<TrendPanelProps> = ({
  channel,
  summary,
  tasks,
  detailDays,
  detailReachRate,
  detailCompletionRate,
  stagePoints,
}) => {
  const isDayMode = Boolean(detailDays);
  const isStageMode = !isDayMode && Boolean(stagePoints && stagePoints.length > 0);

  const stageTotals = (stagePoints ?? []).reduce(
    (acc, p) => ({
      send: acc.send + p.sendMerchants,
      click: acc.click + p.clickMerchants,
      done: acc.done + p.doneMerchants,
    }),
    { send: 0, click: 0, done: 0 },
  );

  const reachRate = isDayMode
    ? detailReachRate ?? 0
    : isStageMode
      ? stageTotals.send > 0
        ? stageTotals.click / stageTotals.send
        : 0
      : summary?.reachRate ?? 0;
  const actionRate = isDayMode
    ? detailCompletionRate ?? 0
    : isStageMode
      ? stageTotals.send > 0
        ? stageTotals.done / stageTotals.send
        : 0
      : summary?.actionRate ?? 0;

  const titleSuffix = isDayMode
    ? '按天触达趋势'
    : isStageMode
      ? '按阶段触达趋势'
      : '触达趋势图';

  return (
    <div className="min-w-0 rounded-lg border border-border bg-card p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h3 className="truncate text-sm font-semibold c-primary">
            {channel}{titleSuffix}
          </h3>
        </div>

        <div className="grid shrink-0 grid-cols-2 gap-3 text-right">
          <MiniMetric
            label="触达率"
            value={formatPct(reachRate)}
            tip="当前渠道加总点击商家数/当前渠道加总发送商家数"
          />
          <MiniMetric
            label="完成率"
            value={formatPct(actionRate)}
            tip="当前渠道加总完成商家数/当前渠道加总发送商家数"
          />
        </div>
      </div>

      <div className="mt-4 w-full overflow-hidden">
        {isDayMode ? (
          <DetailDayChart days={detailDays ?? []} />
        ) : (
          <TrendChart tasks={tasks} stagePoints={stagePoints} />
        )}
      </div>
    </div>
  );
};

export default TrendPanel;
