import type { TouchDetailDayRow } from '@shared/api.interface';

export const STAGE_CHANNELS: string[] = ['抖店S卡', 'PC二级页面动态'];

export interface StageRange {
  label: string;
  start: string;
  end: string;
}

export const STAGE_RANGES: StageRange[] = [
  { label: '4.16-5.07', start: '2026-04-16', end: '2026-05-07' },
  { label: '5.08-5.20', start: '2026-05-08', end: '2026-05-20' },
  { label: '5.21-6.03', start: '2026-05-21', end: '2026-06-03' },
  { label: '6.04-6.10', start: '2026-06-04', end: '2026-06-10' },
  { label: '6.11-6.18', start: '2026-06-11', end: '2026-06-18' },
];

export const STAGE_FULL_START = STAGE_RANGES[0].start;
export const STAGE_FULL_END = STAGE_RANGES[STAGE_RANGES.length - 1].end;

export interface StagePoint {
  label: string;
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  actionRate: number;
}

const toDay = (value: string): string => value.slice(0, 10);

export const aggregateStages = (days: TouchDetailDayRow[]): StagePoint[] => {
  const buckets = STAGE_RANGES.map((r) => ({
    label: r.label,
    start: r.start,
    end: r.end,
    send: 0,
    click: 0,
    done: 0,
  }));

  for (const day of days) {
    const d = toDay(day.sendDate);
    const bucket = buckets.find((b) => d >= b.start && d <= b.end);
    if (!bucket) continue;
    bucket.send += day.sendMerchants ?? 0;
    bucket.click += day.clickMerchants ?? 0;
    bucket.done += day.doneMerchants ?? 0;
  }

  return buckets.map((b) => ({
    label: b.label,
    sendMerchants: b.send,
    clickMerchants: b.click,
    doneMerchants: b.done,
    reachRate: b.send > 0 ? b.click / b.send : 0,
    actionRate: b.send > 0 ? b.done / b.send : 0,
  }));
};
