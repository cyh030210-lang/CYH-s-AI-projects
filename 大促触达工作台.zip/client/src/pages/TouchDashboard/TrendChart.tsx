import React, { useMemo } from 'react';
import { LineChart } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type { TopLevelFormatterParams } from 'echarts/types/dist/shared';
import type { ReachTaskRow } from './types';
import type { StagePoint } from './stageTrend';
import { aggregateTaskPoints } from './trendPoints';

interface TrendChartProps {
  tasks: ReachTaskRow[];
  stagePoints?: StagePoint[];
}

interface PeriodPoint {
  label: string;
  reachRate: number;
  actionRate: number;
}

const REACH_COLOR = '#1d74eb';
const ACTION_COLOR = '#3d8f66';

const TrendChart: React.FC<TrendChartProps> = ({ tasks, stagePoints }) => {
  const periods = useMemo<PeriodPoint[]>(() => {
    if (stagePoints && stagePoints.length > 0) {
      return stagePoints.map((p) => ({
        label: p.label,
        reachRate: p.reachRate,
        actionRate: p.actionRate,
      }));
    }
    return aggregateTaskPoints(tasks).map((p) => ({
      label: p.label,
      reachRate: p.reachRate,
      actionRate: p.secondaryRate,
    }));
  }, [tasks, stagePoints]);

  const option = useMemo<EChartsOption>(() => {
    const labels = periods.map((p) => p.label);
    const reachData = periods.map((p) => Number((p.reachRate * 100).toFixed(2)));
    const actionData = periods.map((p) =>
      Number((p.actionRate * 100).toFixed(2)),
    );
    return {
      tooltip: {
        trigger: 'axis',
        formatter: (params: TopLevelFormatterParams) => {
          const list = Array.isArray(params) ? params : [params];
          const first = list[0] as { axisValueLabel?: string; name?: string };
          const title = first?.axisValueLabel ?? first?.name ?? '';
          const rows = list
            .map(
              (p) =>
                `${p.marker as string}${p.seriesName}：${Number(
                  p.value,
                ).toFixed(2)}%`,
            )
            .join('<br/>');
          return `${title}<br/>${rows}`;
        },
      },
      legend: {
        data: ['触达率', '完成率'],
        top: 0,
      },
      grid: { left: '3%', right: '4%', bottom: '20%', top: 40, containLabel: true },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: labels,
      },
      yAxis: {
        type: 'value',
        min: 0,
        axisLabel: {
          formatter: (value: number) => `${value}%`,
        },
      },
      series: [
        {
          name: '触达率',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: REACH_COLOR },
          lineStyle: { color: REACH_COLOR, width: 2 },
          data: reachData,
        },
        {
          name: '完成率',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: ACTION_COLOR },
          lineStyle: { color: ACTION_COLOR, width: 2 },
          data: actionData,
        },
      ],
    };
  }, [periods]);

  if (periods.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-muted/40 p-4">
        <div className="flex items-center gap-1.5 t-heading c-primary">
          <LineChart className="size-4 text-brand" />
          触达趋势
        </div>
        <div className="mt-6 flex flex-col items-center justify-center gap-3 py-6 text-center">
          <div className="flex size-11 items-center justify-center rounded-full bg-muted">
            <LineChart
              className="size-5 text-muted-foreground"
              strokeWidth={1.5}
            />
          </div>
          <div className="t-label c-secondary">当前渠道暂无趋势数据</div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-muted/40 p-4">
      <div className="flex items-center gap-1.5 t-heading c-primary">
        <LineChart className="size-4 text-brand" />
        触达趋势
      </div>
      <p className="mt-1 t-label c-secondary">
        按触达任务期展示触达率与完成率走势，比率以当期发送商家数加总为基准。
      </p>
      <ReactECharts
        option={option}
        theme="ud"
        className="mt-3 h-[300px] w-full"
        notMerge
      />
    </div>
  );
};

export default TrendChart;
