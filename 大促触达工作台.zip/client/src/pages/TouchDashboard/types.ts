import type { ChannelSummary, ReachTaskRow } from '@shared/api.interface';

export type FetchStatus = 'idle' | 'loading' | 'success' | 'error';

export interface OverallMetrics {
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  actionRate: number;
}

export interface KpiItem {
  key: string;
  label: string;
  value: string;
}

export type { ChannelSummary, ReachTaskRow };
