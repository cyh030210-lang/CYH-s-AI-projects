import React from 'react';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  POPUP_CHANNEL,
  POPUP_SUBTYPE_OPTIONS,
  type PopupSubtype,
} from './popupSubtype';
import {
  PC_DYNAMIC_CHANNEL,
  NON_SELF_SLOT_OPTIONS,
  type NonSelfSlot,
} from './nonSelfSlot';

interface ChannelSwitcherProps {
  currentChannel: string;
  channels: string[];
  onSelect: (channel: string) => void;
  popupSubtype?: PopupSubtype;
  onPopupSubtypeChange?: (subtype: PopupSubtype) => void;
  nonSelfSlot?: NonSelfSlot;
  onNonSelfSlotChange?: (slot: NonSelfSlot) => void;
  slotActive?: boolean;
}

const ChannelSwitcher: React.FC<ChannelSwitcherProps> = ({
  currentChannel,
  channels,
  onSelect,
  popupSubtype = 'all',
  onPopupSubtypeChange,
  nonSelfSlot,
  onNonSelfSlotChange,
  slotActive = false,
}) => {
  return (
    <div className="flex flex-nowrap items-center gap-2 overflow-x-auto lg:justify-end">
      {channels.map((channel) => {
        const active = channel === currentChannel && !slotActive;
        const showPopupSelect =
          channel === POPUP_CHANNEL && active && onPopupSubtypeChange;
        const showNonSelfSlotSelect =
          channel === PC_DYNAMIC_CHANNEL && onNonSelfSlotChange;
        return (
          <React.Fragment key={channel}>
            <button
              type="button"
              onClick={() => onSelect(channel)}
              className={cn(
                'shrink-0 whitespace-nowrap rounded-lg px-3 py-2 t-label transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40',
                active
                  ? 'bg-brand text-brand-foreground shadow-sm'
                  : 'border border-border bg-card text-foreground hover:border-brand/40 hover:bg-accent/60',
              )}
            >
              {channel}
            </button>
            {showPopupSelect && (
              <Select
                value={popupSubtype}
                onValueChange={(v) =>
                  onPopupSubtypeChange(v as PopupSubtype)
                }
              >
                <SelectTrigger className="h-9 w-[132px] shrink-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {POPUP_SUBTYPE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            {showNonSelfSlotSelect && (
              <Select
                value={nonSelfSlot}
                onValueChange={(v) => onNonSelfSlotChange(v as NonSelfSlot)}
              >
                <SelectTrigger
                  className={cn(
                    'h-9 w-[168px] shrink-0',
                    slotActive &&
                      'border-brand bg-brand-muted text-brand',
                  )}
                >
                  <SelectValue placeholder="非自配资源位" />
                </SelectTrigger>
                <SelectContent>
                  {NON_SELF_SLOT_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default ChannelSwitcher;
