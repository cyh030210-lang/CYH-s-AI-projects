import { useState, useCallback, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { fetchTouchDetailOptions, queryTouchDetail } from '@client/src/api';
import type {
  TouchDetailOptionsResponse,
  TouchDetailQueryResponse,
} from '@shared/api.interface';

export type DetailStatus = 'idle' | 'loading' | 'success' | 'error';

export interface UseTouchDetailReturn {
  options?: TouchDetailOptionsResponse;
  optionsError?: string;
  status: DetailStatus;
  result?: TouchDetailQueryResponse;
  errorMsg?: string;
  query: (
    channel: string,
    startDate: string,
    endDate: string,
    taskIds?: string[],
  ) => Promise<void>;
}

export const useTouchDetail = (): UseTouchDetailReturn => {
  const [options, setOptions] = useState<TouchDetailOptionsResponse>();
  const [optionsError, setOptionsError] = useState<string>();
  const [status, setStatus] = useState<DetailStatus>('idle');
  const [result, setResult] = useState<TouchDetailQueryResponse>();
  const [errorMsg, setErrorMsg] = useState<string>();

  useEffect(() => {
    let alive = true;
    fetchTouchDetailOptions()
      .then((data) => {
        if (alive) setOptions(data);
      })
      .catch((err) => {
        logger.warn('触达明细筛选项拉取失败', String(err));
        if (alive) setOptionsError('筛选项加载失败，请稍后重试。');
      });
    return () => {
      alive = false;
    };
  }, []);

  const query = useCallback(
    async (
      channel: string,
      startDate: string,
      endDate: string,
      taskIds?: string[],
    ) => {
      setStatus('loading');
      setErrorMsg(undefined);
      try {
        const data = await queryTouchDetail(channel, startDate, endDate, taskIds);
        setResult(data);
        setStatus('success');
      } catch (err) {
        logger.warn('触达明细查询失败', String(err));
        setErrorMsg('明细查询失败，请稍后重试。');
        setStatus('error');
      }
    },
    [],
  );

  return { options, optionsError, status, result, errorMsg, query };
};
