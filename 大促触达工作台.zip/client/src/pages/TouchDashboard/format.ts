export const formatCount = (v: number | null | undefined): string =>
  new Intl.NumberFormat('zh-CN').format(v ?? 0);

export const formatWan = (v: number | null | undefined): string =>
  `${new Intl.NumberFormat('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format((v ?? 0) / 10000)}万`;

export const formatPct = (v: number | null | undefined): string =>
  `${((v ?? 0) * 100).toFixed(2)}%`;

export interface PpDisplay {
  text: string;
  tone: 'up' | 'down' | 'flat' | 'none';
}

export const formatPp = (v: number | null | undefined): PpDisplay => {
  if (v === null || v === undefined) {
    return { text: '—', tone: 'none' };
  }
  const pp = v * 100;
  if (pp === 0) return { text: '0.00pp', tone: 'flat' };
  const sign = pp > 0 ? '+' : '';
  return {
    text: `${sign}${pp.toFixed(2)}pp`,
    tone: pp > 0 ? 'up' : 'down',
  };
};
