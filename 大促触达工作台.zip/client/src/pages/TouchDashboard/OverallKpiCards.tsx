import React from 'react';
import { HelpCircle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { formatCount, formatPct, formatWan } from './format';

export interface KpiMetrics {
  sendMerchants: number;
  clickMerchants: number;
  doneMerchants: number;
  reachRate: number;
  completionRate: number;
}

export interface BannerKpiMetrics {
  avgExposure: number;
  avgClickUv: number;
  avgReachRate: number;
}

interface OverallKpiCardsProps {
  metrics: KpiMetrics;
  bannerMetrics?: BannerKpiMetrics;
}

const OverallKpiCards: React.FC<OverallKpiCardsProps> = ({
  metrics,
  bannerMetrics,
}) => {
  const cards: { key: string; label: string; value: string; tip?: string }[] =
    bannerMetrics
      ? [
          {
            key: 'avgExposure',
            label: '平均曝光',
            value: formatCount(bannerMetrics.avgExposure),
            tip: '统计区间内每日曝光量的平均值',
          },
          {
            key: 'avgClickUv',
            label: '平均点击UV',
            value: formatCount(bannerMetrics.avgClickUv),
            tip: '统计区间内每日点击 UV 的平均值',
          },
          {
            key: 'avgReachRate',
            label: '平均触达率',
            value: formatPct(bannerMetrics.avgReachRate),
            tip: '统计区间内每日 CTR 的平均值',
          },
        ]
      : [
    {
      key: 'send',
      label: '发送商家数',
      value: formatWan(metrics.sendMerchants),
      tip: '指统计日期内成功发送消息次数大于0的去重店铺数量',
    },
    {
      key: 'click',
      label: '点击商家数',
      value: formatWan(metrics.clickMerchants),
      tip: '统计满足以下条件的去重店铺数：短信渠道曝光数大于0，或非短信渠道点击数大于0',
    },
    {
      key: 'done',
      label: '完成商家数',
      value: formatWan(metrics.doneMerchants),
      tip: '指统计完成触达任务次数大于0的去重店铺数量，完成数单位为次数',
    },
    {
      key: 'reach',
      label: '总触达率',
      value: formatPct(metrics.reachRate),
      tip: '加总点击商家数/加总发送商家数',
    },
    {
      key: 'action',
      label: '总完成率',
      value: formatPct(metrics.completionRate),
      tip: '加总完成商家数/加总发送商家数',
    },
  ];

  return (
    <div
      className={
        bannerMetrics
          ? 'grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-3'
          : 'grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-5'
      }
    >
      {cards.map((c) => (
        <div
          key={c.key}
          className="rounded-lg border border-border bg-card p-5 shadow-sm"
        >
          <div className="flex items-center gap-1 t-label c-secondary text-sm">
            {c.label}
            {c.tip && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="size-3.5 shrink-0 cursor-help text-muted-foreground transition-colors hover:text-brand" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs whitespace-pre-line leading-relaxed">
                  {c.tip}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          <div className="mt-2 t-metric c-primary text-2xl">{c.value}</div>
        </div>
      ))}
    </div>
  );
};

export default OverallKpiCards;
