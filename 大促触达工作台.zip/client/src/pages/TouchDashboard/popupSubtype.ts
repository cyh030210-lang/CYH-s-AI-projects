export const POPUP_CHANNEL = '弹窗';

export type PopupSubtype =
  | 'all'
  | 'category'
  | 'custom'
  | 'promo'
  | 'resend'
  | 'bargain';

export interface PopupSubtypeOption {
  value: PopupSubtype;
  label: string;
}

export const POPUP_SUBTYPE_OPTIONS: PopupSubtypeOption[] = [
  { value: 'all', label: '全部弹窗' },
  { value: 'category', label: '重点类目弹窗' },
  { value: 'custom', label: '重点类目自定义弹窗' },
  { value: 'promo', label: '大促专属弹窗' },
  { value: 'resend', label: '追发货弹窗' },
];

export const classifyPopupSubtype = (
  taskName: string | null,
): PopupSubtype => {
  const name = taskName ?? '';
  if (name.includes('追发货')) return 'resend';
  if (name.includes('大促专属')) return 'promo';
  if (name.includes('重点类目自定义')) return 'custom';
  if (name.includes('议价弹窗')) return 'bargain';
  return 'category';
};

export const getPopupSubtypeLabel = (subtype: PopupSubtype): string =>
  POPUP_SUBTYPE_OPTIONS.find((o) => o.value === subtype)?.label ?? '弹窗';
