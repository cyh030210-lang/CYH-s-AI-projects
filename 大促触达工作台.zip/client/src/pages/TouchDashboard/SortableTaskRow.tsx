import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Checkbox } from '@/components/ui/checkbox';
import type { ReachTaskRow } from './types';
import { formatWan, formatPct, formatPp } from './format';

interface SortableTaskRowProps {
  task: ReachTaskRow;
  checked: boolean;
  onToggle: (taskId: string) => void;
}

const ppToneClass: Record<string, string> = {
  up: 'text-success',
  down: 'text-destructive',
  flat: 'text-muted-foreground',
  none: 'text-muted-foreground/60',
};

const cellNum =
  'px-4 py-3 text-right tabular-nums whitespace-nowrap text-foreground';

const SortableTaskRow: React.FC<SortableTaskRowProps> = ({
  task,
  checked,
  onToggle,
}) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: task.taskId });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    position: 'relative',
    zIndex: isDragging ? 10 : undefined,
  };

  const reachPp = formatPp(task.reachRatePp);
  const actionPp = formatPp(task.actionRatePp);

  return (
    <tr
      ref={setNodeRef}
      style={style}
      className={cn('border-b border-border', isDragging && 'bg-muted')}
    >
      <td className="border-border px-3 py-3 text-center">
        <button
          type="button"
          className="cursor-grab touch-none text-muted-foreground/60 hover:text-brand active:cursor-grabbing"
          {...attributes}
          {...listeners}
          aria-label="拖拽排序"
        >
          <GripVertical className="size-4" />
        </button>
      </td>
      <td className="px-4 py-3">
        <Checkbox
          checked={checked}
          onCheckedChange={() => onToggle(task.taskId)}
          aria-label="选择任务"
        />
      </td>
      <td className="px-4 py-3 text-left">
        <span className="font-mono t-caption whitespace-nowrap c-secondary">
          {task.taskId}
        </span>
      </td>
      <td className="max-w-[300px] px-4 py-3 text-left">
        <span
          className="block truncate text-foreground"
          title={task.taskName}
        >
          {task.taskName}
        </span>
      </td>
      <td className={cellNum}>
        {formatWan(task.sendMerchants)}
      </td>
      <td className={cellNum}>
        {formatWan(task.clickMerchants)}
      </td>
      <td className={cellNum}>
        {formatWan(task.doneMerchants)}
      </td>
      <td className={cellNum}>
        {formatPct(task.reachRate)}
      </td>
      <td className={cellNum}>
        {formatPct(task.actionRate)}
      </td>
      <td className={cn(cellNum, ppToneClass[reachPp.tone])}>
        {reachPp.text}
      </td>
      <td className={cn(cellNum, ppToneClass[actionPp.tone])}>
        {actionPp.text}
      </td>
    </tr>
  );
};

export default SortableTaskRow;
