export const CHANNEL_ORDER: string[] = [
  '弹窗',
  '抖店站内信',
  '抖店PUSH',
  '抖店S卡',
  'PC二级页面动态',
];

export const DEFAULT_CHANNEL = '弹窗';

// 按天明细接口的渠道数据源别名：页面选中的渠道 → 明细查询实际使用的渠道
export const DETAIL_CHANNEL_ALIAS: Record<string, string> = {
  抖店S卡: '大促卡片',
};

export const resolveDetailChannel = (channel: string): string =>
  DETAIL_CHANNEL_ALIAS[channel] ?? channel;

export const DRAG_HINT_TEXT =
  '拖住每行左侧的排序手柄，可在当前渠道内调整触达任务顺序；导出 Excel 会按当前页面顺序导出。';
