import type { ReachTaskRow } from './types';

export interface TrendPoint {
  label: string;
  reachRate: number;
  secondaryRate: number;
}

const parsePeriod = (
  copyStage: string,
): { label: string; order: number } => {
  const range = copyStage.match(/^[\d.]+(?:-[\d.]+)?/);
  const label = range ? range[0] : copyStage;
  const start = copyStage.match(/^(\d+)\.(\d+)/);
  const order = start
    ? Number(start[1]) * 100 + Number(start[2])
    : Number.MAX_SAFE_INTEGER;
  return { label, order };
};

export const aggregateTaskPoints = (tasks: ReachTaskRow[]): TrendPoint[] => {
  const groups = new Map<
    string,
    { label: string; order: number; send: number; click: number; done: number }
  >();
  for (const t of tasks) {
    if (!t.copyStage) continue;
    const key = t.copyStage;
    const existing = groups.get(key);
    if (existing) {
      existing.send += t.sendMerchants ?? 0;
      existing.click += t.clickMerchants ?? 0;
      existing.done += t.doneMerchants ?? 0;
    } else {
      const { label, order } = parsePeriod(t.copyStage);
      groups.set(key, {
        label,
        order,
        send: t.sendMerchants ?? 0,
        click: t.clickMerchants ?? 0,
        done: t.doneMerchants ?? 0,
      });
    }
  }
  return Array.from(groups.values())
    .filter((g) => g.send > 0)
    .sort((a, b) => a.order - b.order)
    .map((g) => ({
      label: g.label,
      reachRate: g.send > 0 ? g.click / g.send : 0,
      secondaryRate: g.send > 0 ? g.done / g.send : 0,
    }));
};
