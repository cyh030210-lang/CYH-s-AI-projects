import React, { useMemo } from 'react';
import { LineChart } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type { TopLevelFormatterParams } from 'echarts/types/dist/shared';
import type { TouchDetailDayRow } from '@shared/api.interface';

interface DetailDayChartProps {
  days: TouchDetailDayRow[];
}

const REACH_COLOR = '#1d74eb';
const DONE_COLOR = '#3d8f66';

const DetailDayChart: React.FC<DetailDayChartProps> = ({ days }) => {
  const option = useMemo<EChartsOption>(() => {
    const labels = days.map((d) => d.sendDate.slice(5));
    const reachData = days.map((d) => Number((d.reachRate * 100).toFixed(2)));
    const doneData = days.map((d) => Number((d.doneRate * 100).toFixed(2)));
    return {
      tooltip: {
        trigger: 'axis',
        formatter: (params: TopLevelFormatterParams) => {
          const list = Array.isArray(params) ? params : [params];
          const first = list[0] as { axisValueLabel?: string; name?: string };
          const title = first?.axisValueLabel ?? first?.name ?? '';
          const rows = list
            .map(
              (p) =>
                `${p.marker as string}${p.seriesName}：${Number(
                  p.value,
                ).toFixed(2)}%`,
            )
            .join('<br/>');
          return `${title}<br/>${rows}`;
        },
      },
      legend: { data: ['触达率', '完成率'], top: 0 },
      grid: { left: '3%', right: '4%', bottom: '10%', top: 40, containLabel: true },
      xAxis: { type: 'category', boundaryGap: false, data: labels },
      yAxis: {
        type: 'value',
        min: 0,
        axisLabel: { formatter: (value: number) => `${value}%` },
      },
      series: [
        {
          name: '触达率',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: REACH_COLOR },
          lineStyle: { color: REACH_COLOR, width: 2 },
          data: reachData,
        },
        {
          name: '完成率',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 7,
          itemStyle: { color: DONE_COLOR },
          lineStyle: { color: DONE_COLOR, width: 2 },
          data: doneData,
        },
      ],
    };
  }, [days]);

  if (days.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-border bg-muted/40 py-10 text-center">
        <div className="flex size-11 items-center justify-center rounded-full bg-muted">
          <LineChart className="size-5 text-muted-foreground" strokeWidth={1.5} />
        </div>
        <div className="t-label c-secondary">该区间暂无数据</div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-muted/40 p-4">
      <div className="flex items-center gap-1.5 t-heading c-primary">
        <LineChart className="size-4 text-brand" />
        按天趋势
      </div>
      <p className="mt-1 t-label c-secondary">
        按发送日期展示触达率与完成率走势，比率以当天发送商家数加总为基准。
      </p>
      <ReactECharts
        option={option}
        theme="ud"
        className="mt-3 h-[300px] w-full"
        notMerge
      />
    </div>
  );
};

export default DetailDayChart;
