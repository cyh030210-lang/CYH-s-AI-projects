import { useState, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { queryTouchDetail } from '@client/src/api';
import { resolveDetailChannel } from './constants';
import {
  STAGE_CHANNELS,
  STAGE_FULL_START,
  STAGE_FULL_END,
  aggregateStages,
  type StagePoint,
} from './stageTrend';

export type StageTrendStatus = 'idle' | 'loading' | 'success' | 'error';

export interface UseStageTrendReturn {
  stagePoints: StagePoint[];
  status: StageTrendStatus;
}

export const useStageTrend = (
  channel: string,
  enabled: boolean,
): UseStageTrendReturn => {
  const [stagePoints, setStagePoints] = useState<StagePoint[]>([]);
  const [status, setStatus] = useState<StageTrendStatus>('idle');

  const isStageChannel = STAGE_CHANNELS.includes(channel);

  useEffect(() => {
    if (!enabled || !isStageChannel) {
      setStagePoints([]);
      setStatus('idle');
      return;
    }

    let alive = true;
    setStatus('loading');
    queryTouchDetail(
      resolveDetailChannel(channel),
      STAGE_FULL_START,
      STAGE_FULL_END,
    )
      .then((data) => {
        if (!alive) return;
        setStagePoints(aggregateStages(data.days));
        setStatus('success');
      })
      .catch((err) => {
        logger.warn('阶段触达趋势查询失败', String(err));
        if (!alive) return;
        setStagePoints([]);
        setStatus('error');
      });

    return () => {
      alive = false;
    };
  }, [channel, enabled, isStageChannel]);

  return { stagePoints, status };
};
