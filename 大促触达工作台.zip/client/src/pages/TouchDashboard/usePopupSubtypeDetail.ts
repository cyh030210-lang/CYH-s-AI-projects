import { useState, useCallback, useEffect } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { queryPopupSubtypeDetail } from '@client/src/api';
import type { TouchDetailQueryResponse } from '@shared/api.interface';
import { POPUP_CHANNEL, type PopupSubtype } from './popupSubtype';

export type PopupDetailStatus = 'idle' | 'loading' | 'success' | 'error';

export interface UsePopupSubtypeDetailReturn {
  status: PopupDetailStatus;
  result?: TouchDetailQueryResponse;
}

export const usePopupSubtypeDetail = (
  channel: string,
  popupSubtype: PopupSubtype,
  taskIds: string[],
): UsePopupSubtypeDetailReturn => {
  const [status, setStatus] = useState<PopupDetailStatus>('idle');
  const [result, setResult] = useState<TouchDetailQueryResponse>();

  const active =
    channel === POPUP_CHANNEL &&
    (popupSubtype === 'promo' || popupSubtype === 'custom') &&
    taskIds.length > 0;

  const idsKey = taskIds.join(',');

  const load = useCallback(async (ids: string[]) => {
    setStatus('loading');
    try {
      const data = await queryPopupSubtypeDetail(ids);
      setResult(data);
      setStatus('success');
    } catch (err) {
      logger.warn('弹窗子类型明细查询失败', String(err));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    if (active) {
      load(idsKey ? idsKey.split(',') : []);
    } else {
      setResult(undefined);
      setStatus('idle');
    }
  }, [active, idsKey, load]);

  return { status, result };
};
