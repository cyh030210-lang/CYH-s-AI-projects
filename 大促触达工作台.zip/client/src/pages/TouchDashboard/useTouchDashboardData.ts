import { useState, useCallback, useEffect, useMemo } from 'react';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type { TouchDashboardResponse } from '@shared/api.interface';
import type {
  ChannelSummary,
  FetchStatus,
  OverallMetrics,
  ReachTaskRow,
} from './types';

export interface UseTouchDashboardDataReturn {
  status: FetchStatus;
  isEmpty: boolean;
  errorMsg?: string;
  overall: OverallMetrics;
  summaryByChannel: Record<string, ChannelSummary | undefined>;
  tasksByChannel: Record<string, ReachTaskRow[]>;
  refresh: () => Promise<void>;
}

const EMPTY_OVERALL: OverallMetrics = {
  sendMerchants: 0,
  clickMerchants: 0,
  doneMerchants: 0,
  reachRate: 0,
  actionRate: 0,
};

export const useTouchDashboardData = (): UseTouchDashboardDataReturn => {
  const [status, setStatus] = useState<FetchStatus>('idle');
  const [summary, setSummary] = useState<ChannelSummary[]>([]);
  const [tasks, setTasks] = useState<ReachTaskRow[]>([]);
  const [errorMsg, setErrorMsg] = useState<string>();

  const fetchData = useCallback(async () => {
    try {
      setStatus('loading');
      setErrorMsg(undefined);

      const res = await axiosForBackend<TouchDashboardResponse>({
        url: '/api/dashboard/touch-data',
        method: 'GET',
      });

      setSummary(res.data?.channelSummary ?? []);
      setTasks(res.data?.tasks ?? []);
      setStatus('success');
    } catch (err) {
      logger.warn('触达看板数据拉取失败', String(err));
      setErrorMsg('数据加载失败，请稍后重试。若持续失败请联系管理员。');
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const overall = useMemo<OverallMetrics>(() => {
    if (summary.length === 0) return EMPTY_OVERALL;
    const send = summary.reduce((acc, s) => acc + s.sendMerchants, 0);
    const click = summary.reduce((acc, s) => acc + s.clickMerchants, 0);
    const done = summary.reduce((acc, s) => acc + s.doneMerchants, 0);
    return {
      sendMerchants: send,
      clickMerchants: click,
      doneMerchants: done,
      reachRate: send > 0 ? click / send : 0,
      actionRate: send > 0 ? done / send : 0,
    };
  }, [summary]);

  const summaryByChannel = useMemo<
    Record<string, ChannelSummary | undefined>
  >(() => {
    const map: Record<string, ChannelSummary | undefined> = {};
    for (const s of summary) map[s.channel] = s;
    return map;
  }, [summary]);

  const tasksByChannel = useMemo<Record<string, ReachTaskRow[]>>(() => {
    const map: Record<string, ReachTaskRow[]> = {};
    for (const t of tasks) {
      if (!map[t.channel]) map[t.channel] = [];
      map[t.channel].push(t);
    }
    return map;
  }, [tasks]);

  const isEmpty = status === 'success' && tasks.length === 0;

  return {
    status,
    isEmpty,
    errorMsg,
    overall,
    summaryByChannel,
    tasksByChannel,
    refresh: fetchData,
  };
};
