import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { AlertCircle, RefreshCw, Inbox } from 'lucide-react';
import type { DateRange } from 'react-day-picker';
import dayjs from 'dayjs';
import { Button } from '@/components/ui/button';
import { useTouchDashboardData } from './useTouchDashboardData';
import { useTouchDetail } from './useTouchDetail';
import { useStageTrend } from './useStageTrend';
import { DEFAULT_CHANNEL, resolveDetailChannel } from './constants';
import {
  POPUP_CHANNEL,
  classifyPopupSubtype,
  getPopupSubtypeLabel,
  type PopupSubtype,
} from './popupSubtype';
import {
  PC_DYNAMIC_CHANNEL,
  type NonSelfSlot,
} from './nonSelfSlot';
import type { ReachTaskRow } from './types';
import { aggregateTaskPoints } from './trendPoints';
import type { AnalysisTrendPoint } from '@client/src/api';
import type { TouchDetailDayRow } from '@shared/api.interface';
import type { KpiMetrics, BannerKpiMetrics } from './OverallKpiCards';
import { exportChannelExcel } from './exportExcel';
import HeroBanner from './HeroBanner';
import OverallKpiCards from './OverallKpiCards';
import ChannelHeader from './ChannelHeader';
import TopFilterBar from './TopFilterBar';
import DetailDrawer from './DetailDrawer';
import TaskTable from './TaskTable';
import TrendPanel from './TrendPanel';
import BannerTrendChart from './BannerTrendChart';
import { STUDY_APP_BANNER_DATA } from './studyAppBannerData';
import { STUDY_PC_BANNER_DATA } from './studyPcBannerData';
import type { StudyBannerPoint } from './studyAppBannerData';

const BANNER_SLOTS: Partial<
  Record<NonSelfSlot, { data: StudyBannerPoint[]; title: string }>
> = {
  study_app: {
    data: STUDY_APP_BANNER_DATA,
    title: '学习中心APP banner 数据趋势',
  },
  study_pc: {
    data: STUDY_PC_BANNER_DATA,
    title: '学习中心PC banner 数据趋势',
  },
};
import AiAnalysisPanel from './AiAnalysisPanel';
import { useAiAnalysis } from './useAiAnalysis';
import { usePopupSubtypeDetail } from './usePopupSubtypeDetail';

const fmt = (d: Date): string => dayjs(d).format('YYYY-MM-DD');

interface TrendView {
  kind: 'day' | 'stage' | 'task';
  secondaryLabel: string;
  points: AnalysisTrendPoint[];
  days?: TouchDetailDayRow[];
  reachRate?: number;
  completionRate?: number;
}

const TouchDashboard: React.FC = () => {
  const {
    status,
    isEmpty,
    errorMsg,
    overall,
    summaryByChannel,
    tasksByChannel,
    refresh,
  } = useTouchDashboardData();

  const {
    status: aiStatus,
    phase: aiPhase,
    result: aiResult,
    error: aiError,
    analyze: runAiAnalyze,
    reset: resetAi,
  } = useAiAnalysis();

  const {
    options: detailOptions,
    status: detailStatus,
    result: detailResult,
    query: queryDetail,
  } = useTouchDetail();

  const [currentChannel, setCurrentChannel] = useState<string>(DEFAULT_CHANNEL);
  const [popupSubtype, setPopupSubtype] = useState<PopupSubtype>('all');
  const [nonSelfSlot, setNonSelfSlot] = useState<NonSelfSlot | undefined>(
    undefined,
  );
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [orderByChannel, setOrderByChannel] = useState<
    Record<string, ReachTaskRow[]>
  >({});
  const [selectedByChannel, setSelectedByChannel] = useState<
    Record<string, string[]>
  >({});

  // 数据加载完成后，初始化各渠道的当前顺序（沿用后端返回顺序）
  useEffect(() => {
    if (status === 'success') {
      setOrderByChannel({ ...tasksByChannel });
    }
  }, [status, tasksByChannel]);

  const currentTasks = useMemo<ReachTaskRow[]>(
    () => orderByChannel[currentChannel] ?? tasksByChannel[currentChannel] ?? [],
    [orderByChannel, tasksByChannel, currentChannel],
  );

  const popupFilterActive =
    currentChannel === POPUP_CHANNEL && popupSubtype !== 'all';

  const displayTasks = useMemo<ReachTaskRow[]>(
    () =>
      popupFilterActive
        ? currentTasks.filter(
            (t) => classifyPopupSubtype(t.taskName) === popupSubtype,
          )
        : currentTasks,
    [currentTasks, popupFilterActive, popupSubtype],
  );

  const subtypeTaskIds = useMemo<string[]>(
    () => displayTasks.map((t) => t.taskId).filter(Boolean),
    [displayTasks],
  );

  const { result: promoDetail } = usePopupSubtypeDetail(
    currentChannel,
    popupSubtype,
    subtypeTaskIds,
  );
  const subtypeDetailMode =
    currentChannel === POPUP_CHANNEL &&
    (popupSubtype === 'promo' || popupSubtype === 'custom') &&
    Boolean(promoDetail);

  const selectedIds = selectedByChannel[currentChannel] ?? [];

  const hasFullRange = Boolean(dateRange?.from && dateRange?.to);
  const isDayMode =
    hasFullRange && detailStatus === 'success' && Boolean(detailResult);

  const { stagePoints } = useStageTrend(currentChannel, !isDayMode);

  const trendView = useMemo<TrendView>(() => {
    const detailDays = isDayMode
      ? detailResult?.days
      : subtypeDetailMode
        ? promoDetail?.days
        : undefined;
    const detailSummary = isDayMode ? detailResult?.summary : promoDetail?.summary;
    if (detailDays) {
      return {
        kind: 'day',
        secondaryLabel: '完成率',
        days: detailDays,
        reachRate: detailSummary?.reachRate,
        completionRate: detailSummary?.doneRate,
        points: detailDays.map((d) => ({
          label: d.sendDate.slice(5),
          reachRate: d.reachRate,
          secondaryRate: d.doneRate,
        })),
      };
    }
    if (stagePoints && stagePoints.length > 0) {
      return {
        kind: 'stage',
        secondaryLabel: '行动率',
        points: stagePoints.map((p) => ({
          label: p.label,
          reachRate: p.reachRate,
          secondaryRate: p.actionRate,
        })),
      };
    }
    return {
      kind: 'task',
      secondaryLabel: '行动率',
      points: aggregateTaskPoints(displayTasks),
    };
  }, [
    isDayMode,
    subtypeDetailMode,
    detailResult,
    promoDetail,
    stagePoints,
    displayTasks,
  ]);

  const handleSelectChannel = useCallback(
    (channel: string) => {
      setCurrentChannel(channel);
      setNonSelfSlot(undefined);
      setPopupSubtype('all');
      if (dateRange?.from && dateRange?.to) {
        queryDetail(
          resolveDetailChannel(channel),
          fmt(dateRange.from),
          fmt(dateRange.to),
        );
      }
    },
    [dateRange, queryDetail],
  );

  const handleNonSelfSlotChange = useCallback(
    (slot: NonSelfSlot) => {
      setNonSelfSlot(slot);
      setCurrentChannel(PC_DYNAMIC_CHANNEL);
      setPopupSubtype('all');
      if (dateRange?.from && dateRange?.to) {
        queryDetail(
          resolveDetailChannel(PC_DYNAMIC_CHANNEL),
          fmt(dateRange.from),
          fmt(dateRange.to),
        );
      }
    },
    [dateRange, queryDetail],
  );

  const bannerSlot = nonSelfSlot ? BANNER_SLOTS[nonSelfSlot] : undefined;
  const slotViewActive = Boolean(bannerSlot);

  const bannerKpi = useMemo<BannerKpiMetrics | undefined>(() => {
    if (!bannerSlot) return undefined;
    const { data } = bannerSlot;
    const n = data.length;
    if (n === 0) {
      return { avgExposure: 0, avgClickUv: 0, avgReachRate: 0 };
    }
    const sumExposure = data.reduce((a, p) => a + p.exposure, 0);
    const sumClickUv = data.reduce((a, p) => a + p.clickUv, 0);
    const sumCtr = data.reduce((a, p) => a + p.ctr, 0);
    return {
      avgExposure: Math.round(sumExposure / n),
      avgClickUv: Math.round(sumClickUv / n),
      avgReachRate: sumCtr / n,
    };
  }, [bannerSlot]);

  const handleRangeChange = useCallback(
    (range: DateRange | undefined) => {
      setDateRange(range);
      if (range?.from && range?.to) {
        queryDetail(
          resolveDetailChannel(currentChannel),
          fmt(range.from),
          fmt(range.to),
          popupFilterActive ? subtypeTaskIds : undefined,
        );
      }
    },
    [currentChannel, popupFilterActive, subtypeTaskIds, queryDetail],
  );

  const handlePopupSubtypeChange = useCallback(
    (subtype: PopupSubtype) => {
      setPopupSubtype(subtype);
      if (currentChannel === POPUP_CHANNEL && dateRange?.from && dateRange?.to) {
        const ids =
          subtype !== 'all'
            ? currentTasks
                .filter((t) => classifyPopupSubtype(t.taskName) === subtype)
                .map((t) => t.taskId)
                .filter(Boolean)
            : undefined;
        queryDetail(
          resolveDetailChannel(currentChannel),
          fmt(dateRange.from),
          fmt(dateRange.to),
          ids,
        );
      }
    },
    [currentChannel, currentTasks, dateRange, queryDetail],
  );

  const kpiMetrics = useMemo<KpiMetrics>(() => {
    if (isDayMode && detailResult) {
      const s = detailResult.summary;
      return {
        sendMerchants: s.sendMerchants,
        clickMerchants: s.clickMerchants,
        doneMerchants: s.doneMerchants,
        reachRate: s.reachRate,
        completionRate: s.doneRate,
      };
    }
    const channelSummary = summaryByChannel[currentChannel];
    if (popupFilterActive) {
      const send = displayTasks.reduce((a, t) => a + (t.sendMerchants ?? 0), 0);
      const click = displayTasks.reduce(
        (a, t) => a + (t.clickMerchants ?? 0),
        0,
      );
      const done = displayTasks.reduce((a, t) => a + (t.doneMerchants ?? 0), 0);
      return {
        sendMerchants: send,
        clickMerchants: click,
        doneMerchants: done,
        reachRate: send > 0 ? click / send : 0,
        completionRate: send > 0 ? done / send : 0,
      };
    }
    if (channelSummary) {
      return {
        sendMerchants: channelSummary.sendMerchants,
        clickMerchants: channelSummary.clickMerchants,
        doneMerchants: channelSummary.doneMerchants,
        reachRate: channelSummary.reachRate,
        completionRate: channelSummary.actionRate,
      };
    }
    return {
      sendMerchants: overall.sendMerchants,
      clickMerchants: overall.clickMerchants,
      doneMerchants: overall.doneMerchants,
      reachRate: overall.reachRate,
      completionRate: overall.actionRate,
    };
  }, [
    isDayMode,
    detailResult,
    overall,
    summaryByChannel,
    currentChannel,
    popupFilterActive,
    displayTasks,
  ]);

  const handleReorder = useCallback(
    (next: ReachTaskRow[]) => {
      setOrderByChannel((prev) => {
        if (!popupFilterActive) {
          return { ...prev, [currentChannel]: next };
        }
        const base = prev[currentChannel] ?? tasksByChannel[currentChannel] ?? [];
        const nextIds = new Set(next.map((t) => t.taskId));
        const others = base.filter((t) => !nextIds.has(t.taskId));
        return { ...prev, [currentChannel]: [...next, ...others] };
      });
    },
    [currentChannel, popupFilterActive, tasksByChannel],
  );

  const handleResetSort = useCallback(() => {
    setOrderByChannel((prev) => ({
      ...prev,
      [currentChannel]: tasksByChannel[currentChannel] ?? [],
    }));
  }, [currentChannel, tasksByChannel]);

  const handleToggle = useCallback(
    (taskId: string) => {
      setSelectedByChannel((prev) => {
        const cur = prev[currentChannel] ?? [];
        const next = cur.includes(taskId)
          ? cur.filter((id) => id !== taskId)
          : [...cur, taskId];
        return { ...prev, [currentChannel]: next };
      });
    },
    [currentChannel],
  );

  const handleExport = useCallback(() => {
    exportChannelExcel(currentChannel, displayTasks);
  }, [currentChannel, displayTasks]);

  const handleAnalyze = useCallback(() => {
    if (trendView.points.length === 0) return;
    const dateRangeText =
      dateRange?.from && dateRange?.to
        ? `${fmt(dateRange.from)} ~ ${fmt(dateRange.to)}`
        : '';
    const scopeLabel = bannerSlot?.title ?? currentChannel;
    runAiAnalyze(
      currentChannel,
      trendView.secondaryLabel,
      trendView.points,
      dateRangeText,
      scopeLabel,
    );
  }, [currentChannel, trendView, dateRange, bannerSlot, runAiAnalyze]);

  useEffect(() => {
    resetAi();
  }, [currentChannel, resetAi]);

  return (
    <div className="h-full w-full overflow-auto rounded-lg bg-background">
      <div className="py-5 sm:py-6">
        <HeroBanner />

        {status === 'error' && errorMsg ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-destructive/30 bg-card py-16 text-center">
            <AlertCircle className="size-6 text-destructive" />
            <div className="t-label c-primary">
              数据加载失败
            </div>
            <div className="t-caption c-secondary">
              {errorMsg}
            </div>
            <Button variant="outline" size="sm" onClick={refresh}>
              <RefreshCw className="mr-1.5 size-3.5" />
              重试
            </Button>
          </div>
        ) : isEmpty ? (
          <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-border bg-card py-16 text-center">
            <div className="flex size-12 items-center justify-center rounded-full bg-muted">
              <Inbox className="size-5 text-muted-foreground" strokeWidth={1.5} />
            </div>
            <div className="t-label c-primary">
              暂无触达数据
            </div>
            <div className="max-w-sm t-caption c-secondary">
              请先导入触达数据后查看看板。导入完成后点击下方刷新。
            </div>
            <Button variant="outline" size="sm" onClick={refresh}>
              <RefreshCw className="mr-1.5 size-3.5" />
              刷新
            </Button>
          </div>
        ) : (
          <div className="space-y-5">
            <TopFilterBar
              channel={currentChannel}
              onSelectChannel={handleSelectChannel}
              range={dateRange}
              onRangeChange={handleRangeChange}
              minDate={detailOptions?.minDate}
              maxDate={detailOptions?.maxDate}
              canViewDetail={isDayMode}
              onViewDetail={() => setDrawerOpen(true)}
              popupSubtype={popupSubtype}
              onPopupSubtypeChange={handlePopupSubtypeChange}
              nonSelfSlot={nonSelfSlot}
              onNonSelfSlotChange={handleNonSelfSlotChange}
              slotActive={slotViewActive}
            />

            <OverallKpiCards metrics={kpiMetrics} bannerMetrics={bannerKpi} />

            <section className="rounded-lg border border-border bg-card p-4 shadow-sm">
              <ChannelHeader />

              <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1.45fr)_minmax(280px,0.55fr)]">
                {currentChannel === PC_DYNAMIC_CHANNEL && bannerSlot ? (
                  <BannerTrendChart
                    points={bannerSlot.data}
                    title={bannerSlot.title}
                  />
                ) : (
                  <TrendPanel
                    channel={currentChannel}
                    summary={summaryByChannel[currentChannel]}
                    tasks={displayTasks}
                    detailDays={
                      trendView.kind === 'day' ? trendView.days : undefined
                    }
                    detailReachRate={
                      trendView.kind === 'day' ? trendView.reachRate : undefined
                    }
                    detailCompletionRate={
                      trendView.kind === 'day'
                        ? trendView.completionRate
                        : undefined
                    }
                    stagePoints={stagePoints}
                  />
                )}
                <AiAnalysisPanel
                  canAnalyze={trendView.points.length > 0}
                  phase={aiPhase}
                  status={aiStatus}
                  result={aiResult}
                  error={aiError}
                  onAnalyze={handleAnalyze}
                />
              </div>
            </section>

            <section className="overflow-hidden rounded-lg border border-border bg-card shadow-sm">
              <div className="border-b border-border p-4">
                <h2 className="truncate t-heading c-primary">任务汇总</h2>
                <p className="mt-1 t-label c-secondary">
                  支持勾选、重排与导出，优先处理波动较大的模板。
                </p>
              </div>

              <TaskTable
                tasks={slotViewActive ? [] : displayTasks}
                selectedIds={selectedIds}
                onReorder={handleReorder}
                onToggle={handleToggle}
                onResetSort={handleResetSort}
                onExport={handleExport}
              />
            </section>

            {isDayMode && detailResult && dateRange?.from && dateRange?.to && (
              <DetailDrawer
                open={drawerOpen}
                onOpenChange={setDrawerOpen}
                channel={
                  currentChannel === POPUP_CHANNEL && popupSubtype !== 'all'
                    ? `弹窗·${getPopupSubtypeLabel(popupSubtype)}`
                    : currentChannel
                }
                startDate={fmt(dateRange.from)}
                endDate={fmt(dateRange.to)}
                days={detailResult.days}
              />
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TouchDashboard;
