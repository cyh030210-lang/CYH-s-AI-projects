import React from 'react';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import type { TableColumnsType } from '@lark-apaas/client-toolkit/antd-table';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import type { TouchDetailDayRow } from '@shared/api.interface';
import { formatCount, formatPct } from './format';

interface DetailDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  channel: string;
  startDate: string;
  endDate: string;
  days: TouchDetailDayRow[];
}

const columns: TableColumnsType<TouchDetailDayRow> = [
  { title: '发送日期', dataIndex: 'sendDate', fixed: 'left', width: 120 },
  {
    title: '发送商家数',
    dataIndex: 'sendMerchants',
    width: 120,
    align: 'right',
    render: (v: number) => formatCount(v),
  },
  {
    title: '点击商家数',
    dataIndex: 'clickMerchants',
    width: 120,
    align: 'right',
    render: (v: number) => formatCount(v),
  },
  {
    title: '完成商家数',
    dataIndex: 'doneMerchants',
    width: 120,
    align: 'right',
    render: (v: number) => formatCount(v),
  },
  {
    title: '触达率',
    dataIndex: 'reachRate',
    width: 100,
    align: 'right',
    render: (v: number) => formatPct(v),
  },
  {
    title: '完成率',
    dataIndex: 'doneRate',
    width: 100,
    align: 'right',
    render: (v: number) => formatPct(v),
  },
];

const DetailDrawer: React.FC<DetailDrawerProps> = ({
  open,
  onOpenChange,
  channel,
  startDate,
  endDate,
  days,
}) => {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full overflow-y-auto sm:max-w-2xl"
      >
        <SheetHeader>
          <SheetTitle>{channel}｜按天明细</SheetTitle>
          <SheetDescription>
            {startDate} ~ {endDate} 每日发送、点击、完成商家数及触达率、完成率。
          </SheetDescription>
        </SheetHeader>

        <div className="mt-4">
          <Table<TouchDetailDayRow>
            columns={columns}
            dataSource={days}
            rowKey="sendDate"
            size="middle"
            scroll={{ x: 680, y: 480 }}
            pagination={false}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default DetailDrawer;
