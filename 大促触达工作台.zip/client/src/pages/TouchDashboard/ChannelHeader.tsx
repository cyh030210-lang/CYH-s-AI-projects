import React from 'react';

const ChannelHeader: React.FC = () => {
  return (
    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
      <div className="min-w-0">
        <h2 className="truncate t-heading c-primary">渠道趋势</h2>
      </div>
    </div>
  );
};

export default ChannelHeader;
