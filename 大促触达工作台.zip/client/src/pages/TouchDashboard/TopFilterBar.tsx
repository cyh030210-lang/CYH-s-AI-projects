import React, { useMemo } from 'react';
import { CalendarDays, X, ListFilter } from 'lucide-react';
import type { DateRange } from 'react-day-picker';
import dayjs from 'dayjs';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import ChannelSwitcher from './ChannelSwitcher';
import { CHANNEL_ORDER } from './constants';
import type { PopupSubtype } from './popupSubtype';
import type { NonSelfSlot } from './nonSelfSlot';

interface TopFilterBarProps {
  channel: string;
  onSelectChannel: (channel: string) => void;
  range: DateRange | undefined;
  onRangeChange: (range: DateRange | undefined) => void;
  minDate?: string;
  maxDate?: string;
  canViewDetail: boolean;
  onViewDetail: () => void;
  popupSubtype: PopupSubtype;
  onPopupSubtypeChange: (subtype: PopupSubtype) => void;
  nonSelfSlot: NonSelfSlot | undefined;
  onNonSelfSlotChange: (slot: NonSelfSlot) => void;
  slotActive: boolean;
}

const toDate = (s: string): Date => dayjs(s).toDate();
const fmt = (d: Date): string => dayjs(d).format('YYYY-MM-DD');

const TopFilterBar: React.FC<TopFilterBarProps> = ({
  channel,
  onSelectChannel,
  range,
  onRangeChange,
  minDate,
  maxDate,
  canViewDetail,
  onViewDetail,
  popupSubtype,
  onPopupSubtypeChange,
  nonSelfSlot,
  onNonSelfSlotChange,
  slotActive,
}) => {
  const [pickerOpen, setPickerOpen] = React.useState(false);

  const min = minDate ? toDate(minDate) : undefined;
  const max = maxDate ? toDate(maxDate) : undefined;

  const rangeLabel = useMemo(() => {
    if (range?.from && range?.to) {
      return `${fmt(range.from)} 至 ${fmt(range.to)}`;
    }
    if (range?.from) return `${fmt(range.from)} 至 —`;
    return '选择日期区间';
  }, [range]);

  const hasRange = Boolean(range?.from || range?.to);

  return (
    <section className="rounded-lg border border-border bg-card p-4 shadow-sm sm:p-5">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <ChannelSwitcher
            currentChannel={channel}
            channels={CHANNEL_ORDER}
            onSelect={onSelectChannel}
            popupSubtype={popupSubtype}
            onPopupSubtypeChange={onPopupSubtypeChange}
            nonSelfSlot={nonSelfSlot}
            onNonSelfSlotChange={onNonSelfSlotChange}
            slotActive={slotActive}
          />
        </div>

        <div className="shrink-0 space-y-2 lg:min-w-[280px]">
          {hasRange && (
            <div className="flex items-center justify-end">
              <button
                type="button"
                onClick={() => onRangeChange(undefined)}
                className="flex items-center gap-0.5 text-xs text-muted-foreground transition-colors hover:text-brand"
              >
                <X className="size-3" />
                清除
              </button>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2">
            <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'min-w-[220px] flex-1 justify-start gap-2 font-normal',
                    !range?.from && 'text-muted-foreground',
                  )}
                >
                  <CalendarDays className="size-4 shrink-0" />
                  <span className="truncate">{rangeLabel}</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="range"
                  selected={range}
                  onSelect={onRangeChange}
                  defaultMonth={min}
                  startMonth={min}
                  endMonth={max}
                  disabled={
                    min && max ? { before: min, after: max } : undefined
                  }
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>

            <Button
              onClick={onViewDetail}
              disabled={!canViewDetail}
              className="gap-1.5"
            >
              <ListFilter className="size-4" />
              查看明细
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TopFilterBar;
