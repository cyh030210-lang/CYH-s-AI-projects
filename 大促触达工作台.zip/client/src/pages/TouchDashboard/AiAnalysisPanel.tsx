import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { AiStatus, AiPhase } from './useAiAnalysis';

interface AiAnalysisPanelProps {
  canAnalyze: boolean;
  status: AiStatus;
  phase: AiPhase;
  result: string;
  error?: string;
  onAnalyze: () => void;
}

const AiAnalysisPanel: React.FC<AiAnalysisPanelProps> = ({
  canAnalyze,
  status,
  phase,
  result,
  error,
  onAnalyze,
}) => {
  const analyzing = status === 'analyzing';
  const disabled = !canAnalyze || analyzing;

  return (
    <aside className="flex min-w-0 flex-col rounded-lg border border-border bg-accent p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-sm font-semibold c-primary">AI分析</h3>
          <p className="mt-1 truncate t-caption c-secondary">
            解读左侧触达趋势折线
          </p>
        </div>
        <span className="shrink-0 rounded-lg bg-brand-muted px-2 py-1 t-caption text-brand">
          当前渠道趋势
        </span>
      </div>

      <div className="mt-4 min-h-0 flex-1 space-y-3">
        {error && (
          <div className="rounded-lg bg-card p-3 t-label text-destructive">
            {error}
          </div>
        )}

        {result ? (
          <div className="max-h-[360px] overflow-y-auto whitespace-pre-wrap rounded-lg bg-card p-3 t-body c-primary">
            {result}
          </div>
        ) : analyzing ? (
          <div className="flex items-center gap-2 rounded-lg bg-card p-3 t-body c-secondary">
            <Loader2 className="size-3.5 animate-spin text-brand" />
            {phase === 'searching'
              ? '正在检索行业大促节奏与竞对平台活动节点…'
              : '正在结合趋势与外部信息生成分析…'}
          </div>
        ) : (
          !error && (
            <div className="rounded-lg bg-card p-3">
              <p className="truncate t-caption font-medium c-secondary">
                使用说明
              </p>
              <p className="mt-1 line-clamp-4 t-body c-primary">
                点击生成分析，AI 会先联网检索行业大促节奏与竞对平台活动节点，再结合触达配置时间与当前折线趋势，输出趋势解读、触达时效建议与策略调整建议。分析范围与折线图一致，勾选任务不影响分析。
              </p>
            </div>
          )
        )}
      </div>

      <button
        type="button"
        onClick={onAnalyze}
        disabled={disabled}
        className={cn(
          'mt-4 flex h-9 w-full items-center justify-center gap-1.5 rounded-lg bg-brand t-label text-brand-foreground transition-opacity',
          disabled ? 'cursor-not-allowed opacity-50' : 'hover:opacity-90',
        )}
      >
        {analyzing ? (
          <>
            <Loader2 className="size-3.5 animate-spin" />
            {phase === 'searching' ? '检索行业动态中' : '分析中'}
          </>
        ) : (
          '生成分析'
        )}
      </button>
    </aside>
  );
};

export default AiAnalysisPanel;
