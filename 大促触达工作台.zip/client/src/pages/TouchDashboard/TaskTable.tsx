import React, { useState } from 'react';
import {
  DndContext,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { restrictToVerticalAxis } from '@dnd-kit/modifiers';
import { Info, RotateCcw, Download, BarChart3 } from 'lucide-react';
import type { ReachTaskRow } from './types';
import { DRAG_HINT_TEXT } from './constants';
import SortableTaskRow from './SortableTaskRow';
import SelectedTrendDialog from './SelectedTrendDialog';

interface TaskTableProps {
  tasks: ReachTaskRow[];
  selectedIds: string[];
  onReorder: (tasks: ReachTaskRow[]) => void;
  onToggle: (taskId: string) => void;
  onResetSort: () => void;
  onExport: () => void;
}

const HEAD: { label: string; align: 'left' | 'right' | 'center' }[] = [
  { label: '排序', align: 'center' },
  { label: '选择', align: 'left' },
  { label: '任务ID/消息模版', align: 'left' },
  { label: '触达任务名称', align: 'left' },
  { label: '发送商家数', align: 'right' },
  { label: '点击商家数', align: 'right' },
  { label: '完成商家数', align: 'right' },
  { label: '触达率', align: 'right' },
  { label: '行动率', align: 'right' },
  { label: '触达率环比', align: 'right' },
  { label: '行动率环比', align: 'right' },
];

const TaskTable: React.FC<TaskTableProps> = ({
  tasks,
  selectedIds,
  onReorder,
  onToggle,
  onResetSort,
  onExport,
}) => {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = tasks.findIndex((t) => t.taskId === active.id);
    const newIndex = tasks.findIndex((t) => t.taskId === over.id);
    if (oldIndex < 0 || newIndex < 0) return;
    onReorder(arrayMove(tasks, oldIndex, newIndex));
  };

  const selectedSet = new Set(selectedIds);
  const selectedTasks = tasks.filter((t) => selectedSet.has(t.taskId));
  const [analysisOpen, setAnalysisOpen] = useState(false);

  return (
    <>
    <div>
      <div className="mb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 rounded-md bg-accent px-3.5 py-2.5 t-label text-accent-foreground">
          <Info className="size-4 shrink-0" />
          <span>{DRAG_HINT_TEXT}</span>
        </div>
        <div className="flex shrink-0 flex-wrap items-center gap-2">
          {selectedTasks.length > 0 && (
            <>
              <span className="t-caption c-secondary">
                已勾选 {selectedTasks.length} 条
              </span>
              <button
                type="button"
                onClick={() => setAnalysisOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-md border border-brand-border bg-card px-3.5 py-2 t-caption font-medium text-brand transition-colors hover:bg-accent"
              >
                <BarChart3 className="size-3.5" />
                分析
              </button>
            </>
          )}
          <button
            type="button"
            onClick={onResetSort}
            className="inline-flex items-center gap-1.5 rounded-md border border-brand-border bg-card px-3.5 py-2 t-caption font-medium text-brand transition-colors hover:bg-accent"
          >
            <RotateCcw className="size-3.5" />
            恢复默认排序
          </button>
          <button
            type="button"
            onClick={onExport}
            className="inline-flex items-center gap-1.5 rounded-md bg-brand px-3.5 py-2 t-caption font-medium text-brand-foreground transition-opacity hover:opacity-90"
          >
            <Download className="size-3.5" />
            导出 Excel
          </button>
        </div>
      </div>

      <div className="touch-scrollbar max-h-[520px] overflow-auto rounded-md border border-border">
        <table className="w-full min-w-[1180px] border-collapse text-sm">
          <thead>
            <tr>
              {HEAD.map((h) => (
                <th
                  key={h.label}
                  className="sticky top-0 z-10 whitespace-nowrap border-b border-border bg-muted px-4 py-3 t-caption font-semibold c-secondary"
                  style={{ textAlign: h.align }}
                >
                  {h.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tasks.length === 0 ? (
              <tr>
                <td
                  colSpan={HEAD.length}
                  className="px-4 py-12 text-center t-body c-secondary"
                >
                  当前渠道暂无任务数据
                </td>
              </tr>
            ) : (
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                modifiers={[restrictToVerticalAxis]}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={tasks.map((t) => t.taskId)}
                  strategy={verticalListSortingStrategy}
                >
                  {tasks.map((t) => (
                    <SortableTaskRow
                      key={t.taskId}
                      task={t}
                      checked={selectedSet.has(t.taskId)}
                      onToggle={onToggle}
                    />
                  ))}
                </SortableContext>
              </DndContext>
            )}
          </tbody>
        </table>
      </div>

      <SelectedTrendDialog
        open={analysisOpen}
        onOpenChange={setAnalysisOpen}
        tasks={selectedTasks}
      />
    </div>
    </>
  );
};

export default TaskTable;
