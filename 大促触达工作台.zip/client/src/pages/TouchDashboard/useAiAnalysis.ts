import { useState, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  analyzeReachTasks,
  searchMarketContext,
  type AnalysisTrendPoint,
} from '@client/src/api';

export type AiStatus = 'idle' | 'analyzing' | 'success' | 'error';
export type AiPhase = 'searching' | 'writing' | undefined;

export interface UseAiAnalysisReturn {
  status: AiStatus;
  phase: AiPhase;
  result: string;
  error?: string;
  analyze: (
    channel: string,
    secondaryLabel: string,
    points: AnalysisTrendPoint[],
    dateRangeText: string,
    scopeLabel: string,
  ) => Promise<void>;
  reset: () => void;
}

export const useAiAnalysis = (): UseAiAnalysisReturn => {
  const [status, setStatus] = useState<AiStatus>('idle');
  const [phase, setPhase] = useState<AiPhase>(undefined);
  const [result, setResult] = useState('');
  const [error, setError] = useState<string>();

  const analyze = useCallback(
    async (
      channel: string,
      secondaryLabel: string,
      points: AnalysisTrendPoint[],
      dateRangeText: string,
      scopeLabel: string,
    ) => {
      if (points.length === 0) return;
      setStatus('analyzing');
      setResult('');
      setError(undefined);
      try {
        setPhase('searching');
        let marketContext = '';
        try {
          marketContext = await searchMarketContext(scopeLabel, dateRangeText);
        } catch (searchErr) {
          logger.warn('行业与竞对信息检索失败，降级为仅内部数据分析', String(searchErr));
          marketContext = '';
        }

        setPhase('writing');
        await analyzeReachTasks(
          channel,
          secondaryLabel,
          points,
          dateRangeText,
          marketContext,
          (accumulated) => {
            setResult(accumulated);
          },
        );
        setPhase(undefined);
        setStatus('success');
      } catch (err) {
        logger.error('触达任务 AI 分析失败', String(err));
        setError('AI 分析失败，请稍后重试。');
        setPhase(undefined);
        setStatus('error');
      }
    },
    [],
  );

  const reset = useCallback(() => {
    setStatus('idle');
    setPhase(undefined);
    setResult('');
    setError(undefined);
  }, []);

  return { status, phase, result, error, analyze, reset };
};
