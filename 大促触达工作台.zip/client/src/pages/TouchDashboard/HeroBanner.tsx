import React from 'react';

const HeroBanner: React.FC = () => {
  return (
    <div className="mb-[22px] flex items-center justify-between rounded-2xl bg-[#e0e9ff] px-7 py-7 shadow-sm">
      <div className="min-w-0">
        <h1 className="t-display c-primary text-xl">618商家触达效果复盘看板</h1>
        <p className="mt-2 max-w-3xl t-body-lg c-secondary text-sm">
          围绕触达效率与行动转化效率，复盘不同触达渠道的商家触达效果
        </p>
      </div>
    </div>
  );
};

export default HeroBanner;
