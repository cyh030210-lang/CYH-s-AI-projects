import { Outlet } from "react-router-dom";

const Layout = () => {
  return (
    <div className="min-h-screen w-full bg-background text-foreground">
      <Outlet />
    </div>
  );
};

export default Layout;
