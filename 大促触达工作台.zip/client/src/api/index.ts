import { logger } from '@lark-apaas/client-toolkit/logger';
import { capabilityClient } from '@lark-apaas/client-toolkit';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  TouchDetailOptionsResponse,
  TouchDetailQueryResponse,
} from '@shared/api.interface';
import type {
  MarketingCopyGeneratorOneInput,
  MarketingCopyGeneratorOneOutput,
  WritingHighQualityTextOneOutput,
  AiSearchInfoRetrievalOneOutput,
} from '@shared/plugin-types';

interface TrendSearchChunk {
  summary?: string;
}

export interface AnalysisTrendPoint {
  label: string;
  reachRate: number;
  secondaryRate: number;
}

const MARKETING_COPY_PLUGIN_ID = 'marketing_copy_generator_1';
const MARKETING_COPY_ACTION = 'textGenerate';

const AI_WRITING_PLUGIN_ID = 'writing_high_quality_text_1';
const AI_WRITING_ACTION = 'textGenerate';

const TREND_SEARCH_PLUGIN_ID = 'ecommerce_category_trend_search_1';
const TREND_SEARCH_ACTION = 'searchSummary';

const MARKET_SEARCH_PLUGIN_ID = 'ai_search_info_retrieval_1';
const MARKET_SEARCH_ACTION = 'searchSummary';

const stripMarkdown = (text: string): string =>
  text.replace(/^\s{0,3}#{1,6}\s+/gm, '').replace(/\*/g, '');

/**
 * 拉取触达明细的筛选项：渠道列表 + 日期上下界。
 */
export async function fetchTouchDetailOptions(): Promise<TouchDetailOptionsResponse> {
  const res = await axiosForBackend<TouchDetailOptionsResponse>({
    url: '/api/dashboard/detail/options',
    method: 'GET',
  });
  return res.data;
}

/**
 * 按渠道 + 日期区间查询触达明细，返回区间汇总与按天走势。
 */
export async function queryTouchDetail(
  channel: string,
  startDate: string,
  endDate: string,
  taskIds?: string[],
): Promise<TouchDetailQueryResponse> {
  const res = await axiosForBackend<TouchDetailQueryResponse>({
    url: '/api/dashboard/detail/query',
    method: 'GET',
    params: {
      channel,
      startDate,
      endDate,
      taskIds: taskIds && taskIds.length > 0 ? taskIds.join(',') : undefined,
    },
  });
  return res.data;
}

/**
 * 按任务 ID 集合查询弹窗子类型对应任务的全周期按天明细，返回汇总与逐日走势。
 */
export async function queryPopupSubtypeDetail(
  taskIds: string[],
): Promise<TouchDetailQueryResponse> {
  const res = await axiosForBackend<TouchDetailQueryResponse>({
    url: '/api/dashboard/detail/popup-subtype',
    method: 'GET',
    params: { taskIds: taskIds.join(',') },
  });
  return res.data;
}

/**
 * 流式生成单个类目的营销触达文案。
 * 每生成一段增量内容会通过 onChunk 回调返回，调用方负责累加展示。
 */
export async function generateMarketingCopy(
  input: MarketingCopyGeneratorOneInput,
  onChunk: (delta: string, accumulated: string) => void,
): Promise<string> {
  logger.info(
    '生成营销文案入参',
    JSON.stringify({
      promotionPeriod: input.promotionPeriod,
      category: input.category,
      hasWritingStyle: !!input.writingStyle,
      writingStyleLength: input.writingStyle?.length ?? 0,
      writingStylePreview: input.writingStyle?.slice(0, 80) ?? '',
    }),
  );
  let accumulated = '';
  const stream = await capabilityClient
    .load(MARKETING_COPY_PLUGIN_ID)
    .callStream<MarketingCopyGeneratorOneOutput>(MARKETING_COPY_ACTION, {
      ...input,
    });

  for await (const chunk of stream) {
    const delta = chunk?.content ?? '';
    if (delta) {
      accumulated += delta;
      const clean = stripMarkdown(accumulated);
      onChunk(delta, clean);
    }
  }

  const cleaned = stripMarkdown(accumulated);

  if (!cleaned) {
    logger.warn('营销文案生成返回空内容', JSON.stringify({ input }));
  }

  return cleaned;
}

/**
 * 基于左侧折线图当前展示的曲线点（label + 触达率 + 第二条曲线比率），
 * 仅客观解读触达趋势折线的走势，分点流式输出分析报告。
 * 曲线点与图表逐点一致，secondaryLabel 为第二条曲线名称（行动率或完成率）。
 * 使用智能写作插件，不生成任何营销推广文案。
 */
export async function analyzeReachTasks(
  channelName: string,
  secondaryLabel: string,
  points: AnalysisTrendPoint[],
  dateRangeText: string,
  marketContext: string,
  onChunk: (accumulated: string) => void,
): Promise<string> {
  const trendLines = points
    .map(
      (p) =>
        `- ${p.label}：触达率 ${(p.reachRate * 100).toFixed(2)}%，${secondaryLabel} ${(p.secondaryRate * 100).toFixed(2)}%`,
    )
    .join('\n');

  const nodeLabels = points.map((p) => p.label).join('、');
  const configTimeText = dateRangeText
    ? `本次分析的触达配置时间区间为 ${dateRangeText}；`
    : '本次未限定具体日期区间（按阶段/任务维度展示）；';
  const marketText = marketContext
    ? marketContext
    : '本次未获取到外部行业与竞对信息，请仅基于内部数据与触达配置时间给出建议，并在相关结论中说明缺少外部信息。';

  const prompt = [
    '你是电商触达数据分析师。请结合下方「触达趋势数据」「触达配置时间」与「行业大促节奏及竞对平台活动节点」，输出一份既解读趋势、又给出触达时效与策略调整建议的分析报告。',
    `本次只分析「${channelName}」这一个触达渠道，下方趋势数据都来自该渠道，且与图中折线逐点一致。`,
    '',
    '【严格禁止】',
    '- 禁止生成任何营销、推广、招商、促销、号召报名的文案或话术；',
    '- 禁止使用 emoji、感叹号式煊动语（如“爆单风口”“立刻锁位”“仅剩N个”“限时X折”等）；',
    '- 禁止编造数据：趋势结论必须引用下方真实节点名与百分比数值；引用外部节点时仅使用下方「行业与竞对信息」中出现的内容；',
    '- 建议必须具体可执行（如提前多少天、对齐/避开哪个节点、调整哪个低效节点），不写空泛口号。',
    '',
    `【渠道】${channelName}`,
    `【触达配置时间】${configTimeText}趋势涵盖的节点：${nodeLabels}。`,
    `【行业大促节奏与竞对平台活动节点（联网检索）】`,
    marketText,
    '',
    `【触达趋势数据（按图中顺序排列，对应图中触达率/${secondaryLabel}两条曲线）】`,
    trendLines,
    '',
    '请用 1. 2. 3. 编号输出三段：',
    `1. 【趋势解读】触达率与${secondaryLabel}的整体走势方向，点名最高/最低及明显拐点出现在哪个具体节点（带百分比数值），并概括波动特征；`,
    `2. 【触达时效建议】结合触达配置时间与行业大促/竞对平台活动节点，判断当前触达节奏是否踩中大促窗口、是否需提前或延后，明确建议对齐或避开哪些具体日期/节点（引用具体日期或节点名）；`,
    `3. 【策略调整建议】基于趋势波动特征给出可执行的策略调整（如加大某阶段投放、重点优化某低效节点的触达内容或频次），需点名具体节点与方向。`,
    '',
    '每一段都需基于上方真实数据与信息；不使用 Markdown 符号（如 # 或 *）；不写开场白与结束语。',
  ].join('\n');

  let accumulated = '';
  const stream = await capabilityClient
    .load(AI_WRITING_PLUGIN_ID)
    .callStream<WritingHighQualityTextOneOutput>(AI_WRITING_ACTION, {
      prompt,
    });

  for await (const chunk of stream) {
    const delta = chunk?.content ?? '';
    if (delta) {
      accumulated += delta;
      onChunk(stripMarkdown(accumulated));
    }
  }

  const cleaned = stripMarkdown(accumulated);
  if (!cleaned) {
    logger.warn('触达任务 AI 分析返回空内容', JSON.stringify({ channelName }));
  }
  return cleaned;
}

/**
 * 流式联网搜索某电商类目当前的消费趋势并总结。
 * 每生成一段会通过 onChunk 返回累计文本，调用方可实时展示。
 */
export async function searchCategoryTrend(
  query: string,
  onChunk?: (accumulated: string) => void,
): Promise<string> {
  let accumulated = '';
  const stream = await capabilityClient
    .load(TREND_SEARCH_PLUGIN_ID)
    .callStream<TrendSearchChunk>(TREND_SEARCH_ACTION, {
      query,
    });

  for await (const chunk of stream) {
    const delta = chunk?.summary ?? '';
    if (delta) {
      accumulated += delta;
      const clean = stripMarkdown(accumulated);
      onChunk?.(clean);
    }
  }

  const cleaned = stripMarkdown(accumulated);

  if (!cleaned) {
    logger.warn('类目消费趋势搜索返回空内容', JSON.stringify({ query }));
  }

  return cleaned;
}

/**
 * 联网检索当前时段的行业大促节奏与竞对平台活动节点，为触达分析提供外部上下文。
 * 流式返回，累加摘要。检索失败或空结果时返回空串，不抛错。
 */
export async function searchMarketContext(
  scopeLabel: string,
  dateRangeText: string,
  onChunk?: (accumulated: string) => void,
): Promise<string> {
  const year = new Date().getFullYear();
  const rangePart = dateRangeText ? `时间区间 ${dateRangeText}` : '近期及未来';
  const query =
    `${year} 电商行业大促节奏 各主要电商平台活动节点 ${scopeLabel} ${rangePart} 竞品平台促销安排`.slice(
      0,
      500,
    );
  const instruction =
    '按时间线整理近期及未来的行业大促节点与主要电商平台活动节点，提取具体日期与节点名称，简明列出。';

  let accumulated = '';
  const stream = await capabilityClient
    .load(MARKET_SEARCH_PLUGIN_ID)
    .callStream<AiSearchInfoRetrievalOneOutput>(MARKET_SEARCH_ACTION, {
      query,
      instruction,
    });

  for await (const chunk of stream) {
    const delta = chunk?.summary ?? '';
    if (delta) {
      accumulated += delta;
      onChunk?.(stripMarkdown(accumulated));
    }
  }

  const cleaned = stripMarkdown(accumulated);
  if (!cleaned) {
    logger.warn('行业与竞对信息检索返回空内容', JSON.stringify({ scopeLabel }));
  }
  return cleaned;
}
