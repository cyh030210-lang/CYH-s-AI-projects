# UI 设计指南

> **设计类型**: App 设计（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。

> ℹ️ Section 1 为设计意图与决策上下文。Code agent 实现时以 Section 2 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解

- **目标用户**: 电商运营人员，高频配置促销参数并获取AI文案，追求效率与确定性
- **核心目的**: 引导行动（快速完成配置→生成→复制），建立对AI产出质量的信任
- **情绪基调**: 专注、高效 / 避免焦虑、信息过载

### 1.2 设计方向

- **Design Style**: Blue-White Clean 蓝白清爽 — 冷调蓝白中性底 + 品牌蓝唯一功能强调色，依赖留白节奏与蓝色强调建立层级，主操作一眼可见
- **Application Type**: Tool（单页工作台）— 无全局导航，沉浸式配置-结果双区布局
- **Aesthetic Direction**: 极浅蓝页面底 + 白色卡片 + 品牌蓝强调，极轻冷色阴影，强调留白节奏与精密小圆角，营造清爽专业的高效感

## 2. Color System (色彩系统)

**色彩关系**: 品牌蓝强调 + 冷调蓝白中性底 + 深蓝灰文字，品牌蓝作为唯一功能强调色贯穿主 CTA / 选中态 / 激活态 / Focus，语义色（成功/错误）在反馈时出现
**配色设计理由**: 高频业务工具需要主操作一眼可见；以品牌蓝建立清晰的行动指引与状态区分，蓝白底色清爽低疲劳，与「数据复盘」原有蓝色视觉天然统一
**主色推导**: primary 与 brand 同源为品牌蓝 `hsl(214 84% 51%)`，绑定「生成文案」核心行动、选中态、激活态与 Focus ring
**使用比例**: 60% 蓝白中性底色 / 30% 白色卡片 / 10% 品牌蓝（主按钮、选中态、激活态、关键强调）；语义色仅在反馈时出现

### 2.1 主题颜色

| Token                | HSL 值           | 说明                                     |
| -------------------- | ---------------- | ---------------------------------------- |
| `background`         | hsl(210 40% 98%) | 页面底色，极浅蓝，清爽不刺眼             |
| `card`               | hsl(0 0% 100%)   | 卡片/容器背景，纯白区分层级              |
| `foreground`         | hsl(215 28% 17%) | 主文字，深蓝灰保障长文案可读性           |
| `muted-foreground`   | hsl(215 16% 47%) | 次要文字/提示语/占位符                   |
| `primary` / `brand`  | hsl(214 84% 51%) | 主交互色，品牌蓝，生成按钮填充+选中态    |
| `primary-foreground` | hsl(0 0% 100%)   | 主按钮文字，确保对比度≥4.5:1             |
| `brand-muted`        | hsl(214 84% 51% / 0.10) | 选中态浅蓝底、步骤序号徽标底      |
| `brand-border`       | hsl(214 80% 56%) | 强调按钮描边                             |
| `accent`             | hsl(210 92% 95%) | 浅蓝 chip 底、下拉项 focus、hover 浅底   |
| `accent-foreground`  | hsl(214 84% 40%) | accent 上的文字/图标                     |
| `border`             | hsl(214 30% 90%) | 默认边框，低存在感                       |

### 2.2 导航区配色

- **基调关系**: 无全局导航；顶部标题区复用 `background` 底色，与内容区无缝衔接
- **关键状态**: 不适用
- **边界与背景**: 不适用

### 2.3 语义颜色

| 用途     | HSL 值             | 衍生说明                              |
| -------- | ------------------ | ------------------------------------- |
| 错误/必填缺失 | hsl(0 72% 51%)  | 红色，表单校验失败边框+提示文字，对比度≥4.5:1 |
| 成功/已复制/环比涨   | hsl(150 40% 40%) | 绿色，Toast反馈+复制成功图标+环比上涨 |

## 3. Typography (字体排版)

- **Heading**: -apple-system, "SF Pro SC", "PingFang SC", "Microsoft YaHei", sans-serif
- **Body**: -apple-system, "SF Pro SC", "PingFang SC", "Microsoft YaHei", sans-serif
- **字体策略**: 全中文 UI 采用系统原生字体栈（Apple 同款克制高级感），不引入网络展示字体；标题 font-semibold/tracking-tight，正文 text-base/leading-relaxed；数字用 tabular-nums 对齐

## 4. Layout Strategy (布局策略)

- **导航意图**: 无全局导航；纯单页工作台，顶部仅标题+副标题，不引入Sidebar/Topbar
- **页面架构**: 桌面端左右分栏（左40%配置/右60%结果），max-w-[1200px] 居中；左侧底部固定操作栏
- **响应式**: 移动端堆叠为上下布局，配置区在上、结果区在下，操作栏吸底

## 5. Visual Language (视觉语言)

- **形态参数**: 圆角 `rounded-lg (0.5rem)` · 阴影 `shadow-sm`（极轻冷色阴影）· 间距基调有节奏（标题区留白大 `mb-8`，内容区 `p-6`，步骤 `space-y-8`，相关元素紧凑）
- **识别签名**: 选中态=品牌蓝边框(`border-brand`)+浅蓝底(`bg-brand-muted`)；Tab 用品牌蓝下划线(`border-brand text-brand`)；步骤序号为品牌蓝浅底实心徽标；图标统一 lucide 线性单色；空态用线性图标置于浅圆容器，不用插画
- **装饰策略**: 无多余装饰图形；HeroBanner 用品牌蓝渐变横幅；仅通过留白、极轻阴影、品牌蓝强调与边框建立层级
- **动效原则**: 卡片选中/取消 150ms ease；生成结果从骨架屏淡入 200ms；Toast 自动消失 2s
- **可及性**: 正文对比度≥4.5:1；选中态边框清晰；Focus态可见 ring（`focus-visible:ring-ring/40`）

## 6. Component Principles (组件原则)

- **状态完整性**: 促销周期卡片覆盖 Default/Hover/Selected/Focus/Disabled（选中=品牌蓝浅底，Hover=浅灰底，明确区分）；生成按钮含 Loading 态禁用点击
- **层级清晰**: 「生成文案」= 品牌蓝实心主按钮（`bg-brand text-brand-foreground`）；「清空」= ghost按钮；文案卡片复制按钮=icon-only ghost
- **一致性**: 所有卡片统一 rounded-lg + shadow-sm；标签/chip 用 `bg-accent text-brand` 或 `bg-muted` 弱化；输入框 Focus 态统一 ring ring-ring/30

## 7. Image Direction (图片与视觉资产，按需)

- **Image Role**: 不使用插画；空态以 lucide 线性图标（如 PenLine/Inbox）置于浅 `bg-muted` 圆形容器表达
- **Image Art Direction**: 极简风格不引入插画/照片，视觉表达全部由排版、留白与图标承担
- **Image Prompt Keywords**: 不适用
- **Image Avoidance**: 卡通插画、3D渲染、科技感粒子、高饱和渐变、通用商务人物

## 8. 应避免 (Anti-patterns)

- ❌ 硬编码 hex 色值脱离 token 体系（颜色一律走语义 token / CSS 变量）
- ❌ 彩色圆角 pill 滥用（chip 统一 `bg-accent text-brand` 或 `bg-muted` 弱化）
- ❌ 卡片或提示框使用侧边彩条、毛玻璃装饰
- ❌ 处处等距的 padding（须有节奏：标题区留白大、相关元素紧、区块间松）
- ❌ 右侧结果区添加统计卡片/历史记录等未声明模块

## Design Context

### Users
电商运营人员，高频配置促销参数并获取 AI 文案，桌面为主、移动为辅，追求效率、确定性与专业体验。

### Brand Personality
清爽 · 高效 · 专业。情感目标：专注、可信、有指引，让主操作一眼可见，专业用户高效完成配置-生成-复制闭环。

### Aesthetic Direction
Blue-White Clean 蓝白清爽：极浅蓝底 + 白色卡片 + 品牌蓝强调。品牌蓝 `hsl(214 84% 51%)` 为唯一功能强调色，统一用于主 CTA / 选中态 / 激活态 / Focus。系统原生字体，精密小圆角，极轻冷阴影。反面参考：彩色 pill 滥用、卡通插画、毛玻璃、侧边彩条、硬编码 hex。

### Design Principles
1. 主操作一眼可见——品牌蓝贯穿主 CTA、选中态、激活态，指引用户视线
2. 间距有节奏——标题区留白大于内容区，相关元素紧凑、区块间松弛
3. 图标统一 lucide 线性单色，杜绝 emoji 与彩色图标
4. 颜色全部走语义 token，禁止硬编码 hex
5. 响应式适配而非缩放——移动端堆叠时重新校准 padding，不拥挤不浪费