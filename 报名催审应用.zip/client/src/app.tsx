import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

import { useAuth, ROLE_SUBJECT } from '@lark-apaas/client-toolkit/auth';
import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';
import UrgeAuditEntry from './pages/UrgeAuditEntry/UrgeAuditEntry';
import UrgeAuditManage from './pages/UrgeAuditManage/UrgeAuditManage';
import Unauthorized from './pages/Unauthorized/Unauthorized';

const Loading: React.FC = () => (
  <div className="flex min-h-screen w-full items-center justify-center bg-background text-sm text-muted-foreground">
    加载中...
  </div>
);

const ProtectedRoute: React.FC<{
  children: React.ReactNode;
  requiredRoles: string[];
}> = ({ children, requiredRoles }) => {
  const { ability, isLoading } = useAuth();
  if (isLoading) return <Loading />;
  const hasPermission = requiredRoles.some((role) =>
    ability.can(role, ROLE_SUBJECT),
  );
  return hasPermission ? (
    <>{children}</>
  ) : (
    <Navigate to="/unauthorized" replace />
  );
};

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<UrgeAuditEntry />} />
        <Route
          path="manage"
          element={
            <ProtectedRoute requiredRoles={['admin']}>
              <UrgeAuditManage />
            </ProtectedRoute>
          }
        />
        <Route path="unauthorized" element={<Unauthorized />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
